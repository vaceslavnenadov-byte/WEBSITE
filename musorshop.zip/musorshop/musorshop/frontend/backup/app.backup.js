// ==================== НАСТРОЙКИ ====================

// Адрес нашего бэкенда
const API_URL = 'http://localhost:5000/api';

// ==================== СОСТОЯНИЕ ПРИЛОЖЕНИЯ ====================

let products = [];           // все товары, загруженные с сервера
let currentUser = null;      // текущий пользователь (null = гость)
let wishlistIds = new Set(); // id товаров в избранном (заполним на шаге 21)
let ratings = {};            // рейтинги товаров (заполним на шаге 22)

// Обработчики кнопок на карточках: { buy: функция, reviews: функция, ... }
// На следующих шагах мы будем добавлять сюда новые действия
const cardActions = {};

// ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

// Токен хранится в localStorage
function getToken() {
  return localStorage.getItem('token');
}

// Сброс сессии (при выходе или если токен истёк)
function clearSession() {
  localStorage.removeItem('token');
  currentUser = null;
  wishlistIds = new Set();
}

// Экранирование спецсимволов HTML — защита от XSS.
// Всё, что пришло от пользователей (названия, описания, отзывы),
// перед вставкой в страницу пропускаем через эту функцию
function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Формат суммы: 100000 -> "100 000"
function formatPrice(value) {
  return Number(value || 0).toLocaleString('ru-RU');
}

// Универсальный запрос к API.
// Сам добавляет токен, превращает тело в JSON и выбрасывает ошибку с текстом от сервера
async function apiRequest(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  let response;
  try {
    response = await fetch(API_URL + path, {
      method: options.method || 'GET',
      headers,
      body: options.body ? JSON.stringify(options.body) : undefined
    });
  } catch (err) {
    // fetch падает, только если сервер вообще не ответил
    throw new Error('Сервер недоступен. Проверьте, что бэкенд запущен');
  }

  let data = null;
  try {
    data = await response.json();
  } catch (err) {
    // ответ без JSON — оставляем data = null
  }

  // 401 при наличии токена = токен истёк или недействителен. Выходим из аккаунта
  if (response.status === 401 && token) {
    clearSession();
    updateUI();
    renderProducts();
    renderRoute(); // если были в кабинете — возвращаемся в каталог
  }

  if (!response.ok) {
    throw new Error((data && data.message) || 'Ошибка запроса');
  }
  return data;
}

// ==================== УВЕДОМЛЕНИЯ (TOAST) ====================

const TOAST_TYPES = {
  success: { icon: '✅', border: 'border-green-500' },
  error:   { icon: '❌', border: 'border-red-500' },
  info:    { icon: 'ℹ️', border: 'border-blue-500' },
  warning: { icon: '⚠️', border: 'border-yellow-500' }
};

// Показать уведомление. duration — время показа в миллисекундах
function showToast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toastContainer');
  const style = TOAST_TYPES[type] || TOAST_TYPES.info;

  const toast = document.createElement('div');
  toast.setAttribute('role', 'status');
  // Начальное состояние: прозрачный и сдвинут вправо (для анимации появления)
  toast.className =
    `flex items-start gap-3 p-4 rounded-xl bg-gray-900 border border-gray-800 border-l-4 ${style.border} ` +
    'shadow-2xl text-sm cursor-pointer transition-all duration-300 opacity-0 translate-x-8';
  toast.innerHTML =
    `<span class="text-lg leading-none">${style.icon}</span>` +
    `<span class="flex-1">${escapeHtml(message)}</span>`;

  container.appendChild(toast);

  // Через мгновение убираем "скрытые" классы — toast плавно выезжает
  setTimeout(() => toast.classList.remove('opacity-0', 'translate-x-8'), 20);

  // Плавное исчезновение и удаление из страницы
  const hide = () => {
    toast.classList.add('opacity-0', 'translate-x-8');
    setTimeout(() => toast.remove(), 300);
  };

  const timer = setTimeout(hide, duration);

  // По клику уведомление закрывается сразу
  toast.addEventListener('click', () => {
    clearTimeout(timer);
    hide();
  });
}

// ==================== МОДАЛЬНЫЕ ОКНА ====================

function openModal(id) {
  const modal = document.getElementById(id);
  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

function closeModal(id) {
  const modal = document.getElementById(id);
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

// Общая логика закрытия для всех окон сразу
document.querySelectorAll('.modal').forEach((modal) => {
  // Клик по затемнённому фону (но не по самому окну)
  modal.addEventListener('mousedown', (event) => {
    if (event.target === modal) closeModal(modal.id);
  });
  // Клик по крестику
  modal.querySelector('.modal-close').addEventListener('click', () => closeModal(modal.id));
});

// Esc закрывает самое верхнее открытое окно
document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  const opened = document.querySelectorAll('.modal:not(.hidden)');
  if (opened.length > 0) {
    closeModal(opened[opened.length - 1].id);
  }
});

// ==================== ИНТЕРФЕЙС ====================

// Обновляет шапку в зависимости от того, вошёл пользователь или нет
function updateUI() {
  const guestButtons = document.getElementById('guestButtons');
  const userButtons = document.getElementById('userButtons');

  if (currentUser) {
    guestButtons.classList.add('hidden');
    guestButtons.classList.remove('flex');
    userButtons.classList.remove('hidden');
    userButtons.classList.add('flex');
    document.getElementById('headerBalance').textContent = formatPrice(currentUser.balance);
  } else {
    guestButtons.classList.remove('hidden');
    guestButtons.classList.add('flex');
    userButtons.classList.add('hidden');
    userButtons.classList.remove('flex');
  }

  updateCartBadge(); // кнопка корзины и счётчик на ней
}

// ==================== ТОВАРЫ ====================

// Загрузка товаров с сервера
async function loadProducts() {
  // При первой загрузке, пока товаров ещё нет, показываем карточки-скелетоны
  if (products.length === 0) {
    renderSkeletons();
  }

  try {
    products = await apiRequest('/products');
    renderProducts();
  } catch (err) {
    document.getElementById('productsGrid').innerHTML =
      '<p class="col-span-full text-center text-red-400 py-10">Не удалось загрузить товары</p>';
    showToast(err.message, 'error');
  }
}

// ---------- Состояние каталога ----------
const PAGE_SIZE = 8;      // товаров на странице
let searchQuery = '';     // текст поиска
let sortMode = 'newest';  // выбранная сортировка
let currentPage = 1;      // текущая страница

// Варианты сортировки: функция сравнения двух товаров
const SORTERS = {
  'newest':        (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
  'price-asc':     (a, b) => a.price - b.price,
  'price-desc':    (a, b) => b.price - a.price,
  'title-asc':     (a, b) => a.title.localeCompare(b.title, 'ru'),
  'title-desc':    (a, b) => b.title.localeCompare(a.title, 'ru'),
  'quantity-desc': (a, b) => b.quantity - a.quantity
};

// Товары после поиска и сортировки (ещё без разбивки на страницы)
function getVisibleProducts() {
  const query = searchQuery.trim().toLowerCase();

  // Поиск по названию и описанию без учёта регистра
  const filtered = query
    ? products.filter((product) =>
        product.title.toLowerCase().includes(query) ||
        (product.description || '').toLowerCase().includes(query))
    : products;

  // Копируем массив ([...]), чтобы сортировка не меняла исходный список
  return [...filtered].sort(SORTERS[sortMode] || SORTERS.newest);
}

// HTML одной карточки товара
function createProductCard(product) {
  const isAdmin = currentUser && currentUser.role === 'admin';
  const isBuyer = currentUser && currentUser.role === 'user';
  const inStock = product.quantity > 0;
  const rarity = getRarity(product);

  const id = escapeHtml(product._id);
  const title = escapeHtml(product.title);
  const description = escapeHtml(product.description);

  // Картинка; если ссылки нет или она не загрузилась — показываем иконку-заглушку
  const placeholder = '<i class="fa-solid fa-image text-4xl text-gray-700"></i>';
  const image = product.imageUrl
    ? `<img src="${escapeHtml(product.imageUrl)}" alt="${title}" loading="lazy"
            class="w-full h-full object-contain p-3"
            onerror="this.replaceWith(Object.assign(document.createElement('i'), { className: 'fa-solid fa-image text-4xl text-gray-700' }))">`
    : placeholder;

  // Рейтинг (данные появятся на шаге 22)
  const rating = ratings[product._id];
  const ratingHtml = rating
    ? `<span class="text-yellow-500"><i class="fa-solid fa-star"></i> ${rating.average}</span>
       <span class="text-gray-500">(${rating.count})</span>`
    : '<span class="text-gray-500">Нет оценок</span>';

  // Сердечко избранного — только для покупателя
  const inWishlist = wishlistIds.has(product._id);
  const heartButton = isBuyer
    ? `<button type="button" data-action="wishlist" data-id="${id}"
               aria-label="${inWishlist ? 'Убрать из избранного' : 'Добавить в избранное'}"
               class="absolute top-2 left-2 w-9 h-9 rounded-full bg-gray-950/70 flex items-center justify-center transition
                      ${inWishlist ? 'text-red-500' : 'text-gray-400 hover:text-red-400'}">
         <i class="${inWishlist ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
       </button>`
    : '';

  // Кнопки редактирования и удаления — только для админа, появляются при наведении
  const adminButtons = isAdmin
    ? `<div class="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition">
         <button type="button" data-action="edit" data-id="${id}" aria-label="Редактировать"
                 class="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white">✎</button>
         <button type="button" data-action="delete" data-id="${id}" aria-label="Удалить"
                 class="w-9 h-9 rounded-full bg-red-600 hover:bg-red-500 text-white">✕</button>
       </div>`
    : '';

  // Кнопки "Купить" и "В корзину" — только для покупателя
  let buyButton = '';
  if (isBuyer) {
    const inCart = isInCart(product._id);
    buyButton = inStock
      ? `<button type="button" data-action="buy" data-id="${id}"
                 class="flex-1 py-2 rounded-lg bg-yellow-500 text-black text-sm font-semibold hover:bg-yellow-400 transition">
           Купить
         </button>
         <button type="button" data-action="cart" data-id="${id}"
                 aria-label="Добавить в корзину" title="${inCart ? 'Уже в корзине — добавить ещё' : 'Добавить в корзину'}"
                 class="shrink-0 w-10 rounded-lg border text-sm transition
                        ${inCart
                          ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500'
                          : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-yellow-500'}">
           <i class="fa-solid ${inCart ? 'fa-check' : 'fa-cart-plus'}"></i>
         </button>`
      : `<button type="button" disabled
                 class="flex-1 py-2 rounded-lg bg-gray-800 text-gray-500 text-sm font-semibold cursor-not-allowed">
           Нет в наличии
         </button>`;
  }

  return `
    <article class="group relative flex flex-col bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/60 transition">
      <div class="relative h-44 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
        ${image}
        ${heartButton}
        ${adminButtons}
        <!-- Цветная полоса редкости -->
        <div class="absolute bottom-0 inset-x-0 h-1" style="background:${rarity.color}"></div>
      </div>
      <div class="flex flex-col flex-1 p-4">
        <h3 class="font-semibold leading-snug">${title}</h3>
        <p class="text-xs font-medium" style="color:${rarity.color}">${rarity.label}</p>
        <p class="mt-1 text-sm">${ratingHtml}</p>
        <p class="mt-2 text-sm text-gray-400 line-clamp-2">${description}</p>
        <div class="mt-auto pt-4 flex items-end justify-between gap-2">
          <p class="text-xl font-bold text-yellow-500">${formatPrice(product.price)} ₽</p>
          <p class="text-xs ${inStock ? 'text-gray-400' : 'text-red-400'}">
            ${inStock ? `В наличии: ${product.quantity}` : 'Нет в наличии'}
          </p>
        </div>
        <div class="mt-3 flex gap-2">
          <button type="button" data-action="reviews" data-id="${id}"
                  class="flex-1 py-2 rounded-lg bg-gray-800 border border-gray-700 text-sm font-medium hover:bg-gray-700 transition">
            💬 Отзывы
          </button>
          ${buyButton}
        </div>
      </div>
    </article>`;
}

// Отрисовка сетки товаров с учётом поиска, сортировки и пагинации
function renderProducts() {
  const grid = document.getElementById('productsGrid');
  const emptyState = document.getElementById('emptyState');
  const isAdmin = currentUser && currentUser.role === 'admin';

  const list = getVisibleProducts();

  // Сколько всего страниц (минимум одна)
  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  // Если текущая страница оказалась за пределами (например, удалили товар) — поправляем.
  // Пока товары не загружены, страницу не трогаем: иначе сбросится номер,
  // восстановленный после обновления вкладки
  if (products.length > 0) {
    currentPage = Math.min(Math.max(1, currentPage), totalPages);
    saveCatalogState();
  }

  // Поиск ничего не нашёл — показываем плашку
  const nothingFound = list.length === 0 && searchQuery.trim() !== '';
  emptyState.classList.toggle('hidden', !nothingFound);
  grid.classList.toggle('hidden', nothingFound);

  if (nothingFound) {
    grid.innerHTML = '';
    renderPagination(1);
    return;
  }

  // Вырезаем товары текущей страницы
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageItems = list.slice(start, start + PAGE_SIZE);

  let html = pageItems.map(createProductCard).join('');

  // Карточка-плюсик для админа — только на последней странице
  if (isAdmin && currentPage === totalPages) {
    html += createAddCard();
  }

  if (!html) {
    html = '<p class="col-span-full text-center text-gray-500 py-10">Товаров пока нет</p>';
  }

  grid.innerHTML = html;
  renderPagination(totalPages);
}

// Один обработчик кликов на всю сетку (делегирование событий).
// По атрибуту data-action определяем, какая кнопка нажата
document.getElementById('productsGrid').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;

  const handler = cardActions[button.dataset.action];
  if (handler) {
    handler(button.dataset.id, button);
  } else {
    showToast('Эта функция появится на следующих шагах', 'info');
  }
});

// ==================== ШАПКА: ЛОГОТИП И "ГЛАВНАЯ" ====================

function goHome(event) {
  if (event) event.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.getElementById('homeBtn').addEventListener('click', goHome);
document.getElementById('logoLink').addEventListener('click', goHome);

// ==================== ЗАПУСК ====================

updateUI();
loadProducts();

// ==================== АВТОРИЗАЦИЯ ====================

// Та же проверка email, что и на сервере: есть @ и точка после неё
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD_LENGTH = 5;

// Блокировка кнопки отправки на время запроса (защита от двойного клика)
function setFormBusy(form, busy) {
  const button = form.querySelector('button[type="submit"]');
  if (!button) return;
  button.disabled = busy;
  button.classList.toggle('opacity-60', busy);
  button.classList.toggle('cursor-not-allowed', busy);
}

// Загрузка id избранных товаров. Вызывается один раз после входа,
// до отрисовки карточек, чтобы сердечки сразу были нужного цвета
async function loadWishlistIds() {
  wishlistIds = new Set();
  if (!currentUser || currentUser.role !== 'user') return;

  try {
    const ids = await apiRequest('/products/wishlist-ids');
    wishlistIds = new Set(ids);
  } catch (err) {
    // не критично: сердечки просто останутся незакрашенными
  }
}

// Вызывается после любого изменения статуса входа:
// подгружает данные пользователя и перерисовывает страницу
async function applyAuthState() {
  await loadWishlistIds();
  updateUI();
  renderProducts();
  renderRoute(); // обновляет текущий экран (например, кнопки админа на экране кейсов)
}

// Проверена ли сессия при загрузке страницы (нужно экрану кабинета)
let sessionChecked = false;

// Восстановление сессии при загрузке страницы:
// если в localStorage есть токен — спрашиваем у сервера, кто мы
async function refreshUser() {
  if (!getToken()) return;
  try {
    currentUser = await apiRequest('/auth/me');
    await applyAuthState();
  } catch (err) {
    // Если токен истёк, apiRequest уже сбросил сессию.
    // Если сервер недоступен — об этом сообщит loadProducts
  } finally {
    sessionChecked = true;
    renderRoute(); // теперь можно показать кабинет, если открыт адрес #profile
  }
}

// ---------- Открытие окон и переключение между ними ----------

document.getElementById('loginBtn').addEventListener('click', () => openModal('loginModal'));
document.getElementById('registerBtn').addEventListener('click', () => openModal('registerModal'));

document.getElementById('toRegisterLink').addEventListener('click', (event) => {
  event.preventDefault();
  closeModal('loginModal');
  openModal('registerModal');
});

document.getElementById('toLoginLink').addEventListener('click', (event) => {
  event.preventDefault();
  closeModal('registerModal');
  openModal('loginModal');
});

// ---------- Регистрация ----------

document.getElementById('registerForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const email = document.getElementById('registerEmail').value.trim();
  const password = document.getElementById('registerPassword').value;
  const confirmPassword = document.getElementById('registerPasswordConfirm').value;

  // Проверки на стороне браузера (сервер проверит ещё раз)
  if (!EMAIL_REGEX.test(email)) {
    return showToast('Введите корректный email (например, name@mail.ru)', 'warning');
  }
  if (password.length < MIN_PASSWORD_LENGTH) {
    return showToast(`Пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`, 'warning');
  }
  if (password !== confirmPassword) {
    return showToast('Пароли не совпадают', 'warning');
  }

  setFormBusy(form, true);
  try {
    await apiRequest('/auth/register', {
      method: 'POST',
      body: { email, password }
    });

    showToast('Регистрация прошла успешно. Теперь войдите в аккаунт', 'success');
    form.reset();

    // Автоматически открываем окно входа с уже подставленным email
    closeModal('registerModal');
    openModal('loginModal');
    document.getElementById('loginEmail').value = email;
    document.getElementById('loginPassword').focus();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ---------- Вход ----------

document.getElementById('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;

  if (!email || !password) {
    return showToast('Введите email и пароль', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/auth/login', {
      method: 'POST',
      body: { email, password }
    });

    // Сохраняем токен и данные пользователя
    localStorage.setItem('token', data.token);
    currentUser = data.user;

    form.reset();
    closeModal('loginModal');
    await applyAuthState();
    showToast(`Вы вошли как ${currentUser.email}`, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ---------- Выход ----------

document.getElementById('logoutBtn').addEventListener('click', () => {
  clearSession();
  // Закрываем все открытые окна
  document.querySelectorAll('.modal:not(.hidden)').forEach((modal) => closeModal(modal.id));
  updateUI();
  renderProducts();
  renderRoute(); // из кабинета возвращаемся в каталог
  showToast('Вы вышли из аккаунта', 'info');
});

// ---------- Смена пароля ----------

document.getElementById('changePasswordBtn').addEventListener('click', () => {
  openModal('changePasswordModal');
});

document.getElementById('changePasswordForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const oldPassword = document.getElementById('oldPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('newPasswordConfirm').value;

  if (!oldPassword || !newPassword) {
    return showToast('Заполните все поля', 'warning');
  }
  if (newPassword.length < MIN_PASSWORD_LENGTH) {
    return showToast(`Новый пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`, 'warning');
  }
  if (newPassword !== confirmPassword) {
    return showToast('Новые пароли не совпадают', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/auth/change-password', {
      method: 'PUT',
      body: { oldPassword, newPassword }
    });

    // Сервер выдал новый токен взамен старого — сохраняем его
    if (data.token) {
      localStorage.setItem('token', data.token);
    }

    form.reset();
    closeModal('changePasswordModal');
    showToast(data.message, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Восстанавливаем сессию при загрузке страницы
refreshUser();

// ==================== ПОКУПКА И ПРОДАЖА ====================

// Доля цены, которую пользователь получает при продаже (как на сервере)
const SELL_RATE = 0.8;

// Звук успешной покупки: три ноты (до, ми, соль пятой октавы).
// Звук генерируется прямо в браузере через Web Audio API, аудиофайл не нужен
let audioContext = null;

function playSuccessSound() {
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return; // браузер не поддерживает Web Audio

    // Аудиоконтекст создаём один раз и переиспользуем
    if (!audioContext) audioContext = new AudioContextClass();
    if (audioContext.state === 'suspended') audioContext.resume();

    const notes = [523.25, 659.25, 783.99]; // частоты C5, E5, G5 в герцах
    const startTime = audioContext.currentTime;

    notes.forEach((frequency, index) => {
      const oscillator = audioContext.createOscillator(); // генератор тона
      const gain = audioContext.createGain();             // регулятор громкости

      oscillator.type = 'sine';
      oscillator.frequency.value = frequency;

      // Каждая нота начинается на 0.12 с позже предыдущей
      const noteStart = startTime + index * 0.12;

      // Плавное нарастание и затухание громкости, чтобы не было щелчков
      gain.gain.setValueAtTime(0.0001, noteStart);
      gain.gain.exponentialRampToValueAtTime(0.2, noteStart + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.25);

      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start(noteStart);
      oscillator.stop(noteStart + 0.3);
    });
  } catch (err) {
    // звук — необязательная мелочь, ошибки здесь игнорируем
  }
}

// Покупка товара. Вызывается по клику на кнопку "Купить" в карточке
async function handleBuyProduct(productId, button) {
  if (!currentUser) {
    return showToast('Войдите в аккаунт, чтобы покупать', 'warning');
  }

  const product = products.find((item) => item._id === productId);
  if (!product) return;

  // Предварительная проверка баланса (сервер всё равно проверит сам)
  if (currentUser.balance < product.price) {
    return showToast('Недостаточно средств на балансе', 'warning');
  }

  const confirmedBuy = await confirmDialog({
    title: 'Покупка',
    message: `Купить «${product.title}» за ${formatPrice(product.price)} ₽?`,
    confirmText: 'Купить'
  });
  if (!confirmedBuy) return;

  // Блокируем кнопку, чтобы нельзя было купить дважды двойным кликом
  if (button) button.disabled = true;

  try {
    const data = await apiRequest(`/products/${productId}/buy`, { method: 'POST' });

    // Сервер вернул новый баланс — обновляем его у себя
    currentUser.balance = data.balance;
    // Уменьшаем остаток на витрине без повторной загрузки всех товаров
    product.quantity = Math.max(0, product.quantity - 1);

    updateUI();
    renderProducts();
    playSuccessSound();
    showToast(
      `${data.message}. Остаток на балансе: ${formatPrice(data.balance)} ₽`,
      'success',
      5000 // уведомление о покупке висит дольше обычного
    );
  } catch (err) {
    showToast(err.message, 'error');
    // Данные на странице могли устареть (например, товар раскупили) — перезагружаем
    loadProducts();
  }
}

// Продажа купленного предмета за 80% цены.
// Принимает объект покупки, возвращает true при успехе.
// Кнопка "Продать" появится в личном кабинете на шаге 14
async function handleSellProduct(purchase) {
  const refund = Math.floor(purchase.price * SELL_RATE);

  const confirmedSell = await confirmDialog({
    title: 'Продажа',
    message: `Продать «${purchase.productTitle}» за ${formatPrice(refund)} ₽? Это 80% от цены покупки.`,
    confirmText: 'Продать'
  });
  if (!confirmedSell) return false;

  try {
    const data = await apiRequest(`/products/sell/${purchase._id}`, { method: 'POST' });

    currentUser.balance = data.balance;
    updateUI();
    // Товар вернулся на витрину — обновляем остатки
    loadProducts();
    showToast(data.message, 'success');
    return true;
  } catch (err) {
    showToast(err.message, 'error');
    return false;
  }
}

// Подключаем покупку к кнопке "Купить" на карточках
cardActions.buy = handleBuyProduct;

// ==================== ЛИЧНЫЙ КАБИНЕТ ====================

let myPurchases = []; // история покупок текущего пользователя

// Формат даты: 02.10.2026, 17:51
function formatDate(value) {
  return new Date(value).toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Заполняет поля личного кабинета данными текущего пользователя
function fillProfile() {
  if (!currentUser) return;
  const isAdmin = currentUser.role === 'admin';

  document.getElementById('profileEmail').textContent = currentUser.email;
  document.getElementById('profileRole').textContent = isAdmin ? 'Администратор' : 'Покупатель';
  document.getElementById('profileBalance').textContent = formatPrice(currentUser.balance);

  // Панель администратора — только для админа
  document.getElementById('adminSection').classList.toggle('hidden', !isAdmin);

  // Админ не покупает, поэтому покупки и избранное ему не показываем
  document.getElementById('purchasesSection').classList.toggle('hidden', isAdmin);
  document.getElementById('wishlistSection').classList.toggle('hidden', isAdmin);
}

// Загрузка и отрисовка избранного в личном кабинете
async function loadWishlist() {
  const list = document.getElementById('wishlistList');
  list.innerHTML = '<p class="text-sm text-gray-500">Загрузка…</p>';

  let items;
  try {
    items = await apiRequest('/products/my-wishlist');
  } catch (err) {
    list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить избранное</p>';
    return;
  }

  if (items.length === 0) {
    list.innerHTML = '<p class="text-sm text-gray-500">В избранном пока пусто</p>';
    return;
  }

  list.innerHTML = items.map((item) => {
    const image = item.imageUrl
      ? `<img src="${escapeHtml(item.imageUrl)}" alt="" class="w-full h-full object-contain" onerror="this.remove()">`
      : '<i class="fa-solid fa-image text-gray-600"></i>';

    return `
      <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-3">
        <div class="w-12 h-12 shrink-0 rounded bg-gray-900 flex items-center justify-center overflow-hidden">
          ${image}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium truncate">${escapeHtml(item.title)}</p>
          <p class="text-xs text-gray-400">
            ${formatPrice(item.price)} ₽ ·
            ${item.quantity > 0 ? `в наличии: ${item.quantity}` : '<span class="text-red-400">нет в наличии</span>'}
          </p>
        </div>
        <button type="button" data-wishlist-remove="${escapeHtml(item._id)}"
                class="shrink-0 w-9 h-9 rounded-full bg-gray-900 text-red-500 hover:bg-gray-700 transition"
                title="Убрать из избранного" aria-label="Убрать из избранного">
          <i class="fa-solid fa-heart"></i>
        </button>
      </div>`;
  }).join('');
}

let purchaseFilter = 'all'; // какой список показываем: all | active | sold

// Сводка по инвентарю: количество, стоимость, потрачено, получено
function renderInventorySummary() {
  const active = myPurchases.filter((purchase) => purchase.status === 'active');
  const sold = myPurchases.filter((purchase) => purchase.status === 'sold');
  const sum = (list, getValue) => list.reduce((total, item) => total + getValue(item), 0);

  document.getElementById('invCount').textContent = active.length;
  document.getElementById('invValue').textContent = formatPrice(sum(active, (p) => p.price));
  // Для предметов из кейсов считаем цену кейса (paid), а не стоимость предмета
  document.getElementById('invSpent').textContent =
    formatPrice(sum(myPurchases, (p) => (p.paid ?? p.price)));
  document.getElementById('invEarned').textContent =
    formatPrice(sum(sold, (p) => Math.floor(p.price * SELL_RATE)));
}

// Отрисовка списка покупок с учётом выбранного фильтра
function renderPurchases() {
  const list = document.getElementById('purchasesList');

  // Подсветка активной кнопки фильтра
  document.querySelectorAll('#purchaseFilters [data-purchase-filter]').forEach((button) => {
    const active = button.dataset.purchaseFilter === purchaseFilter;
    button.classList.toggle('bg-yellow-500', active);
    button.classList.toggle('text-black', active);
    button.classList.toggle('bg-gray-800', !active);
    button.classList.toggle('text-gray-300', !active);
  });

  const items = purchaseFilter === 'all'
    ? myPurchases
    : myPurchases.filter((purchase) => purchase.status === purchaseFilter);

  if (items.length === 0) {
    const emptyText = {
      all: 'Покупок пока нет',
      active: 'В инвентаре пусто',
      sold: 'Проданных предметов нет'
    }[purchaseFilter];
    list.innerHTML = `<p class="col-span-full text-sm text-gray-500">${emptyText}</p>`;
    return;
  }

  list.innerHTML = items.map((purchase) => {
    const image = purchase.productImage
      ? `<img src="${escapeHtml(purchase.productImage)}" alt="" class="w-full h-full object-contain" onerror="this.remove()">`
      : '<i class="fa-solid fa-image text-gray-600"></i>';

    // Справа — кнопка продажи или плашка "ПРОДАНО"
    const action = purchase.status === 'active'
      ? `<button type="button" data-sell-id="${escapeHtml(purchase._id)}"
                 class="shrink-0 px-3 py-1.5 rounded-lg bg-green-600 text-xs font-semibold hover:bg-green-500 transition">
           Продать за ${formatPrice(Math.floor(purchase.price * SELL_RATE))} ₽
         </button>`
      : '<span class="shrink-0 px-3 py-1.5 rounded-lg bg-gray-700 text-xs font-semibold text-gray-400">ПРОДАНО</span>';

    return `
      <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-3">
        <div class="w-12 h-12 shrink-0 rounded bg-gray-900 flex items-center justify-center overflow-hidden">
          ${image}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium truncate">${escapeHtml(purchase.productTitle)}</p>
          <p class="text-xs text-gray-400">
            ${formatPrice(purchase.price)} ₽ · ${formatDate(purchase.purchasedAt)}${purchase.source === 'case' ? ' · из кейса' : ''}
          </p>
        </div>
        ${action}
      </div>`;
  }).join('');
}

// Загрузка истории покупок с сервера
async function loadPurchases() {
  const list = document.getElementById('purchasesList');
  list.innerHTML = '<p class="col-span-full text-sm text-gray-500">Загрузка…</p>';

  try {
    myPurchases = await apiRequest('/products/my-purchases');
  } catch (err) {
    list.innerHTML = '<p class="col-span-full text-sm text-red-400">Не удалось загрузить покупки</p>';
    return;
  }

  renderInventorySummary();
  renderPurchases();
}

// Переход в личный кабинет (кнопка в шапке)
function openProfileModal() {
  if (!currentUser) return;
  location.hash = '#profile';
}

// Загрузка данных для экрана кабинета. Вызывается при каждом его открытии
async function loadProfilePage() {
  if (!currentUser) return;

  // Сразу показываем то, что знаем
  fillProfile();

  // Затем подтягиваем свежие данные с сервера
  try {
    currentUser = await apiRequest('/auth/me');
    fillProfile();
    updateUI();
  } catch (err) {
    showToast(err.message, 'error');
    return;
  }

  if (currentUser.role === 'user') {
    loadPurchases();
    loadWishlist();
  } else if (currentUser.role === 'admin') {
    loadAdminPanel();
  }

  loadHistory(true);
}

document.getElementById('profileBtn').addEventListener('click', openProfileModal);

// Клик по кнопке "Продать" в истории покупок (делегирование)
document.getElementById('purchasesList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-sell-id]');
  if (!button) return;

  const purchase = myPurchases.find((item) => item._id === button.dataset.sellId);
  if (!purchase) return;

  button.disabled = true;
  const sold = await handleSellProduct(purchase);
  if (sold) {
    fillProfile();   // обновляем баланс в кабинете
    loadPurchases(); // перерисовываем список — появится плашка "ПРОДАНО"
    loadHistory(true); // в истории появится запись о продаже
  } else {
    button.disabled = false;
  }
});

// ==================== ПОПОЛНЕНИЕ БАЛАНСА ====================

const MAX_DEPOSIT = 1000000;

document.getElementById('depositBtn').addEventListener('click', () => {
  document.getElementById('depositForm').reset();
  openModal('depositModal');
});

// Быстрые кнопки подставляют сумму в поле ввода
document.querySelectorAll('.deposit-quick').forEach((button) => {
  button.addEventListener('click', () => {
    document.getElementById('depositAmount').value = button.dataset.amount;
  });
});

document.getElementById('depositForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const amount = Number(document.getElementById('depositAmount').value);

  if (!Number.isInteger(amount) || amount <= 0) {
    return showToast('Введите сумму целым положительным числом', 'warning');
  }
  if (amount > MAX_DEPOSIT) {
    return showToast(`Максимальная сумма пополнения — ${formatPrice(MAX_DEPOSIT)} ₽`, 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/auth/deposit', {
      method: 'POST',
      body: { amount }
    });

    currentUser.balance = data.balance;
    updateUI();
    fillProfile();
    closeModal('depositModal');
    showToast(`Баланс пополнен на ${formatPrice(amount)} ₽`, 'success');
    loadHistory(true);
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== АДМИН: УПРАВЛЕНИЕ ТОВАРАМИ ====================

// Карточка-плюсик "Добавить товар"
function createAddCard() {
  return `
    <button type="button" data-action="add"
            class="min-h-[20rem] flex flex-col items-center justify-center gap-3 rounded-xl
                   border-2 border-dashed border-gray-700 text-gray-500
                   hover:border-yellow-500 hover:text-yellow-500 transition">
      <i class="fa-solid fa-plus text-4xl"></i>
      <span class="font-semibold">Добавить товар</span>
    </button>`;
}

// Открытие окна товара.
// Без аргумента — режим добавления, с товаром — режим редактирования
function openProductModal(product = null) {
  document.getElementById('productForm').reset();

  document.getElementById('productModalTitle').textContent =
    product ? 'Редактировать товар' : 'Добавить товар';
  document.getElementById('productSubmitBtn').textContent =
    product ? 'Сохранить изменения' : 'Добавить';

  // Скрытое поле: пусто = добавление, id = редактирование
  document.getElementById('productId').value = product ? product._id : '';

  if (product) {
    document.getElementById('productTitle').value = product.title;
    document.getElementById('productDescription').value = product.description || '';
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productQuantity').value = product.quantity;
    document.getElementById('productImageUrl').value = product.imageUrl || '';
    document.getElementById('productRarity').value = getRarity(product).key;
  }

  updateImagePreview(); // показываем картинку редактируемого товара
  openModal('productModal');
}

// Сохранение товара (и добавление, и редактирование)
document.getElementById('productForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const productId = document.getElementById('productId').value;
  const title = document.getElementById('productTitle').value.trim();
  const description = document.getElementById('productDescription').value.trim();
  const priceRaw = document.getElementById('productPrice').value.trim();
  const quantityRaw = document.getElementById('productQuantity').value.trim();
  const imageUrl = document.getElementById('productImageUrl').value.trim();

  const price = Number(priceRaw);
  const quantity = Number(quantityRaw);

  // Проверки на стороне браузера (сервер проверит ещё раз)
  if (!title) {
    return showToast('Введите название товара', 'warning');
  }
  if (priceRaw === '' || !Number.isFinite(price) || price < 0) {
    return showToast('Цена должна быть неотрицательным числом', 'warning');
  }
  if (quantityRaw === '' || !Number.isInteger(quantity) || quantity < 0) {
    return showToast('Количество должно быть целым неотрицательным числом', 'warning');
  }
  if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
    return showToast('Ссылка на картинку должна начинаться с http:// или https://', 'warning');
  }

  setFormBusy(form, true);
  try {
    await apiRequest(productId ? `/products/${productId}` : '/products', {
      method: productId ? 'PUT' : 'POST',
      body: {
        title, description, price, quantity, imageUrl,
        rarity: document.getElementById('productRarity').value
      }
    });

    closeModal('productModal');
    await loadProducts();
    showToast(productId ? 'Товар обновлён' : 'Товар добавлен', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Удаление товара
async function handleDeleteProduct(productId) {
  const product = products.find((item) => item._id === productId);
  if (!product) return;

  const confirmedDelete = await confirmDialog({
    title: 'Удаление товара',
    message: `Удалить товар «${product.title}»? Это действие нельзя отменить.`,
    confirmText: 'Удалить',
    danger: true
  });
  if (!confirmedDelete) return;

  try {
    await apiRequest(`/products/${productId}`, { method: 'DELETE' });

    // Убираем товар из локального списка и перерисовываем сетку
    products = products.filter((item) => item._id !== productId);
    renderProducts();
    showToast('Товар удалён', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Подключаем действия к кнопкам на карточках
cardActions.add = () => openProductModal();
cardActions.edit = (productId) => {
  const product = products.find((item) => item._id === productId);
  if (product) openProductModal(product);
};
cardActions.delete = handleDeleteProduct;

// ==================== АДМИН: СТАТИСТИКА ====================

// Отрисовка списка в блоке статистики.
// items — массив данных, renderRow — функция, которая превращает элемент в HTML строки
function renderStatsList(containerId, items, renderRow) {
  const container = document.getElementById(containerId);
  container.innerHTML = items.length > 0
    ? items.map(renderRow).join('')
    : '<p class="text-gray-500">Нет данных</p>';
}

// Загрузка статистики для панели администратора
async function loadStats() {
  let stats;
  try {
    stats = await apiRequest('/products/admin/stats');
  } catch (err) {
    showToast(err.message, 'error');
    return;
  }

  // 4 карточки метрик
  document.getElementById('statRevenue').textContent = formatPrice(stats.totalRevenue);
  document.getElementById('statSales').textContent = formatPrice(stats.totalSales);
  document.getElementById('statUsers').textContent = formatPrice(stats.totalUsers);
  document.getElementById('statProducts').textContent = formatPrice(stats.totalProducts);

  // Топ-5 покупателей
  renderStatsList('topBuyersList', stats.topBuyers, (buyer, index) => `
    <div class="flex items-center justify-between gap-2">
      <span class="truncate"><span class="text-gray-500">${index + 1}.</span> ${escapeHtml(buyer.email)}</span>
      <span class="shrink-0 text-right">
        <span class="font-semibold text-yellow-500">${formatPrice(buyer.totalSpent)} ₽</span>
        <span class="text-xs text-gray-500">(${buyer.purchasesCount})</span>
      </span>
    </div>`);

  // Топ-5 товаров
  renderStatsList('topProductsList', stats.topProducts, (product, index) => `
    <div class="flex items-center justify-between gap-2">
      <span class="truncate"><span class="text-gray-500">${index + 1}.</span> ${escapeHtml(product.title)}</span>
      <span class="shrink-0 font-semibold">${product.salesCount} шт.</span>
    </div>`);

  // Заканчивающиеся товары
  renderStatsList('lowStockList', stats.lowStock, (product) => `
    <div class="flex items-center justify-between gap-2">
      <span class="truncate">${escapeHtml(product.title)}</span>
      <span class="shrink-0 font-semibold ${product.quantity === 0 ? 'text-red-400' : 'text-yellow-500'}">
        ${product.quantity} шт.
      </span>
    </div>`);
}

// ==================== АДМИН: ГРАФИК ПРОДАЖ ====================

let salesChart = null;        // текущий экземпляр графика
let chartData = [];           // данные за 30 дней: [{ date, revenue, count }]
let chartMode = 'revenue';    // что показываем: 'revenue' (выручка) или 'count' (кол-во)

// Настройки двух режимов графика
const CHART_MODES = {
  revenue: { label: 'Оборот', color: '234, 179, 8', unit: ' ₽' },          // жёлтый
  profit:  { label: 'Чистая прибыль', color: '34, 197, 94', unit: ' ₽' },  // зелёный
  count:   { label: 'Покупок', color: '59, 130, 246', unit: ' шт.' }       // синий
};

// Подсветка активной кнопки переключателя
function updateChartButtons() {
  document.querySelectorAll('[data-chart-mode]').forEach((button) => {
    const active = button.dataset.chartMode === chartMode;
    button.classList.toggle('bg-yellow-500', active);
    button.classList.toggle('text-black', active);
    button.classList.toggle('bg-gray-700', !active);
    button.classList.toggle('text-gray-200', !active);
  });
}

// Отрисовка графика по уже загруженным данным
function renderSalesChart() {
  if (typeof Chart === 'undefined') {
    return showToast('Библиотека Chart.js не загрузилась. Проверьте интернет', 'warning');
  }

  const mode = CHART_MODES[chartMode];
  const canvas = document.getElementById('salesChart');

  // Подписи по оси X: "2026-10-02" -> "02.10"
  const labels = chartData.map((day) => {
    const [, month, date] = day.date.split('-');
    return `${date}.${month}`;
  });
  const values = chartData.map((day) => day[chartMode]);

  // Перед созданием нового графика удаляем старый, иначе они наложатся
  if (salesChart) {
    salesChart.destroy();
  }

  salesChart = new Chart(canvas, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: mode.label,
        data: values,
        borderColor: `rgb(${mode.color})`,
        borderWidth: 2,
        tension: 0.35,          // сглаживание линии
        pointRadius: 2,
        pointHoverRadius: 5,
        pointBackgroundColor: `rgb(${mode.color})`,
        fill: true,
        // Градиент под линией: сверху цвет плотнее, снизу прозрачный
        backgroundColor: (context) => {
          const { ctx, chartArea } = context.chart;
          if (!chartArea) return `rgba(${mode.color}, 0.15)`; // график ещё не размечен
          const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
          gradient.addColorStop(0, `rgba(${mode.color}, 0.45)`);
          gradient.addColorStop(1, `rgba(${mode.color}, 0)`);
          return gradient;
        }
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false, // высоту задаёт контейнер (h-72)
      interaction: { mode: 'index', intersect: false }, // тултип по наведению на столбец дня
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#111827',
          borderColor: '#374151',
          borderWidth: 1,
          padding: 10,
          callbacks: {
            // Заголовок тултипа — полная дата
            title: (items) => {
              const [year, month, date] = chartData[items[0].dataIndex].date.split('-');
              return `${date}.${month}.${year}`;
            },
            // Текст тултипа — значение с единицей измерения
            label: (item) => i18n.tr(`${mode.label}: ${formatPrice(item.parsed.y)}${mode.unit}`)
          }
        }
      },
      scales: {
        x: {
          ticks: { color: '#9ca3af', maxTicksLimit: 10 },
          grid: { color: 'rgba(55, 65, 81, 0.4)' }
        },
        y: {
          beginAtZero: true,
          ticks: {
            color: '#9ca3af',
            precision: 0, // только целые деления
            callback: (value) => formatPrice(value)
          },
          grid: { color: 'rgba(55, 65, 81, 0.4)' }
        }
      }
    }
  });
}

// Загрузка данных графика с сервера и отрисовка
async function loadSalesChart() {
  try {
    chartData = await apiRequest('/products/admin/chart-data');
    updateChartButtons();
    renderSalesChart();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Переключатель режимов графика: оборот / чистая прибыль / количество
document.querySelectorAll('[data-chart-mode]').forEach((button) => {
  button.addEventListener('click', () => {
    chartMode = button.dataset.chartMode;
    updateChartButtons();
    renderSalesChart();
  });
});

// ==================== АДМИН: ЭКСПОРТ В CSV ====================

// Подготовка одного значения для CSV-ячейки
function escapeCsvValue(value) {
  let text = String(value ?? '');

  // Защита от формул: если текст начинается с = + - @, Excel может выполнить его
  // как формулу. Апостроф в начале заставляет Excel считать ячейку обычным текстом
  if (typeof value === 'string' && /^[=+\-@]/.test(text)) {
    text = "'" + text;
  }

  // Если в значении есть разделитель, кавычки или перенос строки —
  // оборачиваем в кавычки, а кавычки внутри удваиваем
  if (/[;"\n\r]/.test(text)) {
    text = '"' + text.replace(/"/g, '""') + '"';
  }

  return text;
}

// Выгрузка всех покупок в CSV-файл
async function exportPurchasesCsv() {
  const button = document.getElementById('exportCsvBtn');
  button.disabled = true;

  try {
    const purchases = await apiRequest('/products/admin/purchases');

    if (purchases.length === 0) {
      return showToast('Покупок пока нет — выгружать нечего', 'info');
    }

    // Первая строка — заголовки столбцов
    const rows = [
      ['№', 'Покупатель', 'Товар', 'Цена, ₽', 'Статус', 'Дата покупки', 'Дата продажи'].map(i18n.tr)
    ];

    purchases.forEach((purchase, index) => {
      rows.push([
        index + 1,
        purchase.userEmail,
        purchase.productTitle,
        purchase.price,
        i18n.tr(purchase.status === 'sold' ? 'Продано' : 'Активно'),
        formatDate(purchase.purchasedAt),
        purchase.soldAt ? formatDate(purchase.soldAt) : ''
      ]);
    });

    // Собираем текст файла: ячейки через ";", строки через перенос.
    // \uFEFF в начале — метка BOM, по ней Excel понимает, что файл в UTF-8,
    // и правильно показывает русские буквы
    const csv = '\uFEFF' + rows
      .map((row) => row.map(escapeCsvValue).join(';'))
      .join('\r\n');

    // Имя файла с сегодняшней датой: musorshop-purchases-2026-10-02.csv
    const now = new Date();
    const dateStamp = [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, '0'),
      String(now.getDate()).padStart(2, '0')
    ].join('-');
    const fileName = `musorshop-purchases-${dateStamp}.csv`;

    // Создаём файл в памяти браузера и "нажимаем" на временную ссылку для скачивания
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url); // освобождаем память

    showToast(`Файл ${fileName} сохранён (строк: ${purchases.length})`, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    button.disabled = false;
  }
}

document.getElementById('exportCsvBtn').addEventListener('click', exportPurchasesCsv);

// ==================== ПОИСК, СОРТИРОВКА, ПАГИНАЦИЯ ====================

// Какие номера страниц показывать: первая, последняя и соседи текущей.
// Пропуски заменяются на "...". Пример: (20, 6) -> [1, '...', 5, 6, 7, '...', 20]
function getPageNumbers(totalPages, page) {
  const wanted = new Set([1, totalPages, page - 1, page, page + 1]);
  const pages = [...wanted]
    .filter((number) => number >= 1 && number <= totalPages)
    .sort((a, b) => a - b);

  const result = [];
  pages.forEach((number, index) => {
    if (index > 0) {
      const gap = number - pages[index - 1];
      if (gap === 2) {
        result.push(number - 1); // пропущена одна страница — показываем её, а не "..."
      } else if (gap > 2) {
        result.push('...');
      }
    }
    result.push(number);
  });
  return result;
}

// Отрисовка кнопок пагинации
function renderPagination(totalPages) {
  const container = document.getElementById('pagination');

  // Одна страница — пагинация не нужна
  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  const baseClass = 'min-w-[2.5rem] px-3 py-2 rounded-lg text-sm font-medium transition';
  const normalClass = 'bg-gray-900 border border-gray-800 text-gray-300 hover:border-yellow-500';
  const activeClass = 'bg-yellow-500 text-black';
  const disabledClass = 'bg-gray-900 border border-gray-800 text-gray-600 cursor-not-allowed';

  const isFirst = currentPage === 1;
  const isLast = currentPage === totalPages;

  let html = `
    <button type="button" data-page="${currentPage - 1}" ${isFirst ? 'disabled' : ''}
            class="${baseClass} ${isFirst ? disabledClass : normalClass}">← Назад</button>`;

  getPageNumbers(totalPages, currentPage).forEach((item) => {
    if (item === '...') {
      html += '<span class="px-2 text-gray-500">…</span>';
    } else {
      html += `
        <button type="button" data-page="${item}" ${item === currentPage ? 'aria-current="page"' : ''}
                class="${baseClass} ${item === currentPage ? activeClass : normalClass}">${item}</button>`;
    }
  });

  html += `
    <button type="button" data-page="${currentPage + 1}" ${isLast ? 'disabled' : ''}
            class="${baseClass} ${isLast ? disabledClass : normalClass}">Вперёд →</button>`;

  container.innerHTML = html;
}

// Переход на страницу по клику (делегирование)
document.getElementById('pagination').addEventListener('click', (event) => {
  const button = event.target.closest('[data-page]');
  if (!button || button.disabled) return;

  currentPage = Number(button.dataset.page);
  renderProducts();

  // Плавно прокручиваем к началу сетки (с отступом под закреплённую шапку)
  const grid = document.getElementById('productsGrid');
  const top = grid.getBoundingClientRect().top + window.scrollY - 100;
  window.scrollTo({ top, behavior: 'smooth' });
});

// Дебаунс: функция вызывается только после паузы в delay мс.
// Благодаря этому поиск не запускается на каждую набранную букву
function debounce(fn, delay) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// Поиск с задержкой 300 мс
document.getElementById('searchInput').addEventListener('input', debounce((event) => {
  searchQuery = event.target.value;
  currentPage = 1; // при новом запросе возвращаемся на первую страницу
  renderProducts();
}, 300));

// Смена сортировки
document.getElementById('sortSelect').addEventListener('change', (event) => {
  sortMode = event.target.value;
  currentPage = 1;
  renderProducts();
});

// Кнопка "Главная" и логотип сбрасывают поиск, сортировку и страницу
function resetCatalog() {
  searchQuery = '';
  sortMode = 'newest';
  currentPage = 1;
  document.getElementById('searchInput').value = '';
  document.getElementById('sortSelect').value = 'newest';
  renderProducts();
}

document.getElementById('homeBtn').addEventListener('click', resetCatalog);
document.getElementById('logoLink').addEventListener('click', resetCatalog);

// ==================== ИЗБРАННОЕ ====================

// Добавить товар в избранное или убрать из него. Возвращает true при успехе
async function toggleWishlist(productId, button) {
  if (!currentUser) {
    showToast('Войдите в аккаунт, чтобы пользоваться избранным', 'warning');
    return false;
  }

  const inWishlist = wishlistIds.has(productId);
  if (button) button.disabled = true;

  try {
    await apiRequest(`/products/wishlist/${productId}`, {
      method: inWishlist ? 'DELETE' : 'POST'
    });

    // Обновляем локальный набор id и перерисовываем карточки — сердечко сменит цвет
    if (inWishlist) {
      wishlistIds.delete(productId);
    } else {
      wishlistIds.add(productId);
    }
    renderProducts();

    showToast(
      inWishlist ? 'Удалено из избранного' : 'Добавлено в избранное',
      inWishlist ? 'info' : 'success'
    );
    return true;
  } catch (err) {
    showToast(err.message, 'error');
    if (button) button.disabled = false;
    return false;
  }
}

// Сердечко на карточке товара
cardActions.wishlist = toggleWishlist;

// Кнопка-сердечко в списке избранного в личном кабинете
document.getElementById('wishlistList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-wishlist-remove]');
  if (!button) return;

  const done = await toggleWishlist(button.dataset.wishlistRemove, button);
  if (done) loadWishlist();
});

// ==================== ОТЗЫВЫ И РЕЙТИНГИ ====================

let reviewProductId = null;  // товар, отзывы которого сейчас открыты
let currentReviews = [];     // загруженные отзывы этого товара
let selectedRating = 0;      // выбранная в форме оценка (0 = не выбрана)
let editingReviewId = null;  // id редактируемого отзыва (null = пишем новый)

// Загрузка средних рейтингов всех товаров и перерисовка карточек
async function loadRatings() {
  try {
    ratings = await apiRequest('/products/ratings/all');
    renderProducts();
  } catch (err) {
    // не критично: на карточках останется "Нет оценок"
  }
}

// Подсветка звёзд в форме: первые value звёзд жёлтые, остальные серые
function setStarRating(value) {
  selectedRating = value;
  document.querySelectorAll('#starRating .star').forEach((star) => {
    const active = Number(star.dataset.star) <= value;
    star.classList.toggle('text-yellow-500', active);
    star.classList.toggle('text-gray-600', !active);
  });
}

// HTML пяти звёзд для показа оценки в отзыве
function renderStars(rating) {
  let html = '';
  for (let i = 1; i <= 5; i++) {
    html += `<i class="fa-solid fa-star ${i <= rating ? 'text-yellow-500' : 'text-gray-600'}"></i>`;
  }
  return html;
}

// Кнопка "Отмена" для режима редактирования — создаём один раз и добавляем в форму
const cancelEditBtn = document.createElement('button');
cancelEditBtn.type = 'button';
cancelEditBtn.textContent = 'Отмена';
cancelEditBtn.className =
  'hidden w-full py-2.5 rounded-lg bg-gray-800 border border-gray-700 font-medium hover:bg-gray-700 transition';
document.getElementById('reviewForm').appendChild(cancelEditBtn);

// Возврат формы в исходное состояние (режим "новый отзыв")
function resetReviewForm() {
  const form = document.getElementById('reviewForm');
  editingReviewId = null;
  form.reset();
  setStarRating(0);
  form.querySelector('button[type="submit"]').textContent = 'Оставить отзыв';
  cancelEditBtn.classList.add('hidden');
}

// Есть ли открытый товар в истории покупок текущего пользователя
let reviewPurchased = false;

// Показывать ли форму:
// - в режиме редактирования — всегда;
// - иначе только покупателю, который купил товар и ещё не оставлял на него отзыв
function updateReviewFormVisibility() {
  const isBuyer = currentUser && currentUser.role === 'user';
  const alreadyReviewed = isBuyer &&
    currentReviews.some((review) => String(review.userId) === String(currentUser.id));

  const canWrite = isBuyer && !alreadyReviewed && reviewPurchased;
  const visible = editingReviewId !== null || canWrite;
  document.getElementById('reviewFormWrapper').classList.toggle('hidden', !visible);

  // Покупателю, который товар не покупал, объясняем, почему формы нет
  const showHint = isBuyer && !alreadyReviewed && !reviewPurchased && editingReviewId === null;
  document.getElementById('reviewHint').classList.toggle('hidden', !showHint);
}

// Может ли текущий пользователь менять и удалять этот отзыв
function canManageReview(review) {
  if (!currentUser) return false;
  return currentUser.role === 'admin' || String(review.userId) === String(currentUser.id);
}

// Загрузка и отрисовка отзывов открытого товара
async function loadReviews() {
  const list = document.getElementById('reviewsList');
  list.innerHTML = '<p class="text-sm text-gray-500">Загрузка…</p>';

  let data;
  try {
    data = await apiRequest(`/products/${reviewProductId}/reviews`);
  } catch (err) {
    list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить отзывы</p>';
    return;
  }

  currentReviews = data.reviews;

  
  // Узнаём у сервера, покупал ли текущий пользователь этот товар
  reviewPurchased = false;
  if (currentUser && currentUser.role === 'user') {
    try {
      const permission = await apiRequest(`/products/${reviewProductId}/can-review`);
      reviewPurchased = permission.purchased;
    } catch (err) {
      // не удалось узнать — форму не показываем, сервер всё равно проверит сам
    }
  }

  // Средний рейтинг и количество
  document.getElementById('reviewsAverage').textContent = data.count > 0 ? data.average : '—';
  document.getElementById('reviewsCount').textContent = data.count;

  updateReviewFormVisibility();

  if (data.count === 0) {
    list.innerHTML = '<p class="text-sm text-gray-500">Отзывов пока нет</p>';
    return;
  }

  list.innerHTML = currentReviews.map((review) => {
    const id = escapeHtml(review.id);

    // Кнопки управления — автору отзыва и админу
    const actions = canManageReview(review)
      ? `<span class="shrink-0 flex gap-1">
           <button type="button" data-review-edit="${id}" title="Изменить" aria-label="Изменить отзыв"
                   class="w-7 h-7 rounded bg-gray-700 text-xs text-blue-400 hover:bg-gray-600">✎</button>
           <button type="button" data-review-delete="${id}" title="Удалить" aria-label="Удалить отзыв"
                   class="w-7 h-7 rounded bg-gray-700 text-xs text-red-400 hover:bg-gray-600">✕</button>
         </span>`
      : '';

    // Пометка об изменении
    const edited = review.editedAt
      ? ` · ${review.editedByAdmin ? 'изменено администратором' : 'изменено'}`
      : '';

    return `
      <div class="bg-gray-800 rounded-lg p-3">
        <div class="flex items-center justify-between gap-2">
          <span class="min-w-0 flex flex-wrap items-center gap-2">
            <span class="text-sm font-medium truncate">${escapeHtml(review.userEmail)}</span>
            ${review.verified
              ? '<span class="px-2 py-0.5 rounded bg-green-600/20 text-green-500 text-xs font-medium">✔ Проверенная покупка</span>'
              : ''}
          </span>
          <span class="shrink-0 flex items-center gap-2">
            <span class="text-xs">${renderStars(review.rating)}</span>
            ${actions}
          </span>
        </div>
        ${review.comment
          ? `<p class="mt-2 text-sm text-gray-300 break-words">${escapeHtml(review.comment)}</p>`
          : ''}
        <p class="mt-2 text-xs text-gray-500">${formatDate(review.createdAt)}${edited}</p>
      </div>`;
  }).join('');
}

// Открытие окна отзывов по кнопке "💬 Отзывы" на карточке
function openReviewsModal(productId) {
  const product = products.find((item) => item._id === productId);
  if (!product) return;

  reviewProductId = productId;
  currentReviews = [];
  document.getElementById('reviewsProductTitle').textContent = product.title;

  resetReviewForm();
  openModal('reviewsModal');
  loadReviews();
}

// Переход в режим редактирования: подставляем данные отзыва в форму
function startEditReview(reviewId) {
  const review = currentReviews.find((item) => String(item.id) === reviewId);
  if (!review) return;

  const form = document.getElementById('reviewForm');
  editingReviewId = reviewId;
  setStarRating(review.rating);
  document.getElementById('reviewComment').value = review.comment || '';
  form.querySelector('button[type="submit"]').textContent = 'Сохранить изменения';
  cancelEditBtn.classList.remove('hidden');

  updateReviewFormVisibility();
  form.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Удаление отзыва
async function deleteReview(reviewId) {
  const confirmedDelete = await confirmDialog({
    title: 'Удаление отзыва',
    message: 'Удалить этот отзыв? Это действие нельзя отменить.',
    confirmText: 'Удалить',
    danger: true
  });
  if (!confirmedDelete) return;

  try {
    const data = await apiRequest(`/products/reviews/${reviewId}`, { method: 'DELETE' });
    showToast(data.message, 'success');

    // Если удалили отзыв, который сейчас редактируется, — сбрасываем форму
    if (editingReviewId === reviewId) resetReviewForm();

    loadReviews();
    loadRatings();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Отправка формы: создание нового отзыва или сохранение изменений
async function submitReview(event) {
  event.preventDefault();
  const form = event.currentTarget;

  const comment = document.getElementById('reviewComment').value.trim();

  if (selectedRating < 1) {
    return showToast('Поставьте оценку от 1 до 5 звёзд', 'warning');
  }
  if (comment.length > 500) {
    return showToast('Комментарий не должен превышать 500 символов', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(
      editingReviewId
        ? `/products/reviews/${editingReviewId}`
        : `/products/${reviewProductId}/review`,
      {
        method: editingReviewId ? 'PUT' : 'POST',
        body: { rating: selectedRating, comment }
      }
    );

    showToast(data.message, 'success');
    resetReviewForm();

    // Обновляем список отзывов в окне и рейтинги на карточках
    loadReviews();
    loadRatings();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
}

// Клик по звезде в форме
document.querySelectorAll('#starRating .star').forEach((star) => {
  star.addEventListener('click', () => setStarRating(Number(star.dataset.star)));
});

document.getElementById('reviewForm').addEventListener('submit', submitReview);

// Отмена редактирования
cancelEditBtn.addEventListener('click', () => {
  resetReviewForm();
  updateReviewFormVisibility();
});

// Кнопки ✎ и ✕ в списке отзывов (делегирование)
document.getElementById('reviewsList').addEventListener('click', (event) => {
  const editButton = event.target.closest('[data-review-edit]');
  if (editButton) {
    return startEditReview(editButton.dataset.reviewEdit);
  }

  const deleteButton = event.target.closest('[data-review-delete]');
  if (deleteButton) {
    deleteReview(deleteButton.dataset.reviewDelete);
  }
});

// Кнопка "💬 Отзывы" на карточках
cardActions.reviews = openReviewsModal;

// Загружаем рейтинги при старте страницы
loadRatings();


// ==================== ФИНАЛЬНЫЕ ШТРИХИ ====================

// ---------- Кнопка "Наверх" ----------
const scrollTopBtn = document.getElementById('scrollTopBtn');

// Показываем кнопку, когда страница прокручена больше чем на 400 пикселей
window.addEventListener('scroll', () => {
  const visible = window.scrollY > 400;
  scrollTopBtn.classList.toggle('hidden', !visible);
  scrollTopBtn.classList.toggle('flex', visible);
}, { passive: true });

scrollTopBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ---------- Копирование email в личном кабинете ----------
document.getElementById('copyEmailBtn').addEventListener('click', async () => {
  if (!currentUser) return;

  try {
    await navigator.clipboard.writeText(currentUser.email);
    showToast('Email скопирован в буфер обмена', 'success');
  } catch (err) {
    showToast('Не удалось скопировать email', 'error');
  }
});


// ==================== ПОКАЗАТЬ / СКРЫТЬ ПАРОЛЬ ====================

// Ко всем полям пароля добавляем кнопку-глазик
document.querySelectorAll('input[type="password"]').forEach((input) => {
  // Оборачиваем поле в контейнер, чтобы разместить кнопку поверх правого края
  const wrapper = document.createElement('div');
  wrapper.className = 'relative';
  input.parentNode.insertBefore(wrapper, input);
  wrapper.appendChild(input);

  // Отступ справа, чтобы текст не заезжал под кнопку
  input.style.paddingRight = '2.75rem';

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-200 transition';
  wrapper.appendChild(button);

  // Переключение видимости пароля
  const setVisible = (visible) => {
    input.type = visible ? 'text' : 'password';
    button.innerHTML = `<i class="fa-regular ${visible ? 'fa-eye-slash' : 'fa-eye'}"></i>`;
    button.setAttribute('aria-label', visible ? 'Скрыть пароль' : 'Показать пароль');
    button.title = visible ? 'Скрыть пароль' : 'Показать пароль';
  };

  setVisible(false);
  button.addEventListener('click', () => setVisible(input.type === 'password'));

  // При очистке формы (после успешной отправки) пароль снова скрывается
  if (input.form) {
    input.form.addEventListener('reset', () => setVisible(false));
  }
});


// ==================== СКЕЛЕТОНЫ ЗАГРУЗКИ ====================

// Серые мерцающие карточки-заготовки на время загрузки товаров
function renderSkeletons() {
  const card = `
    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden animate-pulse" aria-hidden="true">
      <div class="h-44 bg-gray-800"></div>
      <div class="p-4 space-y-3">
        <div class="h-4 w-3/4 rounded bg-gray-800"></div>
        <div class="h-3 w-1/3 rounded bg-gray-800"></div>
        <div class="h-3 rounded bg-gray-800"></div>
        <div class="h-6 w-1/2 rounded bg-gray-800"></div>
        <div class="h-9 rounded bg-gray-800"></div>
      </div>
    </div>`;

  // Столько же карточек, сколько помещается на странице
  document.getElementById('productsGrid').innerHTML = card.repeat(PAGE_SIZE);
}

// ==================== ПРОМОКОДЫ ====================

// ---------- Покупатель: активация промокода ----------

// Админу поле промокода в окне пополнения не показываем
document.getElementById('depositBtn').addEventListener('click', () => {
  const isAdmin = currentUser && currentUser.role === 'admin';
  document.getElementById('promoSection').classList.toggle('hidden', isAdmin);
  document.getElementById('promoForm').reset();
});

document.getElementById('promoForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const code = document.getElementById('promoCodeInput').value.trim().toUpperCase();
  if (!code) {
    return showToast('Введите промокод', 'warning');
  }

  const body = { code };

  // Если в поле суммы что-то введено — передаём её на сервер.
  // Она понадобится, если промокод окажется процентным
  const amountRaw = document.getElementById('depositAmount').value.trim();
  if (amountRaw !== '') {
    const depositAmount = Number(amountRaw);
    if (!Number.isInteger(depositAmount) || depositAmount <= 0) {
      return showToast('Введите сумму целым положительным числом', 'warning');
    }
    if (depositAmount > MAX_DEPOSIT) {
      return showToast(`Максимальная сумма пополнения — ${formatPrice(MAX_DEPOSIT)} ₽`, 'warning');
    }
    body.depositAmount = depositAmount;
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/promo/redeem', { method: 'POST', body });

    currentUser.balance = data.balance;
    updateUI();
    fillProfile();
    form.reset();

    // Процентный промокод уже пополнил баланс на введённую сумму — очищаем поле,
    // чтобы пользователь случайно не пополнил второй раз
    if (data.type === 'percent') {
      document.getElementById('depositForm').reset();
    }

    closeModal('depositModal');
    showToast(data.message, 'success', 5000);
    loadHistory(true);
  } catch (err) {
    showToast(err.message, 'error', 6000);
  } finally {
    setFormBusy(form, false);
  }
});

// ---------- Админ: управление промокодами ----------

let promoCodes = [];        // загруженные промокоды
let editingPromoId = null;  // id редактируемого промокода (null = создаём новый)

const MAX_PROMO_BONUS = 1000000; // максимум фиксированного бонуса, ₽
const MAX_PROMO_PERCENT = 100;   // максимум процентного бонуса, %

// Кнопка "Отмена" для режима редактирования — создаём один раз и добавляем в форму
const promoCancelBtn = document.createElement('button');
promoCancelBtn.type = 'button';
promoCancelBtn.textContent = 'Отмена';
promoCancelBtn.className =
  'hidden sm:col-span-5 py-2 rounded-lg bg-gray-900 border border-gray-700 text-sm font-medium hover:bg-gray-700 transition';
document.getElementById('promoCreateForm').appendChild(promoCancelBtn);

// Подсказка в поле бонуса зависит от выбранного типа
function updatePromoAmountField() {
  const isPercent = document.getElementById('promoNewType').value === 'percent';
  const input = document.getElementById('promoNewAmount');
  input.placeholder = isPercent ? 'Процент, %' : 'Бонус, ₽';
  input.max = isPercent ? MAX_PROMO_PERCENT : MAX_PROMO_BONUS;
}

document.getElementById('promoNewType').addEventListener('change', updatePromoAmountField);

// Возврат формы в режим создания
function resetPromoForm() {
  const form = document.getElementById('promoCreateForm');
  editingPromoId = null;
  form.reset();
  form.querySelector('button[type="submit"]').textContent = 'Создать';
  promoCancelBtn.classList.add('hidden');
  updatePromoAmountField();
}

// Переход в режим редактирования: подставляем данные промокода в форму
function startEditPromo(promoId) {
  const promo = promoCodes.find((item) => String(item.id) === promoId);
  if (!promo) return;

  const form = document.getElementById('promoCreateForm');
  editingPromoId = promoId;
  document.getElementById('promoNewCode').value = promo.code;
  document.getElementById('promoNewType').value = promo.type;
  document.getElementById('promoNewAmount').value = promo.amount;
  document.getElementById('promoNewMaxUses').value = promo.maxUses;
  form.querySelector('button[type="submit"]').textContent = 'Сохранить';
  promoCancelBtn.classList.remove('hidden');
  updatePromoAmountField();

  form.scrollIntoView({ behavior: 'smooth', block: 'center' });
  document.getElementById('promoNewCode').focus();
}

// Загрузка и отрисовка списка промокодов в окне статистики
async function loadPromoCodes() {
  const list = document.getElementById('promoList');

  try {
    promoCodes = await apiRequest('/promo');
  } catch (err) {
    list.innerHTML = '<p class="text-red-400">Не удалось загрузить промокоды</p>';
    return;
  }

  if (promoCodes.length === 0) {
    list.innerHTML = '<p class="text-gray-500">Промокодов пока нет</p>';
    return;
  }

  list.innerHTML = promoCodes.map((promo) => {
    const id = escapeHtml(promo.id);
    const exhausted = promo.usedCount >= promo.maxUses;

    // Подпись бонуса: "+5 000 ₽" или "+10% к пополнению"
    const bonusLabel = promo.type === 'percent'
      ? `+${promo.amount}% к пополнению`
      : `+${formatPrice(promo.amount)} ₽`;

    return `
      <div class="flex items-center justify-between gap-3 bg-gray-900 rounded-lg px-3 py-2">
        <span class="font-mono font-semibold truncate ${exhausted ? 'text-gray-500 line-through' : 'text-yellow-500'}">
          ${escapeHtml(promo.code)}
        </span>
        <span class="shrink-0 flex items-center gap-3">
          <span>${bonusLabel}</span>
          <span class="text-gray-400">${promo.usedCount} / ${promo.maxUses}</span>
          <span class="flex gap-1">
            <button type="button" data-promo-edit="${id}" title="Изменить" aria-label="Изменить промокод"
                    class="w-7 h-7 rounded bg-gray-800 text-xs text-blue-400 hover:bg-gray-700">✎</button>
            <button type="button" data-promo-delete="${id}" title="Удалить" aria-label="Удалить промокод"
                    class="w-7 h-7 rounded bg-gray-800 text-xs text-red-400 hover:bg-gray-700">✕</button>
          </span>
        </span>
      </div>`;
  }).join('');
}

// Создание нового промокода или сохранение изменений
document.getElementById('promoCreateForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const code = document.getElementById('promoNewCode').value.trim().toUpperCase();
  const type = document.getElementById('promoNewType').value;
  const amount = Number(document.getElementById('promoNewAmount').value);
  const maxUses = Number(document.getElementById('promoNewMaxUses').value);

  if (!/^[A-Z0-9_-]{3,20}$/.test(code)) {
    return showToast('Код: от 3 до 20 символов, латинские буквы, цифры, дефис и подчёркивание', 'warning');
  }

  // Допустимый размер бонуса зависит от типа
  const maxAmount = type === 'percent' ? MAX_PROMO_PERCENT : MAX_PROMO_BONUS;
  if (!Number.isInteger(amount) || amount < 1 || amount > maxAmount) {
    return showToast(
      type === 'percent'
        ? `Процент должен быть целым числом от 1 до ${MAX_PROMO_PERCENT}`
        : `Бонус должен быть целым числом от 1 до ${formatPrice(MAX_PROMO_BONUS)}`,
      'warning'
    );
  }
  if (!Number.isInteger(maxUses) || maxUses < 1) {
    return showToast('Лимит активаций должен быть целым числом от 1', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(editingPromoId ? `/promo/${editingPromoId}` : '/promo', {
      method: editingPromoId ? 'PUT' : 'POST',
      body: { code, type, amount, maxUses }
    });

    resetPromoForm();
    showToast(data.message, 'success');
    loadPromoCodes();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Отмена редактирования
promoCancelBtn.addEventListener('click', resetPromoForm);

// Кнопки ✎ и ✕ в списке промокодов (делегирование)
document.getElementById('promoList').addEventListener('click', async (event) => {
  const editButton = event.target.closest('[data-promo-edit]');
  if (editButton) {
    return startEditPromo(editButton.dataset.promoEdit);
  }

  const deleteButton = event.target.closest('[data-promo-delete]');
  if (!deleteButton) return;

  const confirmedDelete = await confirmDialog({
    title: 'Удаление промокода',
    message: 'Удалить этот промокод? Уже начисленные бонусы останутся у пользователей.',
    confirmText: 'Удалить',
    danger: true
  });
  if (!confirmedDelete) return;

  try {
    const data = await apiRequest(`/promo/${deleteButton.dataset.promoDelete}`, { method: 'DELETE' });

    // Если удалили промокод, который сейчас редактируется, — сбрасываем форму
    if (editingPromoId === deleteButton.dataset.promoDelete) resetPromoForm();

    showToast(data.message, 'success');
    loadPromoCodes();
  } catch (err) {
    showToast(err.message, 'error');
  }
});

// ==================== ОКНО ПОДТВЕРЖДЕНИЯ ====================

const confirmModal = document.getElementById('confirmModal');
const confirmOkBtn = document.getElementById('confirmOkBtn');
const confirmCancelBtn = document.getElementById('confirmCancelBtn');

let confirmResolver = null;     // функция, которая "отвечает" на вопрос окна
let confirmPrevFocus = null;    // элемент, на котором был фокус до открытия окна

// Закрытие окна с результатом: true — подтвердили, false — отменили
function closeConfirm(result) {
  confirmModal.classList.add('hidden');
  confirmModal.classList.remove('flex');

  const resolve = confirmResolver;
  confirmResolver = null;

  // Возвращаем фокус туда, где он был
  if (confirmPrevFocus && document.contains(confirmPrevFocus)) {
    confirmPrevFocus.focus();
  }
  confirmPrevFocus = null;

  if (resolve) resolve(result);
}

// Показать окно подтверждения. Возвращает Promise<boolean>.
// Использование: if (!(await confirmDialog({ ... }))) return;
//   danger: true — красная кнопка (для удаления и других необратимых действий)
function confirmDialog({
  title = 'Подтверждение',
  message = '',
  confirmText = 'Подтвердить',
  cancelText = 'Отмена',
  danger = false
} = {}) {
  // Если окно уже открыто — предыдущий вопрос считаем отменённым
  if (confirmResolver) closeConfirm(false);

  // textContent вставляет текст как есть, без разбора HTML — это безопасно
  document.getElementById('confirmTitle').textContent = title;
  document.getElementById('confirmMessage').textContent = message;
  confirmOkBtn.textContent = confirmText;
  confirmCancelBtn.textContent = cancelText;

  // Цвет кнопки подтверждения
  confirmOkBtn.classList.toggle('bg-red-600', danger);
  confirmOkBtn.classList.toggle('hover:bg-red-500', danger);
  confirmOkBtn.classList.toggle('text-white', danger);
  confirmOkBtn.classList.toggle('bg-yellow-500', !danger);
  confirmOkBtn.classList.toggle('hover:bg-yellow-400', !danger);
  confirmOkBtn.classList.toggle('text-black', !danger);

  confirmPrevFocus = document.activeElement;
  confirmModal.classList.remove('hidden');
  confirmModal.classList.add('flex');

  // Для опасных действий фокус на "Отмена", чтобы случайный Enter ничего не удалил
  (danger ? confirmCancelBtn : confirmOkBtn).focus();

  return new Promise((resolve) => {
    confirmResolver = resolve;
  });
}

confirmOkBtn.addEventListener('click', () => closeConfirm(true));
confirmCancelBtn.addEventListener('click', () => closeConfirm(false));

// Клик по затемнённому фону = отмена
confirmModal.addEventListener('mousedown', (event) => {
  if (event.target === confirmModal) closeConfirm(false);
});

// Esc = отмена. Слушаем на фазе перехвата (третий аргумент true) и останавливаем событие,
// чтобы общий обработчик Esc не закрыл заодно окно, лежащее под подтверждением
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && confirmResolver) {
    event.stopPropagation();
    closeConfirm(false);
  }
}, true);

// ==================== ЭКРАНЫ: КАТАЛОГ И ЛИЧНЫЙ КАБИНЕТ ====================

// Показывает нужный экран в зависимости от адреса:
//   ...index.html           — каталог
//   ...index.html#cases     — кейсы
//   ...index.html#profile   — личный кабинет
function renderRoute() {
  const views = {
    catalog: document.getElementById('catalogView'),
    cases: document.getElementById('casesView'),
    profile: document.getElementById('profileView')
  };

  let target = 'catalog';
  if (location.hash === '#profile') target = 'profile';
  if (location.hash === '#cases') target = 'cases';

  // Кабинет доступен только вошедшему пользователю
  if (target === 'profile' && !currentUser) {
    // Токен есть, но сессия ещё восстанавливается — ждём (refreshUser вызовет нас повторно)
    if (getToken() && !sessionChecked) return;

    // Гость: убираем #profile из адреса и показываем каталог
    history.replaceState(null, '', location.pathname + location.search);
    target = 'catalog';
  }

  // Какой экран был открыт до этого
  const previous = Object.keys(views).find((name) => !views[name].classList.contains('hidden'));

  Object.keys(views).forEach((name) => {
    views[name].classList.toggle('hidden', name !== target);
  });

  document.title = {
    catalog: 'MusorShop — маркетплейс скинов CS2',
    cases: 'Кейсы — MusorShop',
    profile: 'Личный кабинет — MusorShop'
  }[target];

  // Подсветка ссылки "Кейсы" в шапке
  const casesBtn = document.getElementById('casesBtn');
  casesBtn.classList.toggle('text-yellow-500', target === 'cases');
  casesBtn.classList.toggle('text-gray-300', target !== 'cases');

  if (target !== previous) {
    // Экран только что открылся — прокручиваем наверх и загружаем данные
    window.scrollTo({ top: 0, behavior: 'instant' });
    if (target === 'profile') loadProfilePage();
    if (target === 'cases') loadCases();
  } else if (target === 'cases') {
    // Экран тот же, но мог смениться пользователь — перерисовываем кнопки
    renderCases();
  }
}

// Адрес изменился (клик по ссылке, кнопки "Назад"/"Вперёд" в браузере)
window.addEventListener('hashchange', renderRoute);

// Кнопка "Главная" и логотип возвращают в каталог
function goToCatalog() {
  if (location.hash) {
    location.hash = '';
  }
}

document.getElementById('homeBtn').addEventListener('click', goToCatalog);
document.getElementById('logoLink').addEventListener('click', goToCatalog);

// Фильтр покупок в кабинете
document.getElementById('purchaseFilters').addEventListener('click', (event) => {
  const button = event.target.closest('[data-purchase-filter]');
  if (!button) return;

  purchaseFilter = button.dataset.purchaseFilter;
  renderPurchases();
});

// Первая отрисовка при загрузке страницы
renderRoute();

// ==================== ПАНЕЛЬ АДМИНИСТРАТОРА В КАБИНЕТЕ ====================

let adminTab = 'stats'; // открытая вкладка панели

// Показ выбранной вкладки и подсветка её кнопки
function renderAdminTabs() {
  document.querySelectorAll('#adminTabs [data-admin-tab]').forEach((button) => {
    const active = button.dataset.adminTab === adminTab;
    button.classList.toggle('bg-yellow-500', active);
    button.classList.toggle('text-black', active);
    button.classList.toggle('bg-gray-800', !active);
    button.classList.toggle('text-gray-300', !active);
  });

  // Содержимое вкладок — блоки с id вида adminTab-<имя>
  document.querySelectorAll('[id^="adminTab-"]').forEach((panel) => {
    panel.classList.toggle('hidden', panel.id !== `adminTab-${adminTab}`);
  });

  // График мог быть создан, пока вкладка была скрыта, — подгоняем его под размер
  if (adminTab === 'stats' && salesChart) {
    salesChart.resize();
  }
}

document.getElementById('adminTabs').addEventListener('click', (event) => {
  const button = event.target.closest('[data-admin-tab]');
  if (!button) return;

  adminTab = button.dataset.adminTab;
  renderAdminTabs();
});

// Загрузка всех данных панели. Вызывается при открытии кабинета админом
function loadAdminPanel() {
  renderAdminTabs();
  loadStats();
  loadSalesChart();
  resetPromoForm();
  loadPromoCodes();
  loadAdminLog(true);
  loadAdminUsers(true);
}

// ==================== ИСТОРИЯ ОПЕРАЦИЙ ====================

// Оформление типов операций: подпись и иконка
const TRANSACTION_TYPES = {
  deposit:    { label: 'Пополнение',    icon: 'fa-wallet' },
  purchase:   { label: 'Покупка',       icon: 'fa-cart-shopping' },
  sale:       { label: 'Продажа',       icon: 'fa-hand-holding-dollar' },
  promo:      { label: 'Промокод',      icon: 'fa-ticket' },
  adjustment: { label: 'Корректировка', icon: 'fa-sliders' },
  case:       { label: 'Кейс',          icon: 'fa-box-open' }
};

// HTML одной строки операции. showUser — показывать ли email (для журнала админа)
function createTransactionRow(item, showUser) {
  const type = TRANSACTION_TYPES[item.type] || { label: item.type, icon: 'fa-circle' };
  const isIncome = item.amount >= 0;

  const details = [
    showUser ? escapeHtml(item.userEmail) : '',
    escapeHtml(item.description),
    formatDate(item.createdAt)
  ].filter(Boolean).join(' · ');

  return `
    <div class="flex items-center gap-3 bg-gray-900 border border-gray-800 rounded-lg p-3">
      <div class="w-10 h-10 shrink-0 rounded-full bg-gray-800 flex items-center justify-center text-gray-300">
        <i class="fa-solid ${type.icon}"></i>
      </div>
      <div class="flex-1 min-w-0">
        <p class="text-sm font-medium">${escapeHtml(type.label)}</p>
        <p class="text-xs text-gray-400 truncate">${details}</p>
      </div>
      <div class="shrink-0 text-right">
        <p class="text-sm font-semibold ${isIncome ? 'text-green-500' : 'text-red-400'}">
          ${isIncome ? '+' : '−'}${formatPrice(Math.abs(item.amount))} ₽
        </p>
        <p class="text-xs text-gray-500">Баланс: ${formatPrice(item.balanceAfter)} ₽</p>
      </div>
    </div>`;
}

// Общая загрузка одной "порции" операций в указанный список.
// reset = true — начать с первой страницы и заменить содержимое списка
async function loadTransactions({ url, listId, moreBtnId, showUser, reset }) {
  const list = document.getElementById(listId);
  const moreBtn = document.getElementById(moreBtnId);

  let data;
  try {
    data = await apiRequest(url);
  } catch (err) {
    if (reset) {
      list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить операции</p>';
    }
    return;
  }

  const html = data.items.map((item) => createTransactionRow(item, showUser)).join('');

  if (reset) {
    list.innerHTML = html || '<p class="text-sm text-gray-500">Операций пока нет</p>';
  } else {
    list.insertAdjacentHTML('beforeend', html);
  }

  // Кнопка "Показать ещё" видна, пока на сервере остаются записи
  moreBtn.classList.toggle('hidden', !data.hasMore);
}

// ---------- Своя история в кабинете ----------

let historyPage = 1;

async function loadHistory(reset = false) {
  if (!currentUser) return;
  // Если кабинет сейчас не открыт — загружать нечего
  if (document.getElementById('profileView').classList.contains('hidden')) return;

  if (reset) historyPage = 1;

  await loadTransactions({
    url: `/transactions/my?page=${historyPage}`,
    listId: 'historyList',
    moreBtnId: 'historyMoreBtn',
    showUser: false,
    reset
  });
}

document.getElementById('historyMoreBtn').addEventListener('click', () => {
  historyPage += 1;
  loadHistory(false);
});

// ---------- Журнал всех операций (админ) ----------

let logPage = 1;

async function loadAdminLog(reset = false) {
  if (!currentUser || currentUser.role !== 'admin') return;

  if (reset) logPage = 1;

  const type = document.getElementById('logTypeFilter').value;
  const query = `page=${logPage}${type ? `&type=${encodeURIComponent(type)}` : ''}`;

  await loadTransactions({
    url: `/transactions/admin?${query}`,
    listId: 'logList',
    moreBtnId: 'logMoreBtn',
    showUser: true,
    reset
  });
}

document.getElementById('logMoreBtn').addEventListener('click', () => {
  logPage += 1;
  loadAdminLog(false);
});

// Смена фильтра по типу — загружаем журнал заново
document.getElementById('logTypeFilter').addEventListener('change', () => loadAdminLog(true));

// ==================== АДМИН: УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ ====================

let adminUsers = [];        // загруженные пользователи
let usersPage = 1;          // текущая "порция" списка
let balanceUserId = null;   // кому сейчас корректируем баланс

// HTML одной строки пользователя
function createUserRow(user) {
  const id = escapeHtml(user.id);
  const isAdminUser = user.role === 'admin';

  // Плашки статуса
  let badges = '';
  if (isAdminUser) {
    badges += '<span class="px-2 py-0.5 rounded bg-blue-600 text-xs font-semibold">админ</span>';
  }
  if (user.isBlocked) {
    badges += '<span class="px-2 py-0.5 rounded bg-red-600 text-xs font-semibold">заблокирован</span>';
  }

  // Кнопка блокировки — только для обычных пользователей
  const blockButton = isAdminUser
    ? ''
    : `<button type="button" data-user-block="${id}"
               class="px-3 py-1.5 rounded-lg text-xs font-semibold transition
                      ${user.isBlocked ? 'bg-green-600 hover:bg-green-500' : 'bg-red-600 hover:bg-red-500'}">
         ${user.isBlocked ? 'Разблокировать' : 'Заблокировать'}
       </button>`;

  return `
    <div class="flex flex-wrap items-center gap-3 bg-gray-900 rounded-lg p-3">
      <div class="flex-1 min-w-0">
        <p class="flex flex-wrap items-center gap-2 text-sm font-medium">
          <span class="break-all">${escapeHtml(user.email)}</span>
          ${badges}
        </p>
        <p class="text-xs text-gray-400">
          Баланс: ${formatPrice(user.balance)} ₽ · Покупок: ${user.purchasesCount} · Регистрация: ${formatDate(user.registeredAt)}
        </p>
      </div>
      <div class="shrink-0 flex gap-2">
        <button type="button" data-user-balance="${id}"
                class="px-3 py-1.5 rounded-lg bg-gray-800 border border-gray-700 text-xs font-semibold hover:bg-gray-700 transition">
          Баланс
        </button>
        ${blockButton}
      </div>
    </div>`;
}

// Загрузка списка пользователей. reset = true — с первой страницы
async function loadAdminUsers(reset = false) {
  if (!currentUser || currentUser.role !== 'admin') return;

  const list = document.getElementById('usersList');
  const moreBtn = document.getElementById('usersMoreBtn');

  if (reset) usersPage = 1;

  const search = document.getElementById('usersSearch').value.trim();
  const query = `page=${usersPage}${search ? `&search=${encodeURIComponent(search)}` : ''}`;

  let data;
  try {
    data = await apiRequest(`/users?${query}`);
  } catch (err) {
    if (reset) {
      list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить пользователей</p>';
    }
    return;
  }

  adminUsers = reset ? data.items : adminUsers.concat(data.items);

  document.getElementById('usersTotal').textContent = data.total;
  list.innerHTML = adminUsers.length > 0
    ? adminUsers.map(createUserRow).join('')
    : '<p class="text-sm text-gray-500">Никого не найдено</p>';
  moreBtn.classList.toggle('hidden', !data.hasMore);
}

document.getElementById('usersMoreBtn').addEventListener('click', () => {
  usersPage += 1;
  loadAdminUsers(false);
});

// Поиск по email с задержкой 300 мс
document.getElementById('usersSearch').addEventListener('input', debounce(() => loadAdminUsers(true), 300));

// Кнопки в строках пользователей (делегирование)
document.getElementById('usersList').addEventListener('click', async (event) => {
  // ---------- Корректировка баланса ----------
  const balanceButton = event.target.closest('[data-user-balance]');
  if (balanceButton) {
    const user = adminUsers.find((item) => String(item.id) === balanceButton.dataset.userBalance);
    if (!user) return;

    balanceUserId = String(user.id);
    document.getElementById('balanceForm').reset();
    document.getElementById('balanceUserInfo').textContent =
      `${user.email} · текущий баланс: ${formatPrice(user.balance)} ₽`;
    openModal('balanceModal');
    return;
  }

  // ---------- Блокировка и разблокировка ----------
  const blockButton = event.target.closest('[data-user-block]');
  if (!blockButton) return;

  const user = adminUsers.find((item) => String(item.id) === blockButton.dataset.userBlock);
  if (!user) return;

  const willBlock = !user.isBlocked;

  const confirmed = await confirmDialog({
    title: willBlock ? 'Блокировка пользователя' : 'Разблокировка пользователя',
    message: willBlock
      ? `Заблокировать ${user.email}? Он сразу потеряет доступ к аккаунту и не сможет войти.`
      : `Разблокировать ${user.email}? Он снова сможет войти в аккаунт.`,
    confirmText: willBlock ? 'Заблокировать' : 'Разблокировать',
    danger: willBlock
  });
  if (!confirmed) return;

  try {
    const data = await apiRequest(`/users/${user.id}/block`, {
      method: 'PUT',
      body: { blocked: willBlock }
    });
    showToast(data.message, 'success');
    loadAdminUsers(true);
  } catch (err) {
    showToast(err.message, 'error');
  }
});

// Отправка формы корректировки баланса
document.getElementById('balanceForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const amountRaw = document.getElementById('balanceAmount').value.trim();
  const amount = Number(amountRaw);
  const reason = document.getElementById('balanceReason').value.trim();

  if (amountRaw === '' || !Number.isInteger(amount) || amount === 0) {
    return showToast('Сумма должна быть целым числом, не равным нулю', 'warning');
  }
  if (!reason) {
    return showToast('Укажите причину корректировки', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(`/users/${balanceUserId}/balance`, {
      method: 'POST',
      body: { amount, reason }
    });

    // Если админ изменил собственный баланс — обновляем его в шапке и кабинете
    if (String(currentUser.id) === balanceUserId) {
      currentUser.balance = data.balance;
      updateUI();
      fillProfile();
      loadHistory(true);
    }

    closeModal('balanceModal');
    showToast(`${data.message}. Новый баланс: ${formatPrice(data.balance)} ₽`, 'success');
    loadAdminUsers(true);
    loadAdminLog(true);
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});
// ==================== ЗАГРУЗКА КАРТИНКИ ТОВАРА ====================

const MAX_IMAGE_SIZE = 2 * 1024 * 1024; // 2 МБ
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

// Предпросмотр: показывает картинку по адресу из поля ссылки
function updateImagePreview() {
  const preview = document.getElementById('productImagePreview');
  const url = document.getElementById('productImageUrl').value.trim();

  if (/^https?:\/\//i.test(url)) {
    preview.src = url;
    preview.classList.remove('hidden');
  } else {
    preview.removeAttribute('src');
    preview.classList.add('hidden');
  }
}

// Если картинка по ссылке не загрузилась — прячем предпросмотр
document.getElementById('productImagePreview').addEventListener('error', (event) => {
  event.currentTarget.classList.add('hidden');
});

// Ссылку изменили вручную — обновляем предпросмотр
document.getElementById('productImageUrl').addEventListener('input', debounce(updateImagePreview, 400));

// Форму очистили — прячем предпросмотр.
// setTimeout нужен, потому что событие reset срабатывает ДО очистки полей
document.getElementById('productForm').addEventListener('reset', () => {
  setTimeout(updateImagePreview, 0);
});

// Отправка файла на сервер. Возвращает адрес загруженной картинки.
// apiRequest здесь не подходит: файл передаётся не как JSON, а как FormData
async function uploadImage(file) {
  const formData = new FormData();
  formData.append('image', file);

  let response;
  try {
    response = await fetch(`${API_URL}/upload/image`, {
      method: 'POST',
      // Заголовок Content-Type не указываем: браузер сам выставит его для FormData
      headers: { Authorization: `Bearer ${getToken()}` },
      body: formData
    });
  } catch (err) {
    throw new Error('Сервер недоступен. Проверьте, что бэкенд запущен');
  }

  let data = null;
  try {
    data = await response.json();
  } catch (err) {
    // ответ без JSON
  }

  if (!response.ok) {
    throw new Error((data && data.message) || 'Не удалось загрузить файл');
  }
  return data.url;
}

// Выбран файл — проверяем и сразу загружаем
document.getElementById('productImageFile').addEventListener('change', async (event) => {
  const input = event.currentTarget;
  const file = input.files[0];
  if (!file) return;

  // Проверки в браузере (сервер проверит ещё раз, по содержимому файла)
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    input.value = '';
    return showToast('Допустимы только изображения JPG, PNG, GIF и WebP', 'warning');
  }
  if (file.size > MAX_IMAGE_SIZE) {
    input.value = '';
    return showToast('Файл слишком большой. Максимум — 2 МБ', 'warning');
  }

  const form = document.getElementById('productForm');
  setFormBusy(form, true); // пока идёт загрузка, сохранить товар нельзя

  try {
    const url = await uploadImage(file);
    document.getElementById('productImageUrl').value = url;
    updateImagePreview();
    showToast('Картинка загружена. Не забудьте сохранить товар', 'success');
  } catch (err) {
    input.value = '';
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== КОРЗИНА ====================

// Ключ в localStorage: у каждого покупателя своя корзина.
// Для гостя и админа корзины нет — возвращаем null
function getCartKey() {
  return currentUser && currentUser.role === 'user' ? `cart:${currentUser.id}` : null;
}

// Чтение корзины: массив вида [{ productId, quantity }]
function readCart() {
  const key = getCartKey();
  if (!key) return [];

  try {
    const raw = JSON.parse(localStorage.getItem(key) || '[]');
    if (!Array.isArray(raw)) return [];

    // Отбрасываем всё, что не похоже на позицию корзины (данные могли быть повреждены)
    return raw
      .filter((item) => item && typeof item.productId === 'string' &&
        Number.isInteger(item.quantity) && item.quantity >= 1)
      .map((item) => ({ productId: item.productId, quantity: Math.min(item.quantity, 10) }))
      .slice(0, 20);
  } catch (err) {
    return [];
  }
}

// Сохранение корзины и обновление счётчика в шапке
function writeCart(items) {
  const key = getCartKey();
  if (!key) return;

  try {
    localStorage.setItem(key, JSON.stringify(items));
  } catch (err) {
    // хранилище недоступно — корзина просто не сохранится между визитами
  }
  updateCartBadge();
}

function isInCart(productId) {
  return readCart().some((item) => item.productId === productId);
}

// Кнопка корзины в шапке: видна только покупателю, на ней — число предметов
function updateCartBadge() {
  const button = document.getElementById('cartBtn');
  const badge = document.getElementById('cartCount');
  const isBuyer = Boolean(getCartKey());

  button.classList.toggle('hidden', !isBuyer);

  const count = readCart().reduce((sum, item) => sum + item.quantity, 0);
  badge.textContent = count;
  badge.classList.toggle('hidden', count === 0);
  badge.classList.toggle('flex', count > 0);
}

const CART_MAX_LINES = 20;     // максимум разных товаров
const CART_MAX_QUANTITY = 10;  // максимум штук одного товара

// Позиции корзины вместе с данными товаров.
// Товары, которых больше нет в магазине, из корзины убираются
function getCartLines() {
  const cart = readCart();
  const lines = [];

  cart.forEach((item) => {
    const product = products.find((p) => p._id === item.productId);
    if (product) {
      lines.push({ product, quantity: item.quantity });
    }
  });

  if (lines.length !== cart.length) {
    writeCart(lines.map((line) => ({ productId: line.product._id, quantity: line.quantity })));
  }
  return lines;
}

// Добавление товара в корзину (кнопка на карточке)
function addToCart(productId) {
  if (!getCartKey()) {
    return showToast('Войдите в аккаунт покупателя, чтобы пользоваться корзиной', 'warning');
  }

  const product = products.find((item) => item._id === productId);
  if (!product || product.quantity < 1) {
    return showToast('Товара нет в наличии', 'warning');
  }

  const cart = readCart();
  const existing = cart.find((item) => item.productId === productId);
  const limit = Math.min(product.quantity, CART_MAX_QUANTITY);

  if (existing) {
    if (existing.quantity >= limit) {
      return showToast(`Больше ${limit} шт. этого товара добавить нельзя`, 'warning');
    }
    existing.quantity += 1;
  } else {
    if (cart.length >= CART_MAX_LINES) {
      return showToast(`В корзине может быть не больше ${CART_MAX_LINES} разных товаров`, 'warning');
    }
    cart.push({ productId, quantity: 1 });
  }

  writeCart(cart);
  renderProducts(); // значок на карточке сменится на галочку
  showToast(`«${product.title}» добавлен в корзину`, 'success');
}

cardActions.cart = addToCart;

// Отрисовка содержимого окна корзины
function renderCart() {
  const list = document.getElementById('cartList');
  const footer = document.getElementById('cartFooter');
  const lines = getCartLines();

  if (lines.length === 0) {
    list.innerHTML = '<p class="text-gray-500 text-center py-6">Корзина пуста</p>';
    footer.classList.add('hidden');
    return;
  }

  let total = 0;
  let count = 0;
  let hasProblems = false; // есть ли позиции, которых не хватает на складе

  list.innerHTML = lines.map(({ product, quantity }) => {
    const id = escapeHtml(product._id);
    const lineTotal = product.price * quantity;
    const notEnough = quantity > product.quantity;

    total += lineTotal;
    count += quantity;
    if (notEnough) hasProblems = true;

    const image = product.imageUrl
      ? `<img src="${escapeHtml(product.imageUrl)}" alt="" class="w-full h-full object-contain" onerror="this.remove()">`
      : '<i class="fa-solid fa-image text-gray-600"></i>';

    const stockNote = notEnough
      ? `<span class="text-red-400">в наличии только ${product.quantity} шт.</span>`
      : `${formatPrice(product.price)} ₽ за штуку`;

    return `
      <div class="flex flex-wrap items-center gap-3 bg-gray-800 rounded-lg p-3">
        <div class="w-12 h-12 shrink-0 rounded bg-gray-900 flex items-center justify-center overflow-hidden">
          ${image}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium truncate">${escapeHtml(product.title)}</p>
          <p class="text-xs text-gray-400">${stockNote}</p>
        </div>
        <div class="shrink-0 flex items-center gap-1">
          <button type="button" data-cart-dec="${id}" aria-label="Уменьшить количество"
                  class="w-8 h-8 rounded bg-gray-900 hover:bg-gray-700">−</button>
          <span class="w-8 text-center font-semibold">${quantity}</span>
          <button type="button" data-cart-inc="${id}" aria-label="Увеличить количество"
                  class="w-8 h-8 rounded bg-gray-900 hover:bg-gray-700">+</button>
        </div>
        <p class="shrink-0 w-28 text-right font-semibold text-yellow-500">${formatPrice(lineTotal)} ₽</p>
        <button type="button" data-cart-remove="${id}" title="Убрать" aria-label="Убрать из корзины"
                class="shrink-0 w-8 h-8 rounded bg-gray-900 text-red-400 hover:bg-gray-700">✕</button>
      </div>`;
  }).join('');

  footer.classList.remove('hidden');
  document.getElementById('cartItemsCount').textContent = count;
  document.getElementById('cartTotal').textContent = formatPrice(total);

  // Подсказка под суммой и доступность кнопки оформления
  const note = document.getElementById('cartBalanceNote');
  const checkoutBtn = document.getElementById('cartCheckoutBtn');
  const notEnoughMoney = currentUser.balance < total;

  if (hasProblems) {
    note.textContent = 'Уменьшите количество товаров, которых не хватает на складе';
    note.className = 'mt-1 text-xs text-right text-red-400';
  } else if (notEnoughMoney) {
    note.textContent = `Не хватает ${formatPrice(total - currentUser.balance)} ₽. Пополните баланс`;
    note.className = 'mt-1 text-xs text-right text-red-400';
  } else {
    note.textContent = `После покупки на балансе останется ${formatPrice(currentUser.balance - total)} ₽`;
    note.className = 'mt-1 text-xs text-right text-gray-500';
  }

  const blocked = hasProblems || notEnoughMoney;
  checkoutBtn.disabled = blocked;
  checkoutBtn.classList.toggle('opacity-50', blocked);
  checkoutBtn.classList.toggle('cursor-not-allowed', blocked);
}

// Открытие корзины
document.getElementById('cartBtn').addEventListener('click', () => {
  renderCart();
  openModal('cartModal');
});

// Кнопки −, + и ✕ в списке корзины (делегирование)
document.getElementById('cartList').addEventListener('click', (event) => {
  const button = event.target.closest('[data-cart-inc], [data-cart-dec], [data-cart-remove]');
  if (!button) return;

  let cart = readCart();
  const productId = button.dataset.cartInc || button.dataset.cartDec || button.dataset.cartRemove;
  const item = cart.find((entry) => entry.productId === productId);
  if (!item) return;

  if (button.dataset.cartInc) {
    const product = products.find((p) => p._id === productId);
    const limit = Math.min(product ? product.quantity : 0, CART_MAX_QUANTITY);
    if (item.quantity >= limit) {
      return showToast(`Больше ${limit} шт. этого товара добавить нельзя`, 'warning');
    }
    item.quantity += 1;
  } else if (button.dataset.cartDec && item.quantity > 1) {
    item.quantity -= 1;
  } else {
    // "✕" или уменьшение с одной штуки — убираем позицию целиком
    cart = cart.filter((entry) => entry.productId !== productId);
  }

  writeCart(cart);
  renderCart();
  renderProducts();
});

// Очистка корзины
document.getElementById('cartClearBtn').addEventListener('click', async () => {
  const confirmed = await confirmDialog({
    title: 'Очистка корзины',
    message: 'Убрать из корзины все товары?',
    confirmText: 'Очистить',
    danger: true
  });
  if (!confirmed) return;

  writeCart([]);
  renderCart();
  renderProducts();
});

// Оформление покупки
document.getElementById('cartCheckoutBtn').addEventListener('click', async (event) => {
  const button = event.currentTarget;
  const lines = getCartLines();
  if (lines.length === 0) return;

  const total = lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0);
  const count = lines.reduce((sum, line) => sum + line.quantity, 0);

  const confirmed = await confirmDialog({
    title: 'Оформление покупки',
    message: `Купить предметов: ${count} на сумму ${formatPrice(total)} ₽?`,
    confirmText: 'Купить'
  });
  if (!confirmed) return;

  button.disabled = true;
  try {
    const data = await apiRequest('/products/cart/checkout', {
      method: 'POST',
      body: {
        items: lines.map((line) => ({ productId: line.product._id, quantity: line.quantity }))
      }
    });

    currentUser.balance = data.balance;
    writeCart([]);
    updateUI();
    closeModal('cartModal');
    playSuccessSound();
    showToast(
      `${data.message} на сумму ${formatPrice(data.total)} ₽. Остаток на балансе: ${formatPrice(data.balance)} ₽`,
      'success',
      5000
    );

    // Обновляем остатки на витрине и, если открыт кабинет, его содержимое
    await loadProducts();
    if (!document.getElementById('profileView').classList.contains('hidden')) {
      loadProfilePage();
    }
  } catch (err) {
    showToast(err.message, 'error', 5000);
    // Остатки могли измениться — перезагружаем товары и перерисовываем корзину
    await loadProducts();
    renderCart();
  } finally {
    button.disabled = false;
  }
});

// ==================== РЕДКОСТЬ СКИНОВ ====================

// Справочник редкостей: подпись и цвет (как в CS2)
const RARITY_INFO = {
  milspec:    { label: 'Армейское',     color: '#4b69ff' },
  restricted: { label: 'Запрещённое',   color: '#8847ff' },
  classified: { label: 'Засекреченное', color: '#d32ce6' },
  covert:     { label: 'Тайное',        color: '#eb4b4b' },
  gold:       { label: 'Редкое',        color: '#e4ae39' }
};

// Редкость предмета: { key, label, color }. У старых товаров без редкости — "Армейское"
function getRarity(item) {
  const key = item && RARITY_INFO[item.rarity] ? item.rarity : 'milspec';
  return { key, ...RARITY_INFO[key] };
}

// ==================== КЕЙСЫ ====================

let casesList = [];        // загруженные кейсы
let activeCase = null;     // кейс, открытый в окне
let caseSpinning = false;  // идёт ли сейчас прокрутка рулетки
let editingCaseId = null;  // id редактируемого кейса (null = создаём новый)

const ROULETTE_LENGTH = 60;  // сколько плиток в ленте
const ROULETTE_WIN_INDEX = 52; // на какой плитке лента остановится
const TILE_WIDTH = 112;      // ширина плитки (класс w-28)
const TILE_STEP = 120;       // ширина плитки + промежуток (gap-2)
const SPIN_DURATION = 5000;  // длительность прокрутки, мс

// Шанс в виде текста: "15,98%" или "<0,01%"
function formatChance(chance) {
  if (chance > 0 && chance < 0.01) return '<0,01%';
  return `${chance.toLocaleString('ru-RU', { maximumFractionDigits: 2 })}%`;
}

// ---------- Список кейсов ----------

async function loadCases() {
  const grid = document.getElementById('casesGrid');
  try {
    casesList = await apiRequest('/cases');
  } catch (err) {
    grid.innerHTML = '<p class="col-span-full text-center text-red-400 py-10">Не удалось загрузить кейсы</p>';
    return;
  }
  renderCases();
}

function renderCases() {
  const grid = document.getElementById('casesGrid');
  const isAdmin = currentUser && currentUser.role === 'admin';

  let html = casesList.map((caseData) => {
    const id = escapeHtml(caseData.id);

    const image = caseData.imageUrl
      ? `<img src="${escapeHtml(caseData.imageUrl)}" alt="" loading="lazy" class="w-full h-full object-contain p-3"
              onerror="this.replaceWith(Object.assign(document.createElement('i'), { className: 'fa-solid fa-box-open text-5xl text-yellow-500' }))">`
      : '<i class="fa-solid fa-box-open text-5xl text-yellow-500"></i>';

    const adminButtons = isAdmin
      ? `<div class="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition">
           <button type="button" data-case-edit="${id}" aria-label="Редактировать кейс"
                   class="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white">✎</button>
           <button type="button" data-case-delete="${id}" aria-label="Удалить кейс"
                   class="w-9 h-9 rounded-full bg-red-600 hover:bg-red-500 text-white">✕</button>
         </div>`
      : '';

    return `
      <article class="group relative bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/60 transition">
        <button type="button" data-case-open="${id}" class="block w-full text-left">
          <div class="h-44 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            ${image}
          </div>
          <div class="p-4">
            <h3 class="font-semibold leading-snug">${escapeHtml(caseData.title)}</h3>
            <p class="mt-1 text-sm text-gray-400">Предметов: ${caseData.items.length}</p>
            <p class="mt-3 text-xl font-bold text-yellow-500">${formatPrice(caseData.price)} ₽</p>
          </div>
        </button>
        ${adminButtons}
      </article>`;
  }).join('');

  // Карточка-плюсик для админа
  if (isAdmin) {
    html += `
      <button type="button" data-case-add
              class="min-h-[18rem] flex flex-col items-center justify-center gap-3 rounded-xl
                     border-2 border-dashed border-gray-700 text-gray-500
                     hover:border-yellow-500 hover:text-yellow-500 transition">
        <i class="fa-solid fa-plus text-4xl"></i>
        <span class="font-semibold">Добавить кейс</span>
      </button>`;
  }

  if (!html) {
    html = '<p class="col-span-full text-center text-gray-500 py-10">Кейсов пока нет</p>';
  }

  grid.innerHTML = html;
}

// ---------- Окно кейса ----------

// HTML одной плитки рулетки
function createTile(item) {
  const rarity = getRarity(item);
  const image = item.imageUrl
    ? `<img src="${escapeHtml(item.imageUrl)}" alt="" class="h-14 w-full object-contain" onerror="this.remove()">`
    : '<i class="fa-solid fa-image text-2xl text-gray-600"></i>';

  return `
    <div class="w-28 h-28 shrink-0 rounded-lg bg-gray-800 border-b-4 p-1 flex flex-col items-center justify-center gap-1"
         style="border-color:${rarity.color}">
      ${image}
      <p class="w-full text-center text-[10px] leading-tight text-gray-300 truncate">${escapeHtml(item.title)}</p>
    </div>`;
}

// Случайный предмет с учётом шансов — только для "массовки" в ленте.
// Настоящий результат определяет сервер
function pickRandomItem(items) {
  const total = items.reduce((sum, item) => sum + item.chance, 0);
  let roll = Math.random() * total;
  for (const item of items) {
    roll -= item.chance;
    if (roll <= 0) return item;
  }
  return items[items.length - 1];
}

// Лента в состоянии покоя: несколько случайных плиток без движения
function resetRoulette() {
  const strip = document.getElementById('caseStrip');
  strip.style.transition = 'none';
  strip.style.transform = 'translateX(0)';

  const tiles = [];
  for (let i = 0; i < 10; i++) {
    tiles.push(pickRandomItem(activeCase.items));
  }
  strip.innerHTML = tiles.map(createTile).join('');

  document.getElementById('caseResult').classList.add('hidden');
}

// Кнопка открытия: текст и доступность зависят от роли
function updateCaseOpenButton() {
  const button = document.getElementById('caseOpenBtn');
  if (!activeCase) return;

  const isAdmin = currentUser && currentUser.role === 'admin';
  const isBuyer = currentUser && currentUser.role === 'user';

  button.classList.toggle('hidden', Boolean(isAdmin)); // админ кейсы не открывает

  let text = `Открыть за ${formatPrice(activeCase.price)} ₽`;
  let disabled = caseSpinning;

  if (!isBuyer) {
    text = 'Войдите в аккаунт, чтобы открыть кейс';
    disabled = true;
  } else if (caseSpinning) {
    text = 'Открываем…';
  } else if (activeCase.items.length === 0) {
    text = 'Кейс пуст';
    disabled = true;
  }

  button.textContent = text;
  button.disabled = disabled;
  button.classList.toggle('opacity-50', disabled);
  button.classList.toggle('cursor-not-allowed', disabled);
}

function openCaseModal(caseId) {
  const caseData = casesList.find((item) => String(item.id) === caseId);
  if (!caseData || caseSpinning) return;

  activeCase = caseData;
  document.getElementById('caseModalTitle').textContent = caseData.title;

  // Для админа — средняя стоимость выпадения (помогает подобрать цену кейса)
  const evNote = document.getElementById('caseEvNote');
  const isAdmin = currentUser && currentUser.role === 'admin';
  if (isAdmin) {
    const expected = caseData.items.reduce((sum, item) => sum + item.price * item.chance / 100, 0);
    evNote.textContent =
      `Средняя стоимость выпадающего предмета: ${formatPrice(Math.round(expected))} ₽ при цене кейса ${formatPrice(caseData.price)} ₽`;
  }
  evNote.classList.toggle('hidden', !isAdmin);

  // Содержимое с шансами
  document.getElementById('caseContents').innerHTML = caseData.items.length > 0
    ? caseData.items.map((item) => {
        const rarity = getRarity(item);
        return `
          <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-2 border-l-4" style="border-color:${rarity.color}">
            <div class="flex-1 min-w-0">
              <p class="text-sm font-medium truncate">${escapeHtml(item.title)}</p>
              <p class="text-xs" style="color:${rarity.color}">${rarity.label} · <span class="text-gray-400">${formatPrice(item.price)} ₽</span></p>
            </div>
            <span class="shrink-0 text-sm font-semibold text-gray-200">${formatChance(item.chance)}</span>
          </div>`;
      }).join('')
    : '<p class="col-span-full text-sm text-gray-500">В кейсе нет предметов</p>';

  if (caseData.items.length > 0) {
    resetRoulette();
  } else {
    document.getElementById('caseStrip').innerHTML = '';
    document.getElementById('caseResult').classList.add('hidden');
  }

  updateCaseOpenButton();
  openModal('caseModal');
}

// Прокрутка рулетки до выигранного предмета. Возвращает Promise, который
// завершается, когда лента остановилась
function spinRoulette(wonItem) {
  const strip = document.getElementById('caseStrip');
  const roulette = document.getElementById('caseRoulette');

  // Собираем ленту: случайные предметы, а на заданной позиции — выигранный
  const tiles = [];
  for (let i = 0; i < ROULETTE_LENGTH; i++) {
    tiles.push(i === ROULETTE_WIN_INDEX ? wonItem : pickRandomItem(activeCase.items));
  }

  // Возвращаем ленту в начало без анимации
  strip.style.transition = 'none';
  strip.style.transform = 'translateX(0)';
  strip.innerHTML = tiles.map(createTile).join('');
  void strip.offsetWidth; // заставляем браузер применить стартовое положение

  // Сдвиг, при котором выигранная плитка окажется под центральной меткой.
  // Небольшой случайный разброс, чтобы метка не всегда попадала ровно в середину плитки
  const jitter = Math.floor(Math.random() * 80) - 40;
  const offset = ROULETTE_WIN_INDEX * TILE_STEP + TILE_WIDTH / 2 - roulette.clientWidth / 2 + jitter;

  // Если в системе включено "уменьшение движения" — показываем результат без прокрутки
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const duration = reduceMotion ? 0 : SPIN_DURATION;

  strip.style.transition = `transform ${duration}ms cubic-bezier(0.12, 0.8, 0.2, 1)`;
  strip.style.transform = `translateX(-${offset}px)`;

  return new Promise((resolve) => setTimeout(resolve, duration + 150));
}

// Открытие кейса
async function handleOpenCase() {
  if (caseSpinning || !activeCase) return;

  if (!currentUser || currentUser.role !== 'user') {
    return showToast('Войдите в аккаунт покупателя, чтобы открывать кейсы', 'warning');
  }
  if (currentUser.balance < activeCase.price) {
    return showToast('Недостаточно средств на балансе', 'warning');
  }

  const result = document.getElementById('caseResult');
  caseSpinning = true;
  result.classList.add('hidden');
  updateCaseOpenButton();

  try {
    // Сервер списывает деньги и сразу сообщает, что выпало
    const data = await apiRequest(`/cases/${activeCase.id}/open`, { method: 'POST' });

    currentUser.balance = data.balance;
    updateUI();

    // Анимация только показывает уже известный результат
    await spinRoulette(data.item);

    const rarity = getRarity(data.item);
    result.innerHTML = `
      <p class="text-sm text-gray-400">Вам выпало</p>
      <p class="mt-1 text-xl font-bold" style="color:${rarity.color}">${escapeHtml(data.item.title)}</p>
      <p class="text-sm text-gray-300">${rarity.label} · стоимость ${formatPrice(data.item.price)} ₽</p>
      <p class="mt-2 text-xs text-gray-500">Предмет добавлен в инвентарь в личном кабинете</p>`;
    result.classList.remove('hidden');

    playSuccessSound();
    showToast(`Выпало: ${data.item.title}`, 'success', 5000);
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    caseSpinning = false;
    updateCaseOpenButton();
  }
}

document.getElementById('caseOpenBtn').addEventListener('click', handleOpenCase);

// ---------- Админ: создание, изменение, удаление ----------

function updateCaseItemsCount() {
  document.getElementById('caseItemsCount').textContent =
    document.querySelectorAll('#caseItemsList input:checked').length;
}

// Открытие формы кейса. Без аргумента — создание, с кейсом — редактирование
function openCaseForm(caseData = null) {
  editingCaseId = caseData ? String(caseData.id) : null;

  document.getElementById('caseForm').reset();
  document.getElementById('caseFormTitle').textContent = caseData ? 'Редактировать кейс' : 'Новый кейс';
  document.getElementById('caseSubmitBtn').textContent = caseData ? 'Сохранить изменения' : 'Создать';

  if (caseData) {
    document.getElementById('caseTitleInput').value = caseData.title;
    document.getElementById('casePriceInput').value = caseData.price;
    document.getElementById('caseImageInput').value = caseData.imageUrl || '';
  }

  const selected = new Set(caseData ? caseData.items.map((item) => String(item.id)) : []);

  // Список всех товаров с галочками, от дешёвых к дорогим
  const sorted = [...products].sort((a, b) => a.price - b.price);
  document.getElementById('caseItemsList').innerHTML = sorted.length > 0
    ? sorted.map((product) => {
        const rarity = getRarity(product);
        return `
          <label class="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-700 cursor-pointer">
            <input type="checkbox" value="${escapeHtml(product._id)}" class="accent-yellow-500"
                   ${selected.has(product._id) ? 'checked' : ''}>
            <span class="w-2.5 h-2.5 shrink-0 rounded-full" style="background:${rarity.color}" title="${rarity.label}"></span>
            <span class="flex-1 min-w-0 truncate text-sm">${escapeHtml(product.title)}</span>
            <span class="shrink-0 text-xs text-gray-400">${formatPrice(product.price)} ₽</span>
          </label>`;
      }).join('')
    : '<p class="text-sm text-gray-500 p-2">Сначала добавьте товары в каталог</p>';

  updateCaseItemsCount();
  openModal('caseFormModal');
}

document.getElementById('caseItemsList').addEventListener('change', updateCaseItemsCount);

document.getElementById('caseForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const title = document.getElementById('caseTitleInput').value.trim();
  const price = Number(document.getElementById('casePriceInput').value);
  const imageUrl = document.getElementById('caseImageInput').value.trim();
  const items = [...document.querySelectorAll('#caseItemsList input:checked')].map((input) => input.value);

  if (!title) {
    return showToast('Введите название кейса', 'warning');
  }
  if (!Number.isInteger(price) || price < 1) {
    return showToast('Цена должна быть целым положительным числом', 'warning');
  }
  if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
    return showToast('Ссылка на картинку должна начинаться с http:// или https://', 'warning');
  }
  if (items.length < 2) {
    return showToast('Выберите минимум 2 предмета', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(editingCaseId ? `/cases/${editingCaseId}` : '/cases', {
      method: editingCaseId ? 'PUT' : 'POST',
      body: { title, price, imageUrl, items }
    });

    closeModal('caseFormModal');
    showToast(data.message, 'success');
    loadCases();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Клики по сетке кейсов (делегирование)
document.getElementById('casesGrid').addEventListener('click', async (event) => {
  // Сначала проверяем кнопки админа: они лежат поверх карточки
  const editButton = event.target.closest('[data-case-edit]');
  if (editButton) {
    const caseData = casesList.find((item) => String(item.id) === editButton.dataset.caseEdit);
    if (caseData) openCaseForm(caseData);
    return;
  }

  const deleteButton = event.target.closest('[data-case-delete]');
  if (deleteButton) {
    const caseData = casesList.find((item) => String(item.id) === deleteButton.dataset.caseDelete);
    if (!caseData) return;

    const confirmed = await confirmDialog({
      title: 'Удаление кейса',
      message: `Удалить кейс «${caseData.title}»? Уже выпавшие предметы останутся у пользователей.`,
      confirmText: 'Удалить',
      danger: true
    });
    if (!confirmed) return;

    try {
      const data = await apiRequest(`/cases/${caseData.id}`, { method: 'DELETE' });
      showToast(data.message, 'success');
      loadCases();
    } catch (err) {
      showToast(err.message, 'error');
    }
    return;
  }

  if (event.target.closest('[data-case-add]')) {
    return openCaseForm();
  }

  const openButton = event.target.closest('[data-case-open]');
  if (openButton) {
    openCaseModal(openButton.dataset.caseOpen);
  }
});

// ==================== ФУТЕР: ИНФОРМАЦИОННЫЕ РАЗДЕЛЫ ====================

// Контакт для раздела "Связаться с нами" — ЗАМЕНИ на свой адрес
const CONTACT_EMAIL = 'vaceslavnenadov@gmail.com';

// Тексты разделов. Это наш собственный статичный HTML (не данные пользователей),
// поэтому его можно вставлять в страницу как есть
const INFO_PAGES = {
  help: {
    title: 'Центр помощи',
    html: `
      <p><b>Как купить скин.</b> Зарегистрируйтесь, войдите в аккаунт и нажмите «Купить» на карточке товара.
         Несколько товаров удобнее сложить в корзину и оплатить одним действием.</p>
      <p><b>Как пополнить баланс.</b> Личный кабинет → «Пополнить». Там же вводится промокод.</p>
      <p><b>Как продать скин.</b> Личный кабинет → «Инвентарь и покупки» → «Продать». Вы получите 80% от стоимости предмета.</p>
      <p><b>Как открыть кейс.</b> Раздел «Кейсы» → выберите кейс → «Открыть». Шансы выпадения указаны в списке содержимого.</p>`
  },
  faq: {
    title: 'Частые вопросы',
    html: `
      <p><b>Это настоящие деньги?</b><br>Нет. MusorShop — учебный проект, баланс и предметы виртуальные.</p>
      <p><b>Почему при продаже возвращается только 80%?</b><br>20% — комиссия магазина за обратный выкуп предмета.</p>
      <p><b>Можно ли использовать промокод дважды?</b><br>Нет, каждый промокод активируется один раз на аккаунт.</p>
      <p><b>Как считаются шансы в кейсах?</b><br>Шанс зависит от редкости предмета. Результат определяет сервер
         в момент открытия, анимация только показывает его.</p>
      <p><b>Меня выбросило из аккаунта. Почему?</b><br>Сессия действует сутки. Она также завершается после смены пароля
         на другом устройстве.</p>`
  },
  contact: {
    title: 'Связаться с нами',
    html: `
      <p>По вопросам работы сайта напишите автору проекта:</p>
      <p><a href="mailto:${CONTACT_EMAIL}" class="text-yellow-500 hover:underline">${CONTACT_EMAIL}</a></p>
      <p>В письме укажите email вашего аккаунта и опишите, что произошло.</p>`
  },
  partners: {
    title: 'Партнёрская программа',
    html: `
      <p>MusorShop — учебный проект, поэтому действующей партнёрской программы у него нет.</p>
      <p>В реальном магазине здесь были бы условия: процент с покупок приглашённых пользователей и личная ссылка партнёра.
         Ближайший аналог на сайте — промокоды, которые администратор создаёт в своей панели.</p>`
  },
  ads: {
    title: 'Реклама',
    html: `
      <p>Рекламные места на сайте не продаются: проект некоммерческий и создан в учебных целях.</p>`
  },
  streamers: {
    title: 'Для стримеров',
    html: `
      <p>Отдельной программы для стримеров нет. Администратор может выпустить именной промокод
         с ограниченным числом активаций, которым стример поделится со зрителями.</p>`
  },
  terms: {
    title: 'Пользовательское соглашение',
    html: `
      <p><b>1. О проекте.</b> MusorShop — учебный проект. Сайт не является магазином
         и не связан с Valve или Steam.</p>
      <p><b>2. Виртуальные средства.</b> Баланс, предметы, кейсы и промокоды не имеют денежной стоимости,
         не покупаются за настоящие деньги и не подлежат выводу или обмену.</p>
      <p><b>3. Аккаунт.</b> Один человек использует один аккаунт. Пользователь сам отвечает за сохранность пароля.</p>
      <p><b>4. Отзывы.</b> Запрещены оскорбления и реклама. Администратор может изменить или удалить отзыв;
         изменённые отзывы помечаются.</p>
      <p><b>5. Блокировка.</b> За нарушение правил администратор может заблокировать аккаунт.</p>`
  },
  privacy: {
    title: 'Политика конфиденциальности',
    html: `
      <p><b>Какие данные хранятся.</b> Email, пароль в виде необратимого хеша (bcrypt), баланс,
         история покупок и операций, отзывы и список избранного.</p>
      <p><b>Чего мы не делаем.</b> Пароль в открытом виде не хранится и не может быть восстановлен.
         Данные не передаются третьим лицам.</p>
      <p><b>Что видно другим.</b> В отзывах email показывается в скрытом виде, например bu***@mail.ru.</p>
      <p><b>Что хранится в браузере.</b> Токен входа, содержимое корзины и настройки отображения каталога.
         Они удаляются при очистке данных сайта в браузере.</p>`
  },
  social: {
    title: 'Мы в соцсетях',
    html: `
      <p>У учебного проекта нет страниц в социальных сетях. Значки показывают, как этот блок выглядел бы
         на настоящем сайте.</p>`
  }
};

// Клик по любой кнопке с атрибутом data-info открывает окно с нужным разделом
document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-info]');
  if (!button) return;

  // Тексты разделов хранятся целиком на двух языках
  const pages = i18n.getLanguage() === 'en' ? INFO_PAGES_EN : INFO_PAGES;
  const page = pages[button.dataset.info];
  if (!page) return;

  document.getElementById('infoTitle').textContent = page.title;
  document.getElementById('infoContent').innerHTML = page.html;
  openModal('infoModal');
});

// ==================== ИНДИКАТОР НАДЁЖНОСТИ ПАРОЛЯ ====================

// Уровни надёжности: подпись, цвет и заполнение полоски
const PASSWORD_LEVELS = [
  { label: 'Слабый пароль',   color: '#ef4444', width: '25%' },
  { label: 'Средний пароль',  color: '#eab308', width: '50%' },
  { label: 'Хороший пароль',  color: '#3b82f6', width: '75%' },
  { label: 'Надёжный пароль', color: '#22c55e', width: '100%' }
];

// Оценка пароля: по баллу за длину от 8, длину от 12, буквы разного регистра, цифры, спецсимволы
function getPasswordLevel(password) {
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[a-zа-яё]/.test(password) && /[A-ZА-ЯЁ]/.test(password)) score += 1;
  if (/\d/.test(password)) score += 1;
  if (/[^A-Za-zА-Яа-яЁё0-9]/.test(password)) score += 1;

  // Пароль короче минимально допустимого всегда слабый
  if (password.length < MIN_PASSWORD_LENGTH) score = 0;

  if (score <= 1) return PASSWORD_LEVELS[0];
  if (score === 2) return PASSWORD_LEVELS[1];
  if (score === 3) return PASSWORD_LEVELS[2];
  return PASSWORD_LEVELS[3];
}

// Добавляет под поле пароля полоску и подпись, которые обновляются при вводе
function attachPasswordMeter(inputId) {
  const input = document.getElementById(inputId);

  const meter = document.createElement('div');
  meter.className = 'hidden mt-2';
  meter.innerHTML = `
    <div class="h-1.5 rounded-full bg-gray-700 overflow-hidden">
      <div class="h-full rounded-full transition-all duration-300" style="width:0"></div>
    </div>
    <p class="mt-1 text-xs"></p>`;

  // Поле обёрнуто в контейнер с кнопкой-глазиком — вставляем индикатор после него
  const anchor = input.closest('.relative') || input;
  anchor.insertAdjacentElement('afterend', meter);

  const bar = meter.querySelector('div > div');
  const label = meter.querySelector('p');

  const update = () => {
    const password = input.value;
    meter.classList.toggle('hidden', password.length === 0);
    if (!password) return;

    const level = getPasswordLevel(password);
    bar.style.width = level.width;
    bar.style.background = level.color;
    label.textContent = level.label;
    label.style.color = level.color;
  };

  input.addEventListener('input', update);
  // После очистки формы индикатор скрывается (reset срабатывает до очистки полей)
  if (input.form) {
    input.form.addEventListener('reset', () => setTimeout(update, 0));
  }
}

attachPasswordMeter('registerPassword'); // регистрация
attachPasswordMeter('newPassword');      // смена пароля

// ==================== ЗАПОМИНАНИЕ СОСТОЯНИЯ КАТАЛОГА ====================

// Сортировка — личная настройка, храним в localStorage (сохраняется надолго).
// Страница и поиск — в sessionStorage (живут, пока открыта вкладка, и переживают F5)
function saveCatalogState() {
  try {
    localStorage.setItem('catalogSort', sortMode);
    sessionStorage.setItem('catalogView', JSON.stringify({ page: currentPage, search: searchQuery }));
  } catch (err) {
    // хранилище недоступно — просто не запоминаем
  }
}

// Восстановление при загрузке страницы. Этот код выполняется раньше,
// чем придут товары с сервера, поэтому первая отрисовка уже учтёт сохранённое
(function restoreCatalogState() {
  try {
    const savedSort = localStorage.getItem('catalogSort');
    if (savedSort && SORTERS[savedSort]) {
      sortMode = savedSort;
      document.getElementById('sortSelect').value = savedSort;
    }

    const saved = JSON.parse(sessionStorage.getItem('catalogView') || 'null');
    if (saved) {
      if (typeof saved.search === 'string') {
        searchQuery = saved.search.slice(0, 100);
        document.getElementById('searchInput').value = searchQuery;
      }
      if (Number.isInteger(saved.page) && saved.page > 0) {
        currentPage = saved.page;
      }
    }
  } catch (err) {
    // повреждённые данные игнорируем — каталог откроется в обычном виде
  }
})();

// ==================== ТЕМЫ ОФОРМЛЕНИЯ ====================

// Три режима: system — как в операционной системе, light — светлая, dark — тёмная
const THEME_MODES = {
  system: { label: 'Системная', icon: 'fa-circle-half-stroke' },
  light:  { label: 'Светлая',   icon: 'fa-sun' },
  dark:   { label: 'Тёмная',    icon: 'fa-moon' }
};
const THEME_ORDER = ['system', 'light', 'dark'];

// Запрос к системе: предпочитает ли пользователь светлое оформление
const systemLightQuery = window.matchMedia('(prefers-color-scheme: light)');

// Выбранный пользователем режим (по умолчанию — системный)
function getThemePreference() {
  try {
    const saved = localStorage.getItem('theme');
    return THEME_MODES[saved] ? saved : 'system';
  } catch (err) {
    return 'system';
  }
}

// Применение темы: выставляет атрибут data-theme у <html> и обновляет кнопку
function applyTheme() {
  const preference = getThemePreference();

  // В системном режиме фактическую тему определяют настройки ОС
  const actual = preference === 'system'
    ? (systemLightQuery.matches ? 'light' : 'dark')
    : preference;

  document.documentElement.setAttribute('data-theme', actual);

  const mode = THEME_MODES[preference];
  const button = document.getElementById('themeBtn');
  button.innerHTML = `<i class="fa-solid ${mode.icon}"></i>`;
  button.title = `Тема: ${mode.label}. Нажмите, чтобы сменить`;
  button.setAttribute('aria-label', `Тема оформления: ${mode.label}`);
}

// Клик по кнопке переключает режимы по кругу: системная → светлая → тёмная
document.getElementById('themeBtn').addEventListener('click', () => {
  const current = getThemePreference();
  const next = THEME_ORDER[(THEME_ORDER.indexOf(current) + 1) % THEME_ORDER.length];

  try {
    localStorage.setItem('theme', next);
  } catch (err) {
    // хранилище недоступно — тема сменится только до перезагрузки
  }

  applyTheme();
  showToast(`Тема: ${THEME_MODES[next].label.toLowerCase()}`, 'info', 2000);
});

// Синхронизация с системой: если в ОС сменили оформление, а у нас выбран
// системный режим — сайт переключается сразу, без перезагрузки
systemLightQuery.addEventListener('change', () => {
  if (getThemePreference() === 'system') {
    applyTheme();
  }
});

applyTheme();

// ==================== ПЕРЕВОД: АНГЛИЙСКИЕ ТЕКСТЫ РАЗДЕЛОВ ФУТЕРА ====================

const INFO_PAGES_EN = {
  help: {
    title: 'Help center',
    html: `
      <p><b>How to buy a skin.</b> Sign up, log in and press Buy on an item card.
         To buy several items at once, add them to the cart and check out.</p>
      <p><b>How to top up the balance.</b> My account → Top up. Promo codes are entered there too.</p>
      <p><b>How to sell a skin.</b> My account → Inventory and purchases → Sell. You receive 80% of the item value.</p>
      <p><b>How to open a case.</b> Cases → choose a case → Open. Drop chances are listed in the case contents.</p>`
  },
  faq: {
    title: 'FAQ',
    html: `
      <p><b>Is this real money?</b><br>No. MusorShop is a student project; the balance and items are virtual.</p>
      <p><b>Why do I get only 80% back when selling?</b><br>20% is the shop commission for buying the item back.</p>
      <p><b>Can I use a promo code twice?</b><br>No, each promo code can be redeemed once per account.</p>
      <p><b>How are case chances calculated?</b><br>The chance depends on the item rarity. The server decides the result
         at the moment of opening; the animation only shows it.</p>
      <p><b>I was logged out. Why?</b><br>A session lasts one day. It also ends after the password is changed
         on another device.</p>`
  },
  contact: {
    title: 'Contact us',
    html: `
      <p>For questions about the site, write to the project author:</p>
      <p><a href="mailto:${CONTACT_EMAIL}" class="text-yellow-500 hover:underline">${CONTACT_EMAIL}</a></p>
      <p>Please include the email of your account and describe what happened.</p>`
  },
  partners: {
    title: 'Affiliate program',
    html: `
      <p>MusorShop is a student project, so it has no active affiliate program.</p>
      <p>A real shop would list its terms here: a share of purchases made by invited users and a personal link.
         The closest equivalent on this site is promo codes, which the administrator creates in the admin panel.</p>`
  },
  ads: {
    title: 'Advertising',
    html: `
      <p>Advertising space is not sold: the project is non-commercial and was created for educational purposes.</p>`
  },
  streamers: {
    title: 'For streamers',
    html: `
      <p>There is no separate program for streamers. The administrator can issue a personal promo code
         with a limited number of activations for a streamer to share with viewers.</p>`
  },
  terms: {
    title: 'Terms of use',
    html: `
      <p><b>1. About the project.</b> MusorShop is a student coursework project. The site is not a shop
         and is not affiliated with Valve or Steam.</p>
      <p><b>2. Virtual funds.</b> The balance, items, cases and promo codes have no monetary value,
         cannot be bought with real money and cannot be withdrawn or exchanged.</p>
      <p><b>3. Account.</b> One person uses one account. Users are responsible for keeping their password safe.</p>
      <p><b>4. Reviews.</b> Insults and advertising are not allowed. The administrator may edit or delete a review;
         edited reviews are marked.</p>
      <p><b>5. Blocking.</b> The administrator may block an account for breaking the rules.</p>`
  },
  privacy: {
    title: 'Privacy policy',
    html: `
      <p><b>What is stored.</b> Email, the password as an irreversible hash (bcrypt), balance,
         purchase and transaction history, reviews and the wishlist.</p>
      <p><b>What we do not do.</b> The password is never stored in plain text and cannot be recovered.
         Data is not shared with third parties.</p>
      <p><b>What others can see.</b> In reviews the email is shown masked, for example bu***@mail.com.</p>
      <p><b>What is kept in the browser.</b> The login token, cart contents and catalog display settings.
         They are removed when you clear the site data in your browser.</p>`
  },
  social: {
    title: 'Social media',
    html: `
      <p>This student project has no social media pages. The icons show what this block would look like
         on a real site.</p>`
  }
};

// Содержимое информационного окна уже приходит на нужном языке —
// просим слой перевода его не трогать
document.getElementById('infoContent').setAttribute('data-no-i18n', '');

// При смене языка перерисовываем график: его подписи рисуются на холсте, а не в HTML
window.addEventListener('i18n:change', () => {
  if (salesChart) renderSalesChart();
});
