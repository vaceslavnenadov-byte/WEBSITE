// cases.js
// Кейсы: список, открытие с рулеткой, управление кейсами

// ==================== КЕЙСЫ ====================

let casesList = [];        // загруженные кейсы
let activeCase = null;     // кейс, открытый в окне
let caseSpinning = false;  // идёт ли сейчас прокрутка рулетки
let editingCaseId = null;  // id редактируемого кейса (null = создаём новый)

const ROULETTE_LENGTH = 60;  // сколько плиток в ленте
const ROULETTE_WIN_INDEX = 52; // на какой плитке лента остановится
const TILE_WIDTH = 112;      // ширина плитки (класс w-28)
const TILE_STEP = 120;       // ширина плитки + промежуток (gap-2)
const SPIN_DURATION = 5000;  // длительность прокрутки, мс

// Шанс в виде текста: "15,98%" или "<0,01%"
function formatChance(chance) {
  if (chance > 0 && chance < 0.01) return '<0,01%';
  return `${chance.toLocaleString('ru-RU', { maximumFractionDigits: 2 })}%`;
}

// ---------- Список кейсов ----------

async function loadCases() {
  const grid = document.getElementById('casesGrid');
  try {
    casesList = await apiRequest('/cases');
  } catch (err) {
    grid.innerHTML = '<p class="col-span-full text-center text-red-400 py-10">Не удалось загрузить кейсы</p>';
    return;
  }
  renderCases();
}

function renderCases() {
  const grid = document.getElementById('casesGrid');
  const isAdmin = currentUser && currentUser.role === 'admin';

  let html = casesList.map((caseData) => {
    const id = escapeHtml(caseData.id);

    const image = caseData.imageUrl
      ? `<img src="${escapeHtml(caseData.imageUrl)}" alt="" loading="lazy" class="w-full h-full object-contain p-3"
              onerror="this.replaceWith(Object.assign(document.createElement('i'), { className: 'fa-solid fa-box-open text-5xl text-yellow-500' }))">`
      : '<i class="fa-solid fa-box-open text-5xl text-yellow-500"></i>';

    const adminButtons = isAdmin
      ? `<div class="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition">
           <button type="button" data-case-edit="${id}" aria-label="Редактировать кейс"
                   class="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white">✎</button>
           <button type="button" data-case-delete="${id}" aria-label="Удалить кейс"
                   class="w-9 h-9 rounded-full bg-red-600 hover:bg-red-500 text-white">✕</button>
         </div>`
      : '';

    return `
      <article class="group relative bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/60 transition">
        <button type="button" data-case-open="${id}" class="block w-full text-left">
          <div class="h-44 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            ${image}
          </div>
          <div class="p-4">
            <h3 class="font-semibold leading-snug">${escapeHtml(caseData.title)}</h3>
            <p class="mt-1 text-sm text-gray-400">Предметов: ${caseData.items.length}</p>
            <p class="mt-3 text-xl font-bold text-yellow-500">${formatPrice(caseData.price)} ₽</p>
          </div>
        </button>
        ${adminButtons}
      </article>`;
  }).join('');

  // Карточка-плюсик для админа
  if (isAdmin) {
    html += `
      <button type="button" data-case-add
              class="min-h-[18rem] flex flex-col items-center justify-center gap-3 rounded-xl
                     border-2 border-dashed border-gray-700 text-gray-500
                     hover:border-yellow-500 hover:text-yellow-500 transition">
        <i class="fa-solid fa-plus text-4xl"></i>
        <span class="font-semibold">Добавить кейс</span>
      </button>`;
  }

  if (!html) {
    html = '<p class="col-span-full text-center text-gray-500 py-10">Кейсов пока нет</p>';
  }

  grid.innerHTML = html;
}

// ---------- Окно кейса ----------

// HTML одной плитки рулетки
function createTile(item) {
  const rarity = getRarity(item);
  const image = item.imageUrl
    ? `<img src="${escapeHtml(item.imageUrl)}" alt="" class="h-14 w-full object-contain" onerror="this.remove()">`
    : '<i class="fa-solid fa-image text-2xl text-gray-600"></i>';

  return `
    <div class="w-28 h-28 shrink-0 rounded-lg bg-gray-800 border-b-4 p-1 flex flex-col items-center justify-center gap-1"
         style="border-color:${rarity.color}">
      ${image}
      <p class="w-full text-center text-[10px] leading-tight text-gray-300 truncate">${escapeHtml(item.title)}</p>
    </div>`;
}

// Случайный предмет с учётом шансов — только для "массовки" в ленте.
// Настоящий результат определяет сервер
function pickRandomItem(items) {
  const total = items.reduce((sum, item) => sum + item.chance, 0);
  let roll = Math.random() * total;
  for (const item of items) {
    roll -= item.chance;
    if (roll <= 0) return item;
  }
  return items[items.length - 1];
}

// Лента в состоянии покоя: несколько случайных плиток без движения
function resetRoulette() {
  const strip = document.getElementById('caseStrip');
  strip.style.transition = 'none';
  strip.style.transform = 'translateX(0)';

  const tiles = [];
  for (let i = 0; i < 10; i++) {
    tiles.push(pickRandomItem(activeCase.items));
  }
  strip.innerHTML = tiles.map(createTile).join('');

  document.getElementById('caseResult').classList.add('hidden');
}

// Кнопка открытия: текст и доступность зависят от роли
function updateCaseOpenButton() {
  const button = document.getElementById('caseOpenBtn');
  if (!activeCase) return;

  const isAdmin = currentUser && currentUser.role === 'admin';
  const isBuyer = currentUser && currentUser.role === 'user';

  button.classList.toggle('hidden', Boolean(isAdmin)); // админ кейсы не открывает

  let text = `Открыть за ${formatPrice(activeCase.price)} ₽`;
  let disabled = caseSpinning;

  if (!isBuyer) {
    text = 'Войдите в аккаунт, чтобы открыть кейс';
    disabled = true;
  } else if (caseSpinning) {
    text = 'Открываем…';
  } else if (activeCase.items.length === 0) {
    text = 'Кейс пуст';
    disabled = true;
  }

  button.textContent = text;
  button.disabled = disabled;
  button.classList.toggle('opacity-50', disabled);
  button.classList.toggle('cursor-not-allowed', disabled);
}

function openCaseModal(caseId) {
  const caseData = casesList.find((item) => String(item.id) === caseId);
  if (!caseData || caseSpinning) return;

  activeCase = caseData;
  document.getElementById('caseModalTitle').textContent = caseData.title;

  // Для админа — средняя стоимость выпадения (помогает подобрать цену кейса)
  const evNote = document.getElementById('caseEvNote');
  const isAdmin = currentUser && currentUser.role === 'admin';
  if (isAdmin) {
    const expected = caseData.items.reduce((sum, item) => sum + item.price * item.chance / 100, 0);
    evNote.textContent =
      `Средняя стоимость выпадающего предмета: ${formatPrice(Math.round(expected))} ₽ при цене кейса ${formatPrice(caseData.price)} ₽`;
  }
  evNote.classList.toggle('hidden', !isAdmin);

  // Содержимое с шансами
  document.getElementById('caseContents').innerHTML = caseData.items.length > 0
    ? caseData.items.map((item) => {
        const rarity = getRarity(item);
        return `
          <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-2 border-l-4" style="border-color:${rarity.color}">
            <div class="flex-1 min-w-0">
              <p class="text-sm font-medium truncate">${escapeHtml(item.title)}</p>
              <p class="text-xs" style="color:${rarity.color}">${rarity.label} · <span class="text-gray-400">${formatPrice(item.price)} ₽</span></p>
            </div>
            <span class="shrink-0 text-sm font-semibold text-gray-200">${formatChance(item.chance)}</span>
          </div>`;
      }).join('')
    : '<p class="col-span-full text-sm text-gray-500">В кейсе нет предметов</p>';

  if (caseData.items.length > 0) {
    resetRoulette();
  } else {
    document.getElementById('caseStrip').innerHTML = '';
    document.getElementById('caseResult').classList.add('hidden');
  }

  updateCaseOpenButton();
  openModal('caseModal');
}

// Прокрутка рулетки до выигранного предмета. Возвращает Promise, который
// завершается, когда лента остановилась
function spinRoulette(wonItem) {
  const strip = document.getElementById('caseStrip');
  const roulette = document.getElementById('caseRoulette');

  // Собираем ленту: случайные предметы, а на заданной позиции — выигранный
  const tiles = [];
  for (let i = 0; i < ROULETTE_LENGTH; i++) {
    tiles.push(i === ROULETTE_WIN_INDEX ? wonItem : pickRandomItem(activeCase.items));
  }

  // Возвращаем ленту в начало без анимации
  strip.style.transition = 'none';
  strip.style.transform = 'translateX(0)';
  strip.innerHTML = tiles.map(createTile).join('');
  void strip.offsetWidth; // заставляем браузер применить стартовое положение

  // Сдвиг, при котором выигранная плитка окажется под центральной меткой.
  // Небольшой случайный разброс, чтобы метка не всегда попадала ровно в середину плитки
  const jitter = Math.floor(Math.random() * 80) - 40;
  const offset = ROULETTE_WIN_INDEX * TILE_STEP + TILE_WIDTH / 2 - roulette.clientWidth / 2 + jitter;

  // Если в системе включено "уменьшение движения" — показываем результат без прокрутки
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const duration = reduceMotion ? 0 : SPIN_DURATION;

  strip.style.transition = `transform ${duration}ms cubic-bezier(0.12, 0.8, 0.2, 1)`;
  strip.style.transform = `translateX(-${offset}px)`;

  return new Promise((resolve) => setTimeout(resolve, duration + 150));
}

// Открытие кейса
async function handleOpenCase() {
  if (caseSpinning || !activeCase) return;

  if (!currentUser || currentUser.role !== 'user') {
    return showToast('Войдите в аккаунт покупателя, чтобы открывать кейсы', 'warning');
  }
  if (currentUser.balance < activeCase.price) {
    return showToast('Недостаточно средств на балансе', 'warning');
  }

  const result = document.getElementById('caseResult');
  caseSpinning = true;
  result.classList.add('hidden');
  updateCaseOpenButton();

  try {
    // Сервер списывает деньги и сразу сообщает, что выпало
    const data = await apiRequest(`/cases/${activeCase.id}/open`, { method: 'POST' });

    currentUser.balance = data.balance;
    updateUI();

    // Анимация только показывает уже известный результат
    await spinRoulette(data.item);

    const rarity = getRarity(data.item);
    result.innerHTML = `
      <p class="text-sm text-gray-400">Вам выпало</p>
      <p class="mt-1 text-xl font-bold" style="color:${rarity.color}">${escapeHtml(data.item.title)}</p>
      <p class="text-sm text-gray-300">${rarity.label} · стоимость ${formatPrice(data.item.price)} ₽</p>
      <p class="mt-2 text-xs text-gray-500">Предмет добавлен в инвентарь в личном кабинете</p>`;
    result.classList.remove('hidden');

    playSuccessSound();
    showToast(`Выпало: ${data.item.title}`, 'success', 5000);
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    caseSpinning = false;
    updateCaseOpenButton();
  }
}

document.getElementById('caseOpenBtn').addEventListener('click', handleOpenCase);

// ---------- Админ: создание, изменение, удаление ----------

function updateCaseItemsCount() {
  document.getElementById('caseItemsCount').textContent =
    document.querySelectorAll('#caseItemsList input:checked').length;
}

// Открытие формы кейса. Без аргумента — создание, с кейсом — редактирование
async function openCaseForm(caseData = null) {
  editingCaseId = caseData ? String(caseData.id) : null;

  document.getElementById('caseForm').reset();
  document.getElementById('caseFormTitle').textContent = caseData ? 'Редактировать кейс' : 'Новый кейс';
  document.getElementById('caseSubmitBtn').textContent = caseData ? 'Сохранить изменения' : 'Создать';

  if (caseData) {
    document.getElementById('caseTitleInput').value = caseData.title;
    document.getElementById('casePriceInput').value = caseData.price;
    document.getElementById('caseImageInput').value = caseData.imageUrl || '';
  }

  const selected = new Set(caseData ? caseData.items.map((item) => String(item.id)) : []);

  // В каталоге загружена только одна страница, а форме нужны все товары —
  // запрашиваем их краткий список отдельно
  let allProducts;
  try {
    allProducts = await apiRequest('/products/brief');
  } catch (err) {
    return showToast(err.message, 'error');
  }

  // Список всех товаров с галочками, от дешёвых к дорогим
  const sorted = [...allProducts].sort((a, b) => a.price - b.price);
  document.getElementById('caseItemsList').innerHTML = sorted.length > 0
    ? sorted.map((product) => {
        const rarity = getRarity(product);
        return `
          <label class="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-700 cursor-pointer">
            <input type="checkbox" value="${escapeHtml(product._id)}" class="accent-yellow-500"
                   ${selected.has(product._id) ? 'checked' : ''}>
            <span class="w-2.5 h-2.5 shrink-0 rounded-full" style="background:${rarity.color}" title="${rarity.label}"></span>
            <span class="flex-1 min-w-0 truncate text-sm">${escapeHtml(product.title)}</span>
            <span class="shrink-0 text-xs text-gray-400">${formatPrice(product.price)} ₽</span>
          </label>`;
      }).join('')
    : '<p class="text-sm text-gray-500 p-2">Сначала добавьте товары в каталог</p>';

  updateCaseItemsCount();
  openModal('caseFormModal');
}

document.getElementById('caseItemsList').addEventListener('change', updateCaseItemsCount);

document.getElementById('caseForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const title = document.getElementById('caseTitleInput').value.trim();
  const price = Number(document.getElementById('casePriceInput').value);
  const imageUrl = document.getElementById('caseImageInput').value.trim();
  const items = [...document.querySelectorAll('#caseItemsList input:checked')].map((input) => input.value);

  if (!title) {
    return showToast('Введите название кейса', 'warning');
  }
  if (!Number.isInteger(price) || price < 1) {
    return showToast('Цена должна быть целым положительным числом', 'warning');
  }
  if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
    return showToast('Ссылка на картинку должна начинаться с http:// или https://', 'warning');
  }
  if (items.length < 2) {
    return showToast('Выберите минимум 2 предмета', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(editingCaseId ? `/cases/${editingCaseId}` : '/cases', {
      method: editingCaseId ? 'PUT' : 'POST',
      body: { title, price, imageUrl, items }
    });

    closeModal('caseFormModal');
    showToast(data.message, 'success');
    loadCases();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Клики по сетке кейсов (делегирование)
document.getElementById('casesGrid').addEventListener('click', async (event) => {
  // Сначала проверяем кнопки админа: они лежат поверх карточки
  const editButton = event.target.closest('[data-case-edit]');
  if (editButton) {
    const caseData = casesList.find((item) => String(item.id) === editButton.dataset.caseEdit);
    if (caseData) openCaseForm(caseData);
    return;
  }

  const deleteButton = event.target.closest('[data-case-delete]');
  if (deleteButton) {
    const caseData = casesList.find((item) => String(item.id) === deleteButton.dataset.caseDelete);
    if (!caseData) return;

    const confirmed = await confirmDialog({
      title: 'Удаление кейса',
      message: `Удалить кейс «${caseData.title}»? Уже выпавшие предметы останутся у пользователей.`,
      confirmText: 'Удалить',
      danger: true
    });
    if (!confirmed) return;

    try {
      const data = await apiRequest(`/cases/${caseData.id}`, { method: 'DELETE' });
      showToast(data.message, 'success');
      loadCases();
    } catch (err) {
      showToast(err.message, 'error');
    }
    return;
  }

  if (event.target.closest('[data-case-add]')) {
    return openCaseForm();
  }

  const openButton = event.target.closest('[data-case-open]');
  if (openButton) {
    openCaseModal(openButton.dataset.caseOpen);
  }
});
