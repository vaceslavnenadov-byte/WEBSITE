// progress.js
// Уровень пользователя и ежедневный бонус

// ==================== ВСПОМОГАТЕЛЬНОЕ ====================

// Оставшееся время в виде "5 ч 12 мин" или "12 мин"
function formatDuration(ms) {
  const totalMinutes = Math.max(1, Math.ceil(ms / 60000));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (hours === 0) return `${minutes} мин`;
  return minutes === 0 ? `${hours} ч` : `${hours} ч ${minutes} мин`;
}

// Доступен ли бонус прямо сейчас. Сервер сообщает время следующего бонуса (nextAt),
// поэтому проверяем по часам: бонус мог стать доступен, пока страница была открыта
function isBonusAvailable() {
  const bonus = currentUser && currentUser.bonus;
  if (!bonus) return false;
  return bonus.available || new Date(bonus.nextAt).getTime() <= Date.now();
}

// ==================== ОТРИСОВКА ====================

// Карточка уровня и бонуса в личном кабинете
function renderProgress() {
  const card = document.getElementById('progressCard');
  const visible = Boolean(currentUser && currentUser.role === 'user' && currentUser.progress);
  card.classList.toggle('hidden', !visible);
  if (!visible) return;

  // ---------- Уровень ----------
  const progress = currentUser.progress;
  document.getElementById('progressLevel').textContent = progress.level;
  document.getElementById('progressXp').textContent = formatPrice(progress.xp);
  document.getElementById('progressBar').style.width =
    `${Math.min(100, Math.round(progress.levelXp / progress.levelSize * 100))}%`;
  document.getElementById('progressHint').textContent =
    `До уровня ${progress.level + 1} осталось ${formatPrice(progress.toNext)} XP. Опыт даётся за покупки: 1 XP за каждые 100 ₽`;

  // ---------- Бонус ----------
  const bonus = currentUser.bonus;
  const available = isBonusAvailable();
  const hint = document.getElementById('bonusHint');
  const button = document.getElementById('bonusClaimBtn');

  hint.textContent = available
    ? `Доступно ${formatPrice(bonus.amount)} ₽ · серия дней: ${bonus.nextStreak}`
    : `Следующий бонус через ${formatDuration(new Date(bonus.nextAt).getTime() - Date.now())} · серия дней: ${bonus.streak}`;

  button.disabled = !available;
  button.classList.toggle('opacity-50', !available);
  button.classList.toggle('cursor-not-allowed', !available);
}

// Кнопка-подарок в шапке: видна, только когда бонус можно забрать
function updateBonusButton() {
  document.getElementById('bonusBtn').classList.toggle('hidden', !isBonusAvailable());
}

// ==================== ПОЛУЧЕНИЕ БОНУСА ====================

async function claimDailyBonus() {
  if (!currentUser || currentUser.role !== 'user') return;

  try {
    const data = await apiRequest('/auth/bonus', { method: 'POST' });

    // Сервер возвращает обновлённые данные пользователя: баланс, опыт, состояние бонуса
    currentUser = data.user;
    updateUI();
    playSuccessSound();
    showToast(data.message, 'success', 5000);

    // Если открыт кабинет — обновляем его карточки и историю операций
    if (!document.getElementById('profileView').classList.contains('hidden')) {
      fillProfile();
      loadHistory(true);
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}

document.getElementById('bonusClaimBtn').addEventListener('click', claimDailyBonus);
document.getElementById('bonusBtn').addEventListener('click', claimDailyBonus);
