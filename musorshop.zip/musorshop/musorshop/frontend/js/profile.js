// profile.js
// Личный кабинет: инвентарь, пополнение, промокоды покупателя, история операций

// ==================== ЛИЧНЫЙ КАБИНЕТ ====================

let myPurchases = []; // история покупок текущего пользователя

// Формат даты: 02.10.2026, 17:51
function formatDate(value) {
  return new Date(value).toLocaleString('ru-RU', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Заполняет поля личного кабинета данными текущего пользователя
function fillProfile() {
  if (!currentUser) return;
  const isAdmin = currentUser.role === 'admin';

  document.getElementById('profileEmail').textContent = currentUser.email;
  document.getElementById('profileRole').textContent = isAdmin ? 'Администратор' : 'Покупатель';
  document.getElementById('profileBalance').textContent = formatPrice(currentUser.balance);

  // Панель администратора — только для админа
  document.getElementById('adminSection').classList.toggle('hidden', !isAdmin);

  // Админ не покупает, поэтому покупки и избранное ему не показываем
  document.getElementById('purchasesSection').classList.toggle('hidden', isAdmin);
  document.getElementById('wishlistSection').classList.toggle('hidden', isAdmin);

  renderProgress(); // карточка уровня и ежедневного бонуса
}

// Загрузка и отрисовка избранного в личном кабинете
async function loadWishlist() {
  const list = document.getElementById('wishlistList');
  list.innerHTML = '<p class="text-sm text-gray-500">Загрузка…</p>';

  let items;
  try {
    items = await apiRequest('/products/my-wishlist');
  } catch (err) {
    list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить избранное</p>';
    return;
  }

  if (items.length === 0) {
    list.innerHTML = '<p class="text-sm text-gray-500">В избранном пока пусто</p>';
    return;
  }

  list.innerHTML = items.map((item) => {
    const image = item.imageUrl
      ? `<img src="${escapeHtml(item.imageUrl)}" alt="" class="w-full h-full object-contain" onerror="this.remove()">`
      : '<i class="fa-solid fa-image text-gray-600"></i>';

    return `
      <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-3">
        <div class="w-12 h-12 shrink-0 rounded bg-gray-900 flex items-center justify-center overflow-hidden">
          ${image}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium truncate">${escapeHtml(item.title)}</p>
          <p class="text-xs text-gray-400">
            ${formatPrice(item.price)} ₽ ·
            ${item.quantity > 0 ? `в наличии: ${item.quantity}` : '<span class="text-red-400">нет в наличии</span>'}
          </p>
        </div>
        <button type="button" data-wishlist-remove="${escapeHtml(item._id)}"
                class="shrink-0 w-9 h-9 rounded-full bg-gray-900 text-red-500 hover:bg-gray-700 transition"
                title="Убрать из избранного" aria-label="Убрать из избранного">
          <i class="fa-solid fa-heart"></i>
        </button>
      </div>`;
  }).join('');
}

let purchaseFilter = 'all'; // какой список показываем: all | active | sold

// Сводка по инвентарю: количество, стоимость, потрачено, получено
function renderInventorySummary() {
  const active = myPurchases.filter((purchase) => purchase.status === 'active');
  // Проданные: магазину (sold) и на площадке (traded)
  const sold = myPurchases.filter((purchase) => purchase.status === 'sold' || purchase.status === 'traded');
  const sum = (list, getValue) => list.reduce((total, item) => total + getValue(item), 0);

  document.getElementById('invCount').textContent = active.length;
  document.getElementById('invValue').textContent = formatPrice(sum(active, (p) => p.price));
  // Считаем реально заплаченное (paid): цену кейса или цену лота, а не стоимость предмета
  document.getElementById('invSpent').textContent =
    formatPrice(sum(myPurchases, (p) => (p.paid ?? p.price)));
  // Вырученное: для площадки сумма записана в soldFor, для магазина это 80% стоимости
  document.getElementById('invEarned').textContent =
    formatPrice(sum(sold, (p) => (p.soldFor ?? Math.floor(p.price * SELL_RATE))));
}

// Отрисовка списка покупок с учётом выбранного фильтра
function renderPurchases() {
  const list = document.getElementById('purchasesList');

  // Подсветка активной кнопки фильтра
  document.querySelectorAll('#purchaseFilters [data-purchase-filter]').forEach((button) => {
    const active = button.dataset.purchaseFilter === purchaseFilter;
    button.classList.toggle('bg-yellow-500', active);
    button.classList.toggle('text-black', active);
    button.classList.toggle('bg-gray-800', !active);
    button.classList.toggle('text-gray-300', !active);
  });

  // Какие статусы показывает каждый фильтр
  const statusesByFilter = {
    active: ['active'],
    listed: ['listed'],
    sold: ['sold', 'traded', 'contracted']
  };
  const items = purchaseFilter === 'all'
    ? myPurchases
    : myPurchases.filter((purchase) => statusesByFilter[purchaseFilter].includes(purchase.status));

  if (items.length === 0) {
    const emptyText = {
      all: 'Покупок пока нет',
      active: 'В инвентаре пусто',
      listed: 'На площадке нет ваших предметов',
      sold: 'Проданных предметов нет'
    }[purchaseFilter];
    list.innerHTML = `<p class="col-span-full text-sm text-gray-500">${emptyText}</p>`;
    return;
  }

  // Откуда предмет: подпись после даты
  const sourceLabels = { case: ' · из кейса', market: ' · с площадки', contract: ' · по контракту' };

  list.innerHTML = items.map((purchase) => {
    const id = escapeHtml(purchase._id);

    const image = purchase.productImage
      ? `<img src="${escapeHtml(purchase.productImage)}" alt="" class="w-full h-full object-contain" onerror="this.remove()">`
      : '<i class="fa-solid fa-image text-gray-600"></i>';

    // Справа — действия или плашка состояния
    let action;
    if (purchase.status === 'active') {
      action = `
        <div class="shrink-0 flex flex-col gap-1">
          <button type="button" data-sell-id="${id}"
                  class="px-3 py-1.5 rounded-lg bg-green-600 text-xs font-semibold hover:bg-green-500 transition">
            Продать за ${formatPrice(Math.floor(purchase.price * SELL_RATE))} ₽
          </button>
          <button type="button" data-list-id="${id}" title="Выставить на торговую площадку"
                  class="px-3 py-1.5 rounded-lg bg-gray-900 border border-gray-700 text-xs font-semibold hover:border-yellow-500 transition">
            На площадку
          </button>
        </div>`;
    } else if (purchase.status === 'listed') {
      action = `
        <button type="button" data-go-market title="Мои лоты"
                class="shrink-0 px-3 py-1.5 rounded-lg bg-blue-600 text-xs font-semibold hover:bg-blue-500 transition">
          НА ПЛОЩАДКЕ
        </button>`;
    } else {
      action = `
        <span class="shrink-0 px-3 py-1.5 rounded-lg bg-gray-700 text-xs font-semibold text-gray-400">
          ${{ traded: 'ПРОДАНО НА ПЛОЩАДКЕ', contracted: 'ОБМЕНЯН ПО КОНТРАКТУ' }[purchase.status] || 'ПРОДАНО'}
        </span>`;
    }

    return `
      <div class="flex items-center gap-3 bg-gray-800 rounded-lg p-3">
        <div class="w-12 h-12 shrink-0 rounded bg-gray-900 flex items-center justify-center overflow-hidden">
          ${image}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium truncate">${escapeHtml(purchase.productTitle)}</p>
          <p class="text-xs text-gray-400">
            ${formatPrice(purchase.price)} ₽ · ${formatDate(purchase.purchasedAt)}${sourceLabels[purchase.source] || ''}
          </p>
        </div>
        ${action}
      </div>`;
  }).join('');
}

// Загрузка истории покупок с сервера
async function loadPurchases() {
  const list = document.getElementById('purchasesList');
  list.innerHTML = '<p class="col-span-full text-sm text-gray-500">Загрузка…</p>';

  try {
    myPurchases = await apiRequest('/products/my-purchases');
  } catch (err) {
    list.innerHTML = '<p class="col-span-full text-sm text-red-400">Не удалось загрузить покупки</p>';
    return;
  }

  renderInventorySummary();
  renderPurchases();
}

// Переход в личный кабинет (кнопка в шапке)
function openProfileModal() {
  if (!currentUser) return;
  location.hash = '#profile';
}

// Загрузка данных для экрана кабинета. Вызывается при каждом его открытии
async function loadProfilePage() {
  if (!currentUser) return;

  // Сразу показываем то, что знаем
  fillProfile();

  // Затем подтягиваем свежие данные с сервера
  try {
    currentUser = await apiRequest('/auth/me');
    fillProfile();
    updateUI();
  } catch (err) {
    showToast(err.message, 'error');
    return;
  }

  if (currentUser.role === 'user') {
    loadPurchases();
    loadWishlist();
  } else if (currentUser.role === 'admin') {
    loadAdminPanel();
  }

  loadHistory(true);
}

document.getElementById('profileBtn').addEventListener('click', openProfileModal);

// Клик по кнопке "Продать" в истории покупок (делегирование)
document.getElementById('purchasesList').addEventListener('click', async (event) => {
  // Плашка "НА ПЛОЩАДКЕ" ведёт к своим лотам
  if (event.target.closest('[data-go-market]')) {
    return openMyLots();
  }

  // Кнопка "На площадку" открывает окно с выбором цены
  const listButton = event.target.closest('[data-list-id]');
  if (listButton) {
    const item = myPurchases.find((entry) => entry._id === listButton.dataset.listId);
    if (item) openListingModal(item);
    return;
  }

  // Кнопка "Продать" — выкуп магазином за 80%
  const button = event.target.closest('[data-sell-id]');
  if (!button) return;

  const purchase = myPurchases.find((item) => item._id === button.dataset.sellId);
  if (!purchase) return;

  button.disabled = true;
  const sold = await handleSellProduct(purchase);
  if (sold) {
    fillProfile();   // обновляем баланс в кабинете
    loadPurchases(); // перерисовываем список — появится плашка "ПРОДАНО"
    loadHistory(true); // в истории появится запись о продаже
  } else {
    button.disabled = false;
  }
});

// ==================== ПОПОЛНЕНИЕ БАЛАНСА ====================

const MAX_DEPOSIT = 1000000;

document.getElementById('depositBtn').addEventListener('click', () => {
  document.getElementById('depositForm').reset();
  openModal('depositModal');
});

// Быстрые кнопки подставляют сумму в поле ввода
document.querySelectorAll('.deposit-quick').forEach((button) => {
  button.addEventListener('click', () => {
    document.getElementById('depositAmount').value = button.dataset.amount;
  });
});

document.getElementById('depositForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const amount = Number(document.getElementById('depositAmount').value);

  if (!Number.isInteger(amount) || amount <= 0) {
    return showToast('Введите сумму целым положительным числом', 'warning');
  }
  if (amount > MAX_DEPOSIT) {
    return showToast(`Максимальная сумма пополнения — ${formatPrice(MAX_DEPOSIT)} ₽`, 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/auth/deposit', {
      method: 'POST',
      body: { amount }
    });

    currentUser.balance = data.balance;
    updateUI();
    fillProfile();
    closeModal('depositModal');
    showToast(`Баланс пополнен на ${formatPrice(amount)} ₽`, 'success');
    loadHistory(true);
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== ПРОМОКОДЫ ====================

// ---------- Покупатель: активация промокода ----------

// Админу поле промокода в окне пополнения не показываем
document.getElementById('depositBtn').addEventListener('click', () => {
  const isAdmin = currentUser && currentUser.role === 'admin';
  document.getElementById('promoSection').classList.toggle('hidden', isAdmin);
  document.getElementById('promoForm').reset();
});

document.getElementById('promoForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const code = document.getElementById('promoCodeInput').value.trim().toUpperCase();
  if (!code) {
    return showToast('Введите промокод', 'warning');
  }

  const body = { code };

  // Если в поле суммы что-то введено — передаём её на сервер.
  // Она понадобится, если промокод окажется процентным
  const amountRaw = document.getElementById('depositAmount').value.trim();
  if (amountRaw !== '') {
    const depositAmount = Number(amountRaw);
    if (!Number.isInteger(depositAmount) || depositAmount <= 0) {
      return showToast('Введите сумму целым положительным числом', 'warning');
    }
    if (depositAmount > MAX_DEPOSIT) {
      return showToast(`Максимальная сумма пополнения — ${formatPrice(MAX_DEPOSIT)} ₽`, 'warning');
    }
    body.depositAmount = depositAmount;
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/promo/redeem', { method: 'POST', body });

    currentUser.balance = data.balance;
    updateUI();
    fillProfile();
    form.reset();

    // Процентный промокод уже пополнил баланс на введённую сумму — очищаем поле,
    // чтобы пользователь случайно не пополнил второй раз
    if (data.type === 'percent') {
      document.getElementById('depositForm').reset();
    }

    closeModal('depositModal');
    showToast(data.message, 'success', 5000);
    loadHistory(true);
  } catch (err) {
    showToast(err.message, 'error', 6000);
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== ИСТОРИЯ ОПЕРАЦИЙ ====================

// Оформление типов операций: подпись и иконка
const TRANSACTION_TYPES = {
  deposit:    { label: 'Пополнение',    icon: 'fa-wallet' },
  purchase:   { label: 'Покупка',       icon: 'fa-cart-shopping' },
  sale:       { label: 'Продажа',       icon: 'fa-hand-holding-dollar' },
  promo:      { label: 'Промокод',      icon: 'fa-ticket' },
  adjustment: { label: 'Корректировка', icon: 'fa-sliders' },
  case:       { label: 'Кейс',          icon: 'fa-box-open' },
  market_buy:  { label: 'Покупка на площадке', icon: 'fa-right-left' },
  market_sale: { label: 'Продажа на площадке', icon: 'fa-right-left' },
  bonus:       { label: 'Ежедневный бонус',    icon: 'fa-gift' }
};

// HTML одной строки операции. showUser — показывать ли email (для журнала админа)
function createTransactionRow(item, showUser) {
  const type = TRANSACTION_TYPES[item.type] || { label: item.type, icon: 'fa-circle' };
  const isIncome = item.amount >= 0;

  const details = [
    showUser ? escapeHtml(item.userEmail) : '',
    escapeHtml(item.description),
    formatDate(item.createdAt)
  ].filter(Boolean).join(' · ');

  return `
    <div class="flex items-center gap-3 bg-gray-900 border border-gray-800 rounded-lg p-3">
      <div class="w-10 h-10 shrink-0 rounded-full bg-gray-800 flex items-center justify-center text-gray-300">
        <i class="fa-solid ${type.icon}"></i>
      </div>
      <div class="flex-1 min-w-0">
        <p class="text-sm font-medium">${escapeHtml(type.label)}</p>
        <p class="text-xs text-gray-400 truncate">${details}</p>
      </div>
      <div class="shrink-0 text-right">
        <p class="text-sm font-semibold ${isIncome ? 'text-green-500' : 'text-red-400'}">
          ${isIncome ? '+' : '−'}${formatPrice(Math.abs(item.amount))} ₽
        </p>
        <p class="text-xs text-gray-500">Баланс: ${formatPrice(item.balanceAfter)} ₽</p>
      </div>
    </div>`;
}

// Общая загрузка одной "порции" операций в указанный список.
// reset = true — начать с первой страницы и заменить содержимое списка
async function loadTransactions({ url, listId, moreBtnId, showUser, reset }) {
  const list = document.getElementById(listId);
  const moreBtn = document.getElementById(moreBtnId);

  let data;
  try {
    data = await apiRequest(url);
  } catch (err) {
    if (reset) {
      list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить операции</p>';
    }
    return;
  }

  const html = data.items.map((item) => createTransactionRow(item, showUser)).join('');

  if (reset) {
    list.innerHTML = html || '<p class="text-sm text-gray-500">Операций пока нет</p>';
  } else {
    list.insertAdjacentHTML('beforeend', html);
  }

  // Кнопка "Показать ещё" видна, пока на сервере остаются записи
  moreBtn.classList.toggle('hidden', !data.hasMore);
}

// ---------- Своя история в кабинете ----------

let historyPage = 1;

async function loadHistory(reset = false) {
  if (!currentUser) return;
  // Если кабинет сейчас не открыт — загружать нечего
  if (document.getElementById('profileView').classList.contains('hidden')) return;

  if (reset) historyPage = 1;

  await loadTransactions({
    url: `/transactions/my?page=${historyPage}`,
    listId: 'historyList',
    moreBtnId: 'historyMoreBtn',
    showUser: false,
    reset
  });
}

document.getElementById('historyMoreBtn').addEventListener('click', () => {
  historyPage += 1;
  loadHistory(false);
});

// ---------- Журнал всех операций (админ) ----------

let logPage = 1;

async function loadAdminLog(reset = false) {
  if (!currentUser || currentUser.role !== 'admin') return;

  if (reset) logPage = 1;

  const type = document.getElementById('logTypeFilter').value;
  const query = `page=${logPage}${type ? `&type=${encodeURIComponent(type)}` : ''}`;

  await loadTransactions({
    url: `/transactions/admin?${query}`,
    listId: 'logList',
    moreBtnId: 'logMoreBtn',
    showUser: true,
    reset
  });
}

document.getElementById('logMoreBtn').addEventListener('click', () => {
  logPage += 1;
  loadAdminLog(false);
});

// Смена фильтра по типу — загружаем журнал заново
document.getElementById('logTypeFilter').addEventListener('change', () => loadAdminLog(true));
