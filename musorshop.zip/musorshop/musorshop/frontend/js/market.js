// market.js
// Торговая площадка: лоты пользователей, покупка, выставление предмета, история цен

// ==================== СОСТОЯНИЕ ====================

let marketItems = [];        // лоты текущей страницы
let marketPage = 1;          // текущая страница
let marketPages = 1;         // всего страниц
let marketSearch = '';       // поиск по названию
let marketSort = 'newest';   // сортировка
let marketRarity = '';       // фильтр по редкости
let marketMine = false;      // показывать только свои лоты
let marketFeePercent = 5;    // комиссия магазина, % (точное значение сообщает сервер)
let marketRequestId = 0;     // номер последнего запроса (защита от ответов не по порядку)

let listingPurchase = null;  // предмет, который сейчас выставляется на продажу
let priceChart = null;       // график истории цен

// ==================== СПИСОК ЛОТОВ ====================

// Загрузка страницы лотов с сервера
async function loadMarket() {
  const grid = document.getElementById('marketGrid');
  const isBuyer = currentUser && currentUser.role === 'user';

  // Галочка "мои лоты" доступна только покупателю
  document.getElementById('marketMineLabel').classList.toggle('hidden', !isBuyer);
  if (marketMine && !isBuyer) {
    marketMine = false;
    document.getElementById('marketMine').checked = false;
  }

  const params = new URLSearchParams();
  params.set('page', marketPage);
  params.set('sort', marketSort);
  if (marketSearch.trim()) params.set('search', marketSearch.trim());
  if (marketRarity) params.set('rarity', marketRarity);
  if (marketMine) params.set('mine', '1');

  const requestId = ++marketRequestId;

  let data;
  try {
    data = await apiRequest(`/market?${params.toString()}`);
  } catch (err) {
    if (requestId !== marketRequestId) return;
    grid.innerHTML = '<p class="col-span-full text-center text-red-400 py-10">Не удалось загрузить лоты</p>';
    return;
  }
  if (requestId !== marketRequestId) return; // уже отправлен более новый запрос

  marketItems = data.items;
  marketPage = data.page;
  marketPages = data.pages;
  marketFeePercent = data.feePercent;

  document.getElementById('marketTotal').textContent = data.total;
  document.getElementById('marketFeeNote').textContent = marketFeePercent;
  renderMarket();
}

// HTML одной карточки лота
function createLotCard(lot) {
  const id = escapeHtml(lot.id);
  const rarity = getRarity(lot);
  const isBuyer = currentUser && currentUser.role === 'user';
  const isAdmin = currentUser && currentUser.role === 'admin';

  const image = lot.imageUrl
    ? `<img src="${escapeHtml(lot.imageUrl)}" alt="${escapeHtml(lot.title)}" loading="lazy"
            class="w-full h-full object-contain p-3"
            onerror="this.replaceWith(Object.assign(document.createElement('i'), { className: 'fa-solid fa-image text-4xl text-gray-700' }))">`
    : '<i class="fa-solid fa-image text-4xl text-gray-700"></i>';

  // Строка характеристик: редкость и качество
  const meta = [rarity.label, WEAR_INFO[lot.wear]].filter(Boolean).join(' · ');

  // Насколько цена лота отличается от цены в магазине
  let compare = '';
  if (lot.itemValue > 0) {
    const diff = Math.round((lot.price - lot.itemValue) / lot.itemValue * 100);
    if (diff < 0) compare = `<span class="text-green-500">${diff}%</span>`;
    if (diff > 0) compare = `<span class="text-red-400">+${diff}%</span>`;
  }

  // Основная кнопка зависит от того, чей это лот и кто смотрит
  let action = '';
  if (lot.isMine || isAdmin) {
    action = `<button type="button" data-lot-cancel="${id}"
                      class="flex-1 py-2 rounded-lg bg-gray-800 border border-gray-700 text-sm font-medium hover:bg-gray-700 transition">
                Снять с продажи
              </button>`;
  } else if (isBuyer) {
    action = `<button type="button" data-lot-buy="${id}"
                      class="flex-1 py-2 rounded-lg bg-yellow-500 text-black text-sm font-semibold hover:bg-yellow-400 transition">
                Купить
              </button>`;
  }

  return `
    <article class="relative flex flex-col bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/60 transition">
      <div class="relative h-40 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
        ${image}
        ${lot.isMine
          ? '<span class="absolute top-2 left-2 px-2 py-0.5 rounded bg-blue-600 text-white text-[10px] font-bold">ВАШ ЛОТ</span>'
          : ''}
        ${lot.statTrak
          ? '<span class="absolute bottom-3 left-2 px-2 py-0.5 rounded bg-orange-500 text-black text-[10px] font-bold">StatTrak™</span>'
          : ''}
        <div class="absolute bottom-0 inset-x-0 h-1" style="background:${rarity.color}"></div>
      </div>
      <div class="flex flex-col flex-1 p-4">
        <h3 class="font-semibold leading-snug">${escapeHtml(lot.title)}</h3>
        <p class="text-xs font-medium" style="color:${rarity.color}">${meta}</p>
        <p class="mt-2 text-xs text-gray-400">Продавец: ${escapeHtml(lot.seller)}</p>
        <p class="text-xs text-gray-400">Цена в магазине: ${formatPrice(lot.itemValue)} ₽</p>
        <div class="mt-auto pt-3 flex items-end justify-between gap-2">
          <p class="text-xl font-bold text-yellow-500">${formatPrice(lot.price)} ₽</p>
          <p class="text-xs font-semibold">${compare}</p>
        </div>
        <div class="mt-3 flex gap-2">
          <button type="button" data-lot-history="${id}" title="История цен" aria-label="История цен"
                  class="shrink-0 w-10 rounded-lg bg-gray-800 border border-gray-700 text-sm text-gray-300 hover:border-yellow-500 transition">
            <i class="fa-solid fa-chart-line"></i>
          </button>
          ${action}
        </div>
      </div>
    </article>`;
}

// Отрисовка сетки лотов и пагинации
function renderMarket() {
  const grid = document.getElementById('marketGrid');

  if (marketItems.length === 0) {
    grid.innerHTML = `
      <p class="col-span-full text-center text-gray-500 py-10">
        ${marketMine ? 'У вас нет активных лотов' : 'Лотов пока нет'}
      </p>`;
  } else {
    grid.innerHTML = marketItems.map(createLotCard).join('');
  }

  // Пагинация (правила сокращения номеров те же, что в каталоге)
  const pagination = document.getElementById('marketPagination');
  if (marketPages <= 1) {
    pagination.innerHTML = '';
    return;
  }

  const base = 'min-w-[2.5rem] px-3 py-2 rounded-lg text-sm font-medium transition';
  const normal = 'bg-gray-900 border border-gray-800 text-gray-300 hover:border-yellow-500';
  const active = 'bg-yellow-500 text-black';

  pagination.innerHTML = getPageNumbers(marketPages, marketPage).map((item) => (
    item === '...'
      ? '<span class="px-2 text-gray-500">…</span>'
      : `<button type="button" data-market-page="${item}" ${item === marketPage ? 'aria-current="page"' : ''}
                 class="${base} ${item === marketPage ? active : normal}">${item}</button>`
  )).join('');
}

// ==================== ПОКУПКА И СНЯТИЕ ЛОТА ====================

async function buyLot(lot, button) {
  if (currentUser.balance < lot.price) {
    return showToast('Недостаточно средств на балансе', 'warning');
  }

  const confirmed = await confirmDialog({
    title: 'Покупка на площадке',
    message: `Купить «${lot.title}» у продавца ${lot.seller} за ${formatPrice(lot.price)} ₽?`,
    confirmText: 'Купить'
  });
  if (!confirmed) return;

  button.disabled = true;
  try {
    const data = await apiRequest(`/market/${lot.id}/buy`, { method: 'POST' });

    currentUser.balance = data.balance;
    updateUI();
    playSuccessSound();
    showToast(`${data.message}. Остаток на балансе: ${formatPrice(data.balance)} ₽`, 'success', 5000);
  } catch (err) {
    showToast(err.message, 'error');
  }
  // В любом случае обновляем список: лот куплен нами или кем-то другим
  loadMarket();
}

async function cancelLot(lot) {
  const confirmed = await confirmDialog({
    title: 'Снятие лота',
    message: `Снять «${lot.title}» с продажи? Предмет вернётся в инвентарь владельца.`,
    confirmText: 'Снять с продажи',
    danger: true
  });
  if (!confirmed) return;

  try {
    const data = await apiRequest(`/market/${lot.id}`, { method: 'DELETE' });
    showToast(data.message, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
  loadMarket();
}

// Клики по карточкам лотов (делегирование)
document.getElementById('marketGrid').addEventListener('click', (event) => {
  const button = event.target.closest('[data-lot-buy], [data-lot-cancel], [data-lot-history]');
  if (!button) return;

  const lotId = button.dataset.lotBuy || button.dataset.lotCancel || button.dataset.lotHistory;
  const lot = marketItems.find((item) => String(item.id) === lotId);
  if (!lot) return;

  if (button.dataset.lotBuy) buyLot(lot, button);
  else if (button.dataset.lotCancel) cancelLot(lot);
  else openPriceHistory(lot.productId, lot.title);
});

// ==================== ПОИСК, СОРТИРОВКА, ФИЛЬТРЫ ====================

document.getElementById('marketSearch').addEventListener('input', debounce((event) => {
  marketSearch = event.target.value;
  marketPage = 1;
  loadMarket();
}, 300));

document.getElementById('marketSort').addEventListener('change', (event) => {
  marketSort = event.target.value;
  marketPage = 1;
  loadMarket();
});

document.getElementById('marketRarity').addEventListener('change', (event) => {
  marketRarity = event.target.value;
  marketPage = 1;
  loadMarket();
});

document.getElementById('marketMine').addEventListener('change', (event) => {
  marketMine = event.target.checked;
  marketPage = 1;
  loadMarket();
});

document.getElementById('marketPagination').addEventListener('click', (event) => {
  const button = event.target.closest('[data-market-page]');
  if (!button) return;

  marketPage = Number(button.dataset.marketPage);
  loadMarket();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Переход на площадку с включённым фильтром "мои лоты" (кнопка в инвентаре)
function openMyLots() {
  marketMine = true;
  marketPage = 1;
  document.getElementById('marketMine').checked = true;

  if (location.hash === '#market') {
    loadMarket();
  } else {
    location.hash = '#market'; // экран сам загрузит лоты при открытии
  }
}

// ==================== ВЫСТАВЛЕНИЕ ПРЕДМЕТА НА ПРОДАЖУ ====================

// Пересчёт подсказки под полем цены: комиссия и сумма, которую получит продавец
function updateListingSummary() {
  const summary = document.getElementById('listingSummary');
  const price = Number(document.getElementById('listingPrice').value);

  if (!Number.isInteger(price) || price < 1) {
    summary.textContent = 'Введите цену, чтобы увидеть расчёт';
    return;
  }

  const fee = Math.floor(price * marketFeePercent / 100);
  summary.textContent = `Комиссия: ${formatPrice(fee)} ₽. Вы получите: ${formatPrice(price - fee)} ₽`;
}

// Открытие окна выставления. purchase — запись из инвентаря
function openListingModal(purchase) {
  listingPurchase = purchase;

  document.getElementById('listingForm').reset();
  document.getElementById('listingItemTitle').textContent = purchase.productTitle;
  document.getElementById('listingShopOffer').textContent =
    `Магазин выкупит этот предмет за ${formatPrice(Math.floor(purchase.price * SELL_RATE))} ₽`;
  document.getElementById('listingFeePercent').textContent = marketFeePercent;
  updateListingSummary();

  openModal('listingModal');
  document.getElementById('listingPrice').focus();
}

document.getElementById('listingPrice').addEventListener('input', updateListingSummary);

document.getElementById('listingForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!listingPurchase) return;

  const price = Number(document.getElementById('listingPrice').value);
  if (!Number.isInteger(price) || price < 1) {
    return showToast('Цена должна быть целым положительным числом', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/market', {
      method: 'POST',
      body: { purchaseId: listingPurchase._id, price }
    });

    closeModal('listingModal');
    showToast(`${data.message}. После продажи вы получите ${formatPrice(data.sellerGets)} ₽`, 'success', 5000);
    loadPurchases(); // предмет в инвентаре получит отметку "на площадке"
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== ИСТОРИЯ ЦЕН ====================

async function openPriceHistory(productId, title) {
  document.getElementById('historyItemTitle').textContent = title;
  document.getElementById('historyStats').innerHTML = '<p class="col-span-full text-sm text-gray-500">Загрузка…</p>';
  document.getElementById('historyEmpty').classList.add('hidden');
  document.getElementById('historyChartWrap').classList.add('hidden');
  openModal('priceHistoryModal');

  let data;
  try {
    data = await apiRequest(`/market/history/${productId}`);
  } catch (err) {
    document.getElementById('historyStats').innerHTML =
      '<p class="col-span-full text-sm text-red-400">Не удалось загрузить историю цен</p>';
    return;
  }

  // Четыре показателя: число сделок, минимум, средняя, максимум
  const stat = (label, value) => `
    <div class="bg-gray-800 rounded-xl p-3">
      <p class="text-xs text-gray-400">${label}</p>
      <p class="font-bold">${value}</p>
    </div>`;
  const money = (value) => (value === null ? '—' : `${formatPrice(value)} ₽`);

  document.getElementById('historyStats').innerHTML =
    stat('Сделок', data.count) +
    stat('Минимальная цена', money(data.min)) +
    stat('Средняя цена', money(data.average)) +
    stat('Максимальная цена', money(data.max));

  document.getElementById('historyShopPrice').textContent =
    data.shopPrice === null ? 'Товар больше не продаётся в магазине' : `Цена в магазине: ${formatPrice(data.shopPrice)} ₽`;

  if (data.count === 0) {
    document.getElementById('historyEmpty').classList.remove('hidden');
    return;
  }

  if (typeof Chart === 'undefined') return; // библиотека графиков не загрузилась — остаются только цифры

  document.getElementById('historyChartWrap').classList.remove('hidden');
  if (priceChart) priceChart.destroy();

  priceChart = new Chart(document.getElementById('priceHistoryChart'), {
    type: 'line',
    data: {
      // Подписи по оси X — дата сделки в формате ДД.ММ
      labels: data.deals.map((deal) => new Date(deal.soldAt).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })),
      datasets: [{
        data: data.deals.map((deal) => deal.price),
        borderColor: 'rgb(234, 179, 8)',
        backgroundColor: 'rgba(234, 179, 8, 0.15)',
        borderWidth: 2,
        tension: 0.25,
        pointRadius: 3,
        pointBackgroundColor: 'rgb(234, 179, 8)',
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#111827',
          borderColor: '#374151',
          borderWidth: 1,
          callbacks: {
            title: (items) => formatDate(data.deals[items[0].dataIndex].soldAt),
            label: (item) => `${formatPrice(item.parsed.y)} ₽`
          }
        }
      },
      scales: {
        x: { ticks: { color: '#9ca3af', maxTicksLimit: 8 }, grid: { color: 'rgba(55, 65, 81, 0.4)' } },
        y: {
          ticks: { color: '#9ca3af', precision: 0, callback: (value) => formatPrice(value) },
          grid: { color: 'rgba(55, 65, 81, 0.4)' }
        }
      }
    }
  });
}
