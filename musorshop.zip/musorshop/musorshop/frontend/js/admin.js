// admin.js
// Администратор: товары, загрузка картинок, статистика, график, CSV, промокоды, пользователи

// ==================== АДМИН: УПРАВЛЕНИЕ ТОВАРАМИ ====================

// Карточка-плюсик "Добавить товар"
function createAddCard() {
  return `
    <button type="button" data-action="add"
            class="min-h-[20rem] flex flex-col items-center justify-center gap-3 rounded-xl
                   border-2 border-dashed border-gray-700 text-gray-500
                   hover:border-yellow-500 hover:text-yellow-500 transition">
      <i class="fa-solid fa-plus text-4xl"></i>
      <span class="font-semibold">Добавить товар</span>
    </button>`;
}

// Открытие окна товара.
// Без аргумента — режим добавления, с товаром — режим редактирования
function openProductModal(product = null) {
  document.getElementById('productForm').reset();

  document.getElementById('productModalTitle').textContent =
    product ? 'Редактировать товар' : 'Добавить товар';
  document.getElementById('productSubmitBtn').textContent =
    product ? 'Сохранить изменения' : 'Добавить';

  // Скрытое поле: пусто = добавление, id = редактирование
  document.getElementById('productId').value = product ? product._id : '';

  if (product) {
    document.getElementById('productTitle').value = product.title;
    document.getElementById('productDescription').value = product.description || '';
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productQuantity').value = product.quantity;
    document.getElementById('productImageUrl').value = product.imageUrl || '';
    document.getElementById('productRarity').value = getRarity(product).key;
    document.getElementById('productCategory').value = product.category || 'other';
    document.getElementById('productWear').value = product.wear || '';
    document.getElementById('productStatTrak').checked = Boolean(product.statTrak);
  }

  updateImagePreview(); // показываем картинку редактируемого товара
  openModal('productModal');
}

// Сохранение товара (и добавление, и редактирование)
document.getElementById('productForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const productId = document.getElementById('productId').value;
  const title = document.getElementById('productTitle').value.trim();
  const description = document.getElementById('productDescription').value.trim();
  const priceRaw = document.getElementById('productPrice').value.trim();
  const quantityRaw = document.getElementById('productQuantity').value.trim();
  const imageUrl = document.getElementById('productImageUrl').value.trim();

  const price = Number(priceRaw);
  const quantity = Number(quantityRaw);

  // Проверки на стороне браузера (сервер проверит ещё раз)
  if (!title) {
    return showToast('Введите название товара', 'warning');
  }
  if (priceRaw === '' || !Number.isFinite(price) || price < 0) {
    return showToast('Цена должна быть неотрицательным числом', 'warning');
  }
  if (quantityRaw === '' || !Number.isInteger(quantity) || quantity < 0) {
    return showToast('Количество должно быть целым неотрицательным числом', 'warning');
  }
  if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
    return showToast('Ссылка на картинку должна начинаться с http:// или https://', 'warning');
  }

  setFormBusy(form, true);
  try {
    await apiRequest(productId ? `/products/${productId}` : '/products', {
      method: productId ? 'PUT' : 'POST',
      body: {
        title, description, price, quantity, imageUrl,
        rarity: document.getElementById('productRarity').value,
        category: document.getElementById('productCategory').value,
        wear: document.getElementById('productWear').value,
        statTrak: document.getElementById('productStatTrak').checked
      }
    });

    closeModal('productModal');
    await loadProducts();
    showToast(productId ? 'Товар обновлён' : 'Товар добавлен', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Удаление товара
async function handleDeleteProduct(productId) {
  const product = products.find((item) => item._id === productId);
  if (!product) return;

  const confirmedDelete = await confirmDialog({
    title: 'Удаление товара',
    message: `Удалить товар «${product.title}»? Это действие нельзя отменить.`,
    confirmText: 'Удалить',
    danger: true
  });
  if (!confirmedDelete) return;

  try {
    await apiRequest(`/products/${productId}`, { method: 'DELETE' });

    // Перезагружаем страницу каталога: на место удалённого товара подтянется следующий
    await loadProducts();
    showToast('Товар удалён', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Подключаем действия к кнопкам на карточках
cardActions.add = () => openProductModal();
cardActions.edit = (productId) => {
  const product = products.find((item) => item._id === productId);
  if (product) openProductModal(product);
};
cardActions.delete = handleDeleteProduct;

// ==================== АДМИН: СТАТИСТИКА ====================

// Отрисовка списка в блоке статистики.
// items — массив данных, renderRow — функция, которая превращает элемент в HTML строки
function renderStatsList(containerId, items, renderRow) {
  const container = document.getElementById(containerId);
  container.innerHTML = items.length > 0
    ? items.map(renderRow).join('')
    : '<p class="text-gray-500">Нет данных</p>';
}

// Загрузка статистики для панели администратора
async function loadStats() {
  let stats;
  try {
    stats = await apiRequest('/products/admin/stats');
  } catch (err) {
    showToast(err.message, 'error');
    return;
  }

  // 4 карточки метрик
  document.getElementById('statRevenue').textContent = formatPrice(stats.totalRevenue);
  document.getElementById('statSales').textContent = formatPrice(stats.totalSales);
  document.getElementById('statUsers').textContent = formatPrice(stats.totalUsers);
  document.getElementById('statProducts').textContent = formatPrice(stats.totalProducts);

  // Топ-5 покупателей
  renderStatsList('topBuyersList', stats.topBuyers, (buyer, index) => `
    <div class="flex items-center justify-between gap-2">
      <span class="truncate"><span class="text-gray-500">${index + 1}.</span> ${escapeHtml(buyer.email)}</span>
      <span class="shrink-0 text-right">
        <span class="font-semibold text-yellow-500">${formatPrice(buyer.totalSpent)} ₽</span>
        <span class="text-xs text-gray-500">(${buyer.purchasesCount})</span>
      </span>
    </div>`);

  // Топ-5 товаров
  renderStatsList('topProductsList', stats.topProducts, (product, index) => `
    <div class="flex items-center justify-between gap-2">
      <span class="truncate"><span class="text-gray-500">${index + 1}.</span> ${escapeHtml(product.title)}</span>
      <span class="shrink-0 font-semibold">${product.salesCount} шт.</span>
    </div>`);

  // Заканчивающиеся товары
  renderStatsList('lowStockList', stats.lowStock, (product) => `
    <div class="flex items-center justify-between gap-2">
      <span class="truncate">${escapeHtml(product.title)}</span>
      <span class="shrink-0 font-semibold ${product.quantity === 0 ? 'text-red-400' : 'text-yellow-500'}">
        ${product.quantity} шт.
      </span>
    </div>`);
}

// ==================== АДМИН: ГРАФИК ПРОДАЖ ====================

let salesChart = null;        // текущий экземпляр графика
let chartData = [];           // данные за 30 дней: [{ date, revenue, count }]
let chartMode = 'revenue';    // что показываем: 'revenue' (выручка) или 'count' (кол-во)

// Настройки двух режимов графика
const CHART_MODES = {
  revenue: { label: 'Оборот', color: '234, 179, 8', unit: ' ₽' },          // жёлтый
  profit:  { label: 'Чистая прибыль', color: '34, 197, 94', unit: ' ₽' },  // зелёный
  count:   { label: 'Покупок', color: '59, 130, 246', unit: ' шт.' }       // синий
};

// Подсветка активной кнопки переключателя
function updateChartButtons() {
  document.querySelectorAll('[data-chart-mode]').forEach((button) => {
    const active = button.dataset.chartMode === chartMode;
    button.classList.toggle('bg-yellow-500', active);
    button.classList.toggle('text-black', active);
    button.classList.toggle('bg-gray-700', !active);
    button.classList.toggle('text-gray-200', !active);
  });
}

// Отрисовка графика по уже загруженным данным
function renderSalesChart() {
  if (typeof Chart === 'undefined') {
    return showToast('Библиотека Chart.js не загрузилась. Проверьте интернет', 'warning');
  }

  const mode = CHART_MODES[chartMode];
  const canvas = document.getElementById('salesChart');

  // Подписи по оси X: "2026-10-02" -> "02.10"
  const labels = chartData.map((day) => {
    const [, month, date] = day.date.split('-');
    return `${date}.${month}`;
  });
  const values = chartData.map((day) => day[chartMode]);

  // Перед созданием нового графика удаляем старый, иначе они наложатся
  if (salesChart) {
    salesChart.destroy();
  }

  salesChart = new Chart(canvas, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: mode.label,
        data: values,
        borderColor: `rgb(${mode.color})`,
        borderWidth: 2,
        tension: 0.35,          // сглаживание линии
        pointRadius: 2,
        pointHoverRadius: 5,
        pointBackgroundColor: `rgb(${mode.color})`,
        fill: true,
        // Градиент под линией: сверху цвет плотнее, снизу прозрачный
        backgroundColor: (context) => {
          const { ctx, chartArea } = context.chart;
          if (!chartArea) return `rgba(${mode.color}, 0.15)`; // график ещё не размечен
          const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
          gradient.addColorStop(0, `rgba(${mode.color}, 0.45)`);
          gradient.addColorStop(1, `rgba(${mode.color}, 0)`);
          return gradient;
        }
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false, // высоту задаёт контейнер (h-72)
      interaction: { mode: 'index', intersect: false }, // тултип по наведению на столбец дня
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#111827',
          borderColor: '#374151',
          borderWidth: 1,
          padding: 10,
          callbacks: {
            // Заголовок тултипа — полная дата
            title: (items) => {
              const [year, month, date] = chartData[items[0].dataIndex].date.split('-');
              return `${date}.${month}.${year}`;
            },
            // Текст тултипа — значение с единицей измерения
            label: (item) => i18n.tr(`${mode.label}: ${formatPrice(item.parsed.y)}${mode.unit}`)
          }
        }
      },
      scales: {
        x: {
          ticks: { color: '#9ca3af', maxTicksLimit: 10 },
          grid: { color: 'rgba(55, 65, 81, 0.4)' }
        },
        y: {
          beginAtZero: true,
          ticks: {
            color: '#9ca3af',
            precision: 0, // только целые деления
            callback: (value) => formatPrice(value)
          },
          grid: { color: 'rgba(55, 65, 81, 0.4)' }
        }
      }
    }
  });
}

// Загрузка данных графика с сервера и отрисовка
async function loadSalesChart() {
  try {
    chartData = await apiRequest('/products/admin/chart-data');
    updateChartButtons();
    renderSalesChart();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Переключатель режимов графика: оборот / чистая прибыль / количество
document.querySelectorAll('[data-chart-mode]').forEach((button) => {
  button.addEventListener('click', () => {
    chartMode = button.dataset.chartMode;
    updateChartButtons();
    renderSalesChart();
  });
});

// ==================== АДМИН: ЭКСПОРТ В CSV ====================

// Подготовка одного значения для CSV-ячейки
function escapeCsvValue(value) {
  let text = String(value ?? '');

  // Защита от формул: если текст начинается с = + - @, Excel может выполнить его
  // как формулу. Апостроф в начале заставляет Excel считать ячейку обычным текстом
  if (typeof value === 'string' && /^[=+\-@]/.test(text)) {
    text = "'" + text;
  }

  // Если в значении есть разделитель, кавычки или перенос строки —
  // оборачиваем в кавычки, а кавычки внутри удваиваем
  if (/[;"\n\r]/.test(text)) {
    text = '"' + text.replace(/"/g, '""') + '"';
  }

  return text;
}

// Выгрузка всех покупок в CSV-файл
async function exportPurchasesCsv() {
  const button = document.getElementById('exportCsvBtn');
  button.disabled = true;

  try {
    const purchases = await apiRequest('/products/admin/purchases');

    if (purchases.length === 0) {
      return showToast('Покупок пока нет — выгружать нечего', 'info');
    }

    // Первая строка — заголовки столбцов
    const rows = [
      ['№', 'Покупатель', 'Товар', 'Цена, ₽', 'Статус', 'Дата покупки', 'Дата продажи'].map(i18n.tr)
    ];

    purchases.forEach((purchase, index) => {
      rows.push([
        index + 1,
        purchase.userEmail,
        purchase.productTitle,
        purchase.price,
        i18n.tr({
          sold: 'Продано',
          listed: 'На площадке',
          traded: 'Продано на площадке',
          contracted: 'Обменян по контракту'
        }[purchase.status] || 'Активно'),
        formatDate(purchase.purchasedAt),
        purchase.soldAt ? formatDate(purchase.soldAt) : ''
      ]);
    });

    // Собираем текст файла: ячейки через ";", строки через перенос.
    // \uFEFF в начале — метка BOM, по ней Excel понимает, что файл в UTF-8,
    // и правильно показывает русские буквы
    const csv = '\uFEFF' + rows
      .map((row) => row.map(escapeCsvValue).join(';'))
      .join('\r\n');

    // Имя файла с сегодняшней датой: musorshop-purchases-2026-10-02.csv
    const now = new Date();
    const dateStamp = [
      now.getFullYear(),
      String(now.getMonth() + 1).padStart(2, '0'),
      String(now.getDate()).padStart(2, '0')
    ].join('-');
    const fileName = `musorshop-purchases-${dateStamp}.csv`;

    // Создаём файл в памяти браузера и "нажимаем" на временную ссылку для скачивания
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url); // освобождаем память

    showToast(`Файл ${fileName} сохранён (строк: ${purchases.length})`, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    button.disabled = false;
  }
}

document.getElementById('exportCsvBtn').addEventListener('click', exportPurchasesCsv);

// ==================== АДМИН: ПРОМОКОДЫ ====================

let promoCodes = [];        // загруженные промокоды
let editingPromoId = null;  // id редактируемого промокода (null = создаём новый)

const MAX_PROMO_BONUS = 1000000; // максимум фиксированного бонуса, ₽
const MAX_PROMO_PERCENT = 100;   // максимум процентного бонуса, %

// Кнопка "Отмена" для режима редактирования — создаём один раз и добавляем в форму
const promoCancelBtn = document.createElement('button');
promoCancelBtn.type = 'button';
promoCancelBtn.textContent = 'Отмена';
promoCancelBtn.className =
  'hidden sm:col-span-5 py-2 rounded-lg bg-gray-900 border border-gray-700 text-sm font-medium hover:bg-gray-700 transition';
document.getElementById('promoCreateForm').appendChild(promoCancelBtn);

// Подсказка в поле бонуса зависит от выбранного типа
function updatePromoAmountField() {
  const isPercent = document.getElementById('promoNewType').value === 'percent';
  const input = document.getElementById('promoNewAmount');
  input.placeholder = isPercent ? 'Процент, %' : 'Бонус, ₽';
  input.max = isPercent ? MAX_PROMO_PERCENT : MAX_PROMO_BONUS;
}

document.getElementById('promoNewType').addEventListener('change', updatePromoAmountField);

// Возврат формы в режим создания
function resetPromoForm() {
  const form = document.getElementById('promoCreateForm');
  editingPromoId = null;
  form.reset();
  form.querySelector('button[type="submit"]').textContent = 'Создать';
  promoCancelBtn.classList.add('hidden');
  updatePromoAmountField();
}

// Переход в режим редактирования: подставляем данные промокода в форму
function startEditPromo(promoId) {
  const promo = promoCodes.find((item) => String(item.id) === promoId);
  if (!promo) return;

  const form = document.getElementById('promoCreateForm');
  editingPromoId = promoId;
  document.getElementById('promoNewCode').value = promo.code;
  document.getElementById('promoNewType').value = promo.type;
  document.getElementById('promoNewAmount').value = promo.amount;
  document.getElementById('promoNewMaxUses').value = promo.maxUses;
  form.querySelector('button[type="submit"]').textContent = 'Сохранить';
  promoCancelBtn.classList.remove('hidden');
  updatePromoAmountField();

  form.scrollIntoView({ behavior: 'smooth', block: 'center' });
  document.getElementById('promoNewCode').focus();
}

// Загрузка и отрисовка списка промокодов в окне статистики
async function loadPromoCodes() {
  const list = document.getElementById('promoList');

  try {
    promoCodes = await apiRequest('/promo');
  } catch (err) {
    list.innerHTML = '<p class="text-red-400">Не удалось загрузить промокоды</p>';
    return;
  }

  if (promoCodes.length === 0) {
    list.innerHTML = '<p class="text-gray-500">Промокодов пока нет</p>';
    return;
  }

  list.innerHTML = promoCodes.map((promo) => {
    const id = escapeHtml(promo.id);
    const exhausted = promo.usedCount >= promo.maxUses;

    // Подпись бонуса: "+5 000 ₽" или "+10% к пополнению"
    const bonusLabel = promo.type === 'percent'
      ? `+${promo.amount}% к пополнению`
      : `+${formatPrice(promo.amount)} ₽`;

    return `
      <div class="flex items-center justify-between gap-3 bg-gray-900 rounded-lg px-3 py-2">
        <span class="font-mono font-semibold truncate ${exhausted ? 'text-gray-500 line-through' : 'text-yellow-500'}">
          ${escapeHtml(promo.code)}
        </span>
        <span class="shrink-0 flex items-center gap-3">
          <span>${bonusLabel}</span>
          <span class="text-gray-400">${promo.usedCount} / ${promo.maxUses}</span>
          <span class="flex gap-1">
            <button type="button" data-promo-edit="${id}" title="Изменить" aria-label="Изменить промокод"
                    class="w-7 h-7 rounded bg-gray-800 text-xs text-blue-400 hover:bg-gray-700">✎</button>
            <button type="button" data-promo-delete="${id}" title="Удалить" aria-label="Удалить промокод"
                    class="w-7 h-7 rounded bg-gray-800 text-xs text-red-400 hover:bg-gray-700">✕</button>
          </span>
        </span>
      </div>`;
  }).join('');
}

// Создание нового промокода или сохранение изменений
document.getElementById('promoCreateForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const code = document.getElementById('promoNewCode').value.trim().toUpperCase();
  const type = document.getElementById('promoNewType').value;
  const amount = Number(document.getElementById('promoNewAmount').value);
  const maxUses = Number(document.getElementById('promoNewMaxUses').value);

  if (!/^[A-Z0-9_-]{3,20}$/.test(code)) {
    return showToast('Код: от 3 до 20 символов, латинские буквы, цифры, дефис и подчёркивание', 'warning');
  }

  // Допустимый размер бонуса зависит от типа
  const maxAmount = type === 'percent' ? MAX_PROMO_PERCENT : MAX_PROMO_BONUS;
  if (!Number.isInteger(amount) || amount < 1 || amount > maxAmount) {
    return showToast(
      type === 'percent'
        ? `Процент должен быть целым числом от 1 до ${MAX_PROMO_PERCENT}`
        : `Бонус должен быть целым числом от 1 до ${formatPrice(MAX_PROMO_BONUS)}`,
      'warning'
    );
  }
  if (!Number.isInteger(maxUses) || maxUses < 1) {
    return showToast('Лимит активаций должен быть целым числом от 1', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(editingPromoId ? `/promo/${editingPromoId}` : '/promo', {
      method: editingPromoId ? 'PUT' : 'POST',
      body: { code, type, amount, maxUses }
    });

    resetPromoForm();
    showToast(data.message, 'success');
    loadPromoCodes();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// Отмена редактирования
promoCancelBtn.addEventListener('click', resetPromoForm);

// Кнопки ✎ и ✕ в списке промокодов (делегирование)
document.getElementById('promoList').addEventListener('click', async (event) => {
  const editButton = event.target.closest('[data-promo-edit]');
  if (editButton) {
    return startEditPromo(editButton.dataset.promoEdit);
  }

  const deleteButton = event.target.closest('[data-promo-delete]');
  if (!deleteButton) return;

  const confirmedDelete = await confirmDialog({
    title: 'Удаление промокода',
    message: 'Удалить этот промокод? Уже начисленные бонусы останутся у пользователей.',
    confirmText: 'Удалить',
    danger: true
  });
  if (!confirmedDelete) return;

  try {
    const data = await apiRequest(`/promo/${deleteButton.dataset.promoDelete}`, { method: 'DELETE' });

    // Если удалили промокод, который сейчас редактируется, — сбрасываем форму
    if (editingPromoId === deleteButton.dataset.promoDelete) resetPromoForm();

    showToast(data.message, 'success');
    loadPromoCodes();
  } catch (err) {
    showToast(err.message, 'error');
  }
});

// ==================== ПАНЕЛЬ АДМИНИСТРАТОРА В КАБИНЕТЕ ====================

let adminTab = 'stats'; // открытая вкладка панели

// Показ выбранной вкладки и подсветка её кнопки
function renderAdminTabs() {
  document.querySelectorAll('#adminTabs [data-admin-tab]').forEach((button) => {
    const active = button.dataset.adminTab === adminTab;
    button.classList.toggle('bg-yellow-500', active);
    button.classList.toggle('text-black', active);
    button.classList.toggle('bg-gray-800', !active);
    button.classList.toggle('text-gray-300', !active);
  });

  // Содержимое вкладок — блоки с id вида adminTab-<имя>
  document.querySelectorAll('[id^="adminTab-"]').forEach((panel) => {
    panel.classList.toggle('hidden', panel.id !== `adminTab-${adminTab}`);
  });

  // График мог быть создан, пока вкладка была скрыта, — подгоняем его под размер
  if (adminTab === 'stats' && salesChart) {
    salesChart.resize();
  }
}

document.getElementById('adminTabs').addEventListener('click', (event) => {
  const button = event.target.closest('[data-admin-tab]');
  if (!button) return;

  adminTab = button.dataset.adminTab;
  renderAdminTabs();
});

// Загрузка всех данных панели. Вызывается при открытии кабинета админом
function loadAdminPanel() {
  renderAdminTabs();
  loadStats();
  loadSalesChart();
  resetPromoForm();
  loadPromoCodes();
  loadAdminLog(true);
  loadAdminUsers(true);
  loadAdminActions(true);
}

// ==================== АДМИН: УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ ====================

let adminUsers = [];        // загруженные пользователи
let usersPage = 1;          // текущая "порция" списка
let balanceUserId = null;   // кому сейчас корректируем баланс

// HTML одной строки пользователя
function createUserRow(user) {
  const id = escapeHtml(user.id);
  const isAdminUser = user.role === 'admin';

  // Плашки статуса
  let badges = '';
  if (isAdminUser) {
    badges += '<span class="px-2 py-0.5 rounded bg-blue-600 text-xs font-semibold">админ</span>';
  }
  if (user.isBlocked) {
    badges += '<span class="px-2 py-0.5 rounded bg-red-600 text-xs font-semibold">заблокирован</span>';
  }

  // Кнопка блокировки — только для обычных пользователей
  const blockButton = isAdminUser
    ? ''
    : `<button type="button" data-user-block="${id}"
               class="px-3 py-1.5 rounded-lg text-xs font-semibold transition
                      ${user.isBlocked ? 'bg-green-600 hover:bg-green-500' : 'bg-red-600 hover:bg-red-500'}">
         ${user.isBlocked ? 'Разблокировать' : 'Заблокировать'}
       </button>`;

  return `
    <div class="flex flex-wrap items-center gap-3 bg-gray-900 rounded-lg p-3">
      <div class="flex-1 min-w-0">
        <p class="flex flex-wrap items-center gap-2 text-sm font-medium">
          <span class="break-all">${escapeHtml(user.email)}</span>
          ${badges}
        </p>
        <p class="text-xs text-gray-400">
          Баланс: ${formatPrice(user.balance)} ₽ · Покупок: ${user.purchasesCount} · Регистрация: ${formatDate(user.registeredAt)}
        </p>
      </div>
      <div class="shrink-0 flex gap-2">
        <button type="button" data-user-balance="${id}"
                class="px-3 py-1.5 rounded-lg bg-gray-800 border border-gray-700 text-xs font-semibold hover:bg-gray-700 transition">
          Баланс
        </button>
        ${blockButton}
      </div>
    </div>`;
}

// Загрузка списка пользователей. reset = true — с первой страницы
async function loadAdminUsers(reset = false) {
  if (!currentUser || currentUser.role !== 'admin') return;

  const list = document.getElementById('usersList');
  const moreBtn = document.getElementById('usersMoreBtn');

  if (reset) usersPage = 1;

  const search = document.getElementById('usersSearch').value.trim();
  const query = `page=${usersPage}${search ? `&search=${encodeURIComponent(search)}` : ''}`;

  let data;
  try {
    data = await apiRequest(`/users?${query}`);
  } catch (err) {
    if (reset) {
      list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить пользователей</p>';
    }
    return;
  }

  adminUsers = reset ? data.items : adminUsers.concat(data.items);

  document.getElementById('usersTotal').textContent = data.total;
  list.innerHTML = adminUsers.length > 0
    ? adminUsers.map(createUserRow).join('')
    : '<p class="text-sm text-gray-500">Никого не найдено</p>';
  moreBtn.classList.toggle('hidden', !data.hasMore);
}

document.getElementById('usersMoreBtn').addEventListener('click', () => {
  usersPage += 1;
  loadAdminUsers(false);
});

// Поиск по email с задержкой 300 мс
document.getElementById('usersSearch').addEventListener('input', debounce(() => loadAdminUsers(true), 300));

// Кнопки в строках пользователей (делегирование)
document.getElementById('usersList').addEventListener('click', async (event) => {
  // ---------- Корректировка баланса ----------
  const balanceButton = event.target.closest('[data-user-balance]');
  if (balanceButton) {
    const user = adminUsers.find((item) => String(item.id) === balanceButton.dataset.userBalance);
    if (!user) return;

    balanceUserId = String(user.id);
    document.getElementById('balanceForm').reset();
    document.getElementById('balanceUserInfo').textContent =
      `${user.email} · текущий баланс: ${formatPrice(user.balance)} ₽`;
    openModal('balanceModal');
    return;
  }

  // ---------- Блокировка и разблокировка ----------
  const blockButton = event.target.closest('[data-user-block]');
  if (!blockButton) return;

  const user = adminUsers.find((item) => String(item.id) === blockButton.dataset.userBlock);
  if (!user) return;

  const willBlock = !user.isBlocked;

  const confirmed = await confirmDialog({
    title: willBlock ? 'Блокировка пользователя' : 'Разблокировка пользователя',
    message: willBlock
      ? `Заблокировать ${user.email}? Он сразу потеряет доступ к аккаунту и не сможет войти.`
      : `Разблокировать ${user.email}? Он снова сможет войти в аккаунт.`,
    confirmText: willBlock ? 'Заблокировать' : 'Разблокировать',
    danger: willBlock
  });
  if (!confirmed) return;

  try {
    const data = await apiRequest(`/users/${user.id}/block`, {
      method: 'PUT',
      body: { blocked: willBlock }
    });
    showToast(data.message, 'success');
    loadAdminUsers(true);
  } catch (err) {
    showToast(err.message, 'error');
  }
});

// Отправка формы корректировки баланса
document.getElementById('balanceForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const amountRaw = document.getElementById('balanceAmount').value.trim();
  const amount = Number(amountRaw);
  const reason = document.getElementById('balanceReason').value.trim();

  if (amountRaw === '' || !Number.isInteger(amount) || amount === 0) {
    return showToast('Сумма должна быть целым числом, не равным нулю', 'warning');
  }
  if (!reason) {
    return showToast('Укажите причину корректировки', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest(`/users/${balanceUserId}/balance`, {
      method: 'POST',
      body: { amount, reason }
    });

    // Если админ изменил собственный баланс — обновляем его в шапке и кабинете
    if (String(currentUser.id) === balanceUserId) {
      currentUser.balance = data.balance;
      updateUI();
      fillProfile();
      loadHistory(true);
    }

    closeModal('balanceModal');
    showToast(`${data.message}. Новый баланс: ${formatPrice(data.balance)} ₽`, 'success');
    loadAdminUsers(true);
    loadAdminLog(true);
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== ЗАГРУЗКА КАРТИНКИ ТОВАРА ====================

const MAX_IMAGE_SIZE = 2 * 1024 * 1024; // 2 МБ
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

// Предпросмотр: показывает картинку по адресу из поля ссылки
function updateImagePreview() {
  const preview = document.getElementById('productImagePreview');
  const url = document.getElementById('productImageUrl').value.trim();

  if (/^https?:\/\//i.test(url)) {
    preview.src = url;
    preview.classList.remove('hidden');
  } else {
    preview.removeAttribute('src');
    preview.classList.add('hidden');
  }
}

// Если картинка по ссылке не загрузилась — прячем предпросмотр
document.getElementById('productImagePreview').addEventListener('error', (event) => {
  event.currentTarget.classList.add('hidden');
});

// Ссылку изменили вручную — обновляем предпросмотр
document.getElementById('productImageUrl').addEventListener('input', debounce(updateImagePreview, 400));

// Форму очистили — прячем предпросмотр.
// setTimeout нужен, потому что событие reset срабатывает ДО очистки полей
document.getElementById('productForm').addEventListener('reset', () => {
  setTimeout(updateImagePreview, 0);
});

// Отправка файла на сервер. Возвращает адрес загруженной картинки.
// apiRequest здесь не подходит: файл передаётся не как JSON, а как FormData
async function uploadImage(file) {
  const formData = new FormData();
  formData.append('image', file);

  let response;
  try {
    response = await fetch(`${API_URL}/upload/image`, {
      method: 'POST',
      // Заголовок Content-Type не указываем: браузер сам выставит его для FormData
      headers: { 'X-Requested-With': 'fetch' },
      credentials: 'same-origin',
      body: formData
    });
  } catch (err) {
    throw new Error('Сервер недоступен. Проверьте, что бэкенд запущен');
  }

  let data = null;
  try {
    data = await response.json();
  } catch (err) {
    // ответ без JSON
  }

  if (!response.ok) {
    throw new Error((data && data.message) || 'Не удалось загрузить файл');
  }
  return data.url;
}

// Выбран файл — проверяем и сразу загружаем
document.getElementById('productImageFile').addEventListener('change', async (event) => {
  const input = event.currentTarget;
  const file = input.files[0];
  if (!file) return;

  // Проверки в браузере (сервер проверит ещё раз, по содержимому файла)
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    input.value = '';
    return showToast('Допустимы только изображения JPG, PNG, GIF и WebP', 'warning');
  }
  if (file.size > MAX_IMAGE_SIZE) {
    input.value = '';
    return showToast('Файл слишком большой. Максимум — 2 МБ', 'warning');
  }

  const form = document.getElementById('productForm');
  setFormBusy(form, true); // пока идёт загрузка, сохранить товар нельзя

  try {
    const url = await uploadImage(file);
    document.getElementById('productImageUrl').value = url;
    updateImagePreview();
    showToast('Картинка загружена. Не забудьте сохранить товар', 'success');
  } catch (err) {
    input.value = '';
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== АДМИН: ЖУРНАЛ ДЕЙСТВИЙ ====================

let adminActions = [];  // загруженные записи журнала
let actionsPage = 1;    // текущая "порция"

// Подпись для каждого кода действия
const ADMIN_ACTION_LABELS = {
  'product.create': 'Создан товар',
  'product.update': 'Изменён товар',
  'product.delete': 'Удалён товар',
  'promo.create':   'Создан промокод',
  'promo.update':   'Изменён промокод',
  'promo.delete':   'Удалён промокод',
  'case.create':    'Создан кейс',
  'case.update':    'Изменён кейс',
  'case.delete':    'Удалён кейс',
  'user.block':     'Заблокирован пользователь',
  'user.unblock':   'Разблокирован пользователь',
  'user.balance':   'Изменён баланс',
  'review.edit':    'Изменён отзыв',
  'review.delete':  'Удалён отзыв',
  'market.cancel':  'Снят лот'
};

// Значок раздела
const ADMIN_ACTION_ICONS = {
  product: 'fa-box',
  promo:   'fa-ticket',
  case:    'fa-box-open',
  user:    'fa-user-shield',
  review:  'fa-comment',
  market:  'fa-right-left'
};

// Удаления и блокировки выделяем красным, остальное — обычным цветом
function isDangerousAction(action) {
  return action.endsWith('.delete') || action === 'user.block' || action === 'market.cancel';
}

function createActionRow(item) {
  const label = ADMIN_ACTION_LABELS[item.action] || item.action;
  const icon = ADMIN_ACTION_ICONS[item.category] || 'fa-circle';

  return `
    <button type="button" data-action-id="${escapeHtml(item.id)}" title="Показать подробности"
            class="w-full text-left flex items-start gap-3 bg-gray-900 rounded-lg p-3 border border-transparent hover:border-yellow-500/60 transition">
      <div class="w-9 h-9 shrink-0 rounded-full bg-gray-800 flex items-center justify-center text-sm
                  ${isDangerousAction(item.action) ? 'text-red-400' : 'text-gray-300'}">
        <i class="fa-solid ${icon}"></i>
      </div>
      <div class="flex-1 min-w-0">
        <p class="text-sm font-medium">${escapeHtml(label)}</p>
        <p class="text-sm text-gray-300 break-words">${escapeHtml(item.target)}</p>
        <p class="mt-1 text-xs text-gray-500">${escapeHtml(item.admin)} · ${formatDate(item.createdAt)}</p>
      </div>
      <i class="fa-solid fa-chevron-right shrink-0 mt-2 text-xs text-gray-600"></i>
    </button>`;
}

// Загрузка журнала. reset = true — с первой страницы
async function loadAdminActions(reset = false) {
  if (!currentUser || currentUser.role !== 'admin') return;

  const list = document.getElementById('actionsList');
  const moreBtn = document.getElementById('actionsMoreBtn');

  if (reset) actionsPage = 1;

  const category = document.getElementById('actionsCategoryFilter').value;
  const query = `page=${actionsPage}${category ? `&category=${encodeURIComponent(category)}` : ''}`;

  let data;
  try {
    data = await apiRequest(`/audit?${query}`);
  } catch (err) {
    if (reset) {
      list.innerHTML = '<p class="text-sm text-red-400">Не удалось загрузить журнал действий</p>';
    }
    return;
  }

  adminActions = reset ? data.items : adminActions.concat(data.items);

  document.getElementById('actionsTotal').textContent = data.total;
  list.innerHTML = adminActions.length > 0
    ? adminActions.map(createActionRow).join('')
    : '<p class="text-sm text-gray-500">Действий пока нет</p>';
  moreBtn.classList.toggle('hidden', !data.hasMore);
}

document.getElementById('actionsMoreBtn').addEventListener('click', () => {
  actionsPage += 1;
  loadAdminActions(false);
});

document.getElementById('actionsCategoryFilter').addEventListener('change', () => loadAdminActions(true));

// При переходе на вкладку подгружаем свежие записи: за время работы в панели
// админ мог совершить новые действия
document.getElementById('adminTabs').addEventListener('click', (event) => {
  const button = event.target.closest('[data-admin-tab="actions"]');
  if (button) loadAdminActions(true);
});

// ==================== АДМИН: ПОДРОБНОСТИ ДЕЙСТВИЯ ====================

// Названия полей для показа в окне подробностей
const AUDIT_FIELD_LABELS = {
  title: 'Название',
  description: 'Описание',
  price: 'Цена',
  quantity: 'Количество',
  rarity: 'Редкость',
  category: 'Категория',
  wear: 'Качество',
  statTrak: 'StatTrak™',
  imageUrl: 'Картинка',
  code: 'Код',
  type: 'Тип',
  amount: 'Размер бонуса',
  maxUses: 'Лимит активаций',
  usedCount: 'Активаций',
  itemsCount: 'Предметов в кейсе',
  balance: 'Баланс',
  reason: 'Причина',
  rating: 'Оценка',
  comment: 'Комментарий',
  lotPrice: 'Цена лота',
  itemValue: 'Стоимость предмета'
};

// Значение поля в удобном для чтения виде
function formatAuditValue(field, value) {
  if (value === '' || value === null || value === undefined) return '—';
  if (typeof value === 'boolean') return value ? 'Да' : 'Нет';

  if (field === 'rarity' && RARITY_INFO[value]) return RARITY_INFO[value].label;
  if (field === 'category' && CATEGORY_INFO[value]) return CATEGORY_INFO[value];
  if (field === 'wear' && WEAR_INFO[value]) return WEAR_INFO[value];
  if (field === 'type') {
    return { fixed: 'Фиксированная сумма', percent: 'Процент к пополнению' }[value] || String(value);
  }
  if (['price', 'balance', 'lotPrice', 'itemValue'].includes(field)) {
    return `${formatPrice(value)} ₽`;
  }
  return String(value);
}

// Открытие окна с подробностями действия
function openActionDetails(actionId) {
  const item = adminActions.find((entry) => String(entry.id) === actionId);
  if (!item) return;

  const details = item.details || {};
  const changes = Array.isArray(details.changes) ? details.changes : null;
  const snapshot = details.snapshot && typeof details.snapshot === 'object' ? details.snapshot : null;

  document.getElementById('actionModalTitle').textContent = ADMIN_ACTION_LABELS[item.action] || item.action;
  document.getElementById('actionModalTarget').textContent = item.target;
  document.getElementById('actionModalMeta').textContent = `${item.admin} · ${formatDate(item.createdAt)}`;

  let html = '';

  // ---------- Изменения: таблица "поле — было — стало" ----------
  if (changes && changes.length > 0) {
    html += `
      <div>
        <h3 class="mb-2 font-semibold">Что изменилось</h3>
        <div class="overflow-x-auto rounded-lg border border-gray-800">
          <table class="w-full text-sm">
            <thead class="bg-gray-800 text-left text-xs text-gray-400">
              <tr>
                <th class="px-3 py-2 font-medium">Поле</th>
                <th class="px-3 py-2 font-medium">Было</th>
                <th class="px-3 py-2 font-medium">Стало</th>
              </tr>
            </thead>
            <tbody>
              ${changes.map((change) => `
                <tr class="border-t border-gray-800 align-top">
                  <td class="px-3 py-2 text-gray-400 whitespace-nowrap">${escapeHtml(AUDIT_FIELD_LABELS[change.field] || change.field)}</td>
                  <td class="px-3 py-2 text-red-400 break-words">${escapeHtml(formatAuditValue(change.field, change.before))}</td>
                  <td class="px-3 py-2 text-green-500 break-words">${escapeHtml(formatAuditValue(change.field, change.after))}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
  } else if (changes) {
    html += '<p class="text-sm text-gray-400">Форма была сохранена без изменений: значения полей остались прежними</p>';
  }

  // ---------- Снимок: данные объекта на момент действия ----------
  if (snapshot && Object.keys(snapshot).length > 0) {
    html += `
      <div>
        <h3 class="mb-2 font-semibold">Данные на момент действия</h3>
        <div class="rounded-lg border border-gray-800 divide-y divide-gray-800">
          ${Object.entries(snapshot).map(([field, value]) => `
            <div class="flex gap-3 px-3 py-2 text-sm">
              <span class="w-40 shrink-0 text-gray-400">${escapeHtml(AUDIT_FIELD_LABELS[field] || field)}</span>
              <span class="min-w-0 break-words">${escapeHtml(formatAuditValue(field, value))}</span>
            </div>`).join('')}
        </div>
      </div>`;
  }

  if (!html) {
    html = '<p class="text-sm text-gray-400">Для этого действия дополнительных сведений нет: всё указано в заголовке</p>';
  }

  document.getElementById('actionModalBody').innerHTML = html;
  openModal('actionModal');
}

// Клик по записи журнала (делегирование)
document.getElementById('actionsList').addEventListener('click', (event) => {
  const row = event.target.closest('[data-action-id]');
  if (row) openActionDetails(row.dataset.actionId);
});

