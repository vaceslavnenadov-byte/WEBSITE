// auth.js
// Авторизация: вход, регистрация, выход, смена пароля, показ и надёжность пароля

// ==================== АВТОРИЗАЦИЯ ====================

// Та же проверка email, что и на сервере: есть @ и точка после неё
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD_LENGTH = 5;

// Блокировка кнопки отправки на время запроса (защита от двойного клика)
function setFormBusy(form, busy) {
  const button = form.querySelector('button[type="submit"]');
  if (!button) return;
  button.disabled = busy;
  button.classList.toggle('opacity-60', busy);
  button.classList.toggle('cursor-not-allowed', busy);
}

// Загрузка id избранных товаров. Вызывается один раз после входа,
// до отрисовки карточек, чтобы сердечки сразу были нужного цвета
async function loadWishlistIds() {
  wishlistIds = new Set();
  if (!currentUser || currentUser.role !== 'user') return;

  try {
    const ids = await apiRequest('/products/wishlist-ids');
    wishlistIds = new Set(ids);
  } catch (err) {
    // не критично: сердечки просто останутся незакрашенными
  }
}

// Вызывается после любого изменения статуса входа:
// подгружает данные пользователя и перерисовывает страницу
async function applyAuthState() {
  await loadWishlistIds();
  updateUI();
  renderProducts();
  renderRoute(); // обновляет текущий экран (например, кнопки админа на экране кейсов)
  connectRealtime(); // переподключаемся: теперь сервер знает, кто мы
  refreshNotifications(); // загружаем уведомления вошедшего пользователя
}

// Проверена ли сессия при загрузке страницы (нужно экрану кабинета)
let sessionChecked = false;

// Восстановление сессии при загрузке страницы:
// если в localStorage есть токен — спрашиваем у сервера, кто мы
async function refreshUser() {
  // На этом устройстве не входили — запрашивать профиль незачем
  if (!hasSession()) {
    sessionChecked = true;
    return;
  }
  try {
    currentUser = await apiRequest('/auth/me');
    await applyAuthState();
  } catch (err) {
    // Если токен истёк, apiRequest уже сбросил сессию.
    // Если сервер недоступен — об этом сообщит loadProducts
  } finally {
    sessionChecked = true;
    renderRoute(); // теперь можно показать кабинет, если открыт адрес #profile
  }
}

// ---------- Открытие окон и переключение между ними ----------

document.getElementById('loginBtn').addEventListener('click', () => openModal('loginModal'));
document.getElementById('registerBtn').addEventListener('click', () => openModal('registerModal'));

document.getElementById('toRegisterLink').addEventListener('click', (event) => {
  event.preventDefault();
  closeModal('loginModal');
  openModal('registerModal');
});

document.getElementById('toLoginLink').addEventListener('click', (event) => {
  event.preventDefault();
  closeModal('registerModal');
  openModal('loginModal');
});

// ---------- Регистрация ----------

document.getElementById('registerForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const email = document.getElementById('registerEmail').value.trim();
  const password = document.getElementById('registerPassword').value;
  const confirmPassword = document.getElementById('registerPasswordConfirm').value;

  // Проверки на стороне браузера (сервер проверит ещё раз)
  if (!EMAIL_REGEX.test(email)) {
    return showToast('Введите корректный email (например, name@mail.ru)', 'warning');
  }
  if (password.length < MIN_PASSWORD_LENGTH) {
    return showToast(`Пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`, 'warning');
  }
  if (password !== confirmPassword) {
    return showToast('Пароли не совпадают', 'warning');
  }

  if (!getCaptcha('register').captchaAnswer) {
    return showToast('Введите код с картинки', 'warning');
  }

  setFormBusy(form, true);
  try {
    await apiRequest('/auth/register', {
      method: 'POST',
      body: { email, password, ...getCaptcha('register') }
    });

    showToast('Регистрация прошла успешно. Теперь войдите в аккаунт', 'success');
    form.reset();

    // Автоматически открываем окно входа с уже подставленным email
    closeModal('registerModal');
    openModal('loginModal');
    document.getElementById('loginEmail').value = email;
    document.getElementById('loginPassword').focus();
  } catch (err) {
    showToast(err.message, 'error');
    loadCaptcha('register'); // код одноразовый — после неудачи нужен новый
  } finally {
    setFormBusy(form, false);
  }
});

// ---------- Вход ----------

document.getElementById('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;

  if (!getCaptcha('login').captchaAnswer) {
    return showToast('Введите код с картинки', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/auth/login', {
      method: 'POST',
      body: { email, password, ...getCaptcha('login') }
    });

    // Токен сервер положил в httpOnly-cookie; у себя запоминаем только отметку о входе
    markSession(true);
    currentUser = data.user;

    form.reset();
    closeModal('loginModal');
    await applyAuthState();
    showToast(`Вы вошли как ${currentUser.email}`, 'success');
  } catch (err) {
    showToast(err.message, 'error');
    loadCaptcha('login'); // код одноразовый — после неудачи нужен новый
  } finally {
    setFormBusy(form, false);
  }
});

// ---------- Выход ----------

document.getElementById('logoutBtn').addEventListener('click', async () => {
  // Cookie с токеном может удалить только сервер
  try {
    await apiRequest('/auth/logout', { method: 'POST' });
  } catch (err) {
    // сервер недоступен — выходим хотя бы на этой странице
  }
  clearSession();
  // Закрываем все открытые окна
  document.querySelectorAll('.modal:not(.hidden)').forEach((modal) => closeModal(modal.id));
  updateUI();
  renderProducts();
  renderRoute(); // из кабинета возвращаемся в каталог
  connectRealtime(); // переподключаемся уже как гость
  refreshNotifications(); // очищаем список уведомлений
  showToast('Вы вышли из аккаунта', 'info');
});

// ---------- Смена пароля ----------

document.getElementById('changePasswordBtn').addEventListener('click', () => {
  openModal('changePasswordModal');
});

document.getElementById('changePasswordForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;

  const oldPassword = document.getElementById('oldPassword').value;
  const newPassword = document.getElementById('newPassword').value;
  const confirmPassword = document.getElementById('newPasswordConfirm').value;

  if (!oldPassword || !newPassword) {
    return showToast('Заполните все поля', 'warning');
  }
  if (newPassword.length < MIN_PASSWORD_LENGTH) {
    return showToast(`Новый пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`, 'warning');
  }
  if (newPassword !== confirmPassword) {
    return showToast('Новые пароли не совпадают', 'warning');
  }

  setFormBusy(form, true);
  try {
    const data = await apiRequest('/auth/change-password', {
      method: 'PUT',
      body: { oldPassword, newPassword }
    });

    form.reset();
    closeModal('changePasswordModal');
    showToast(data.message, 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setFormBusy(form, false);
  }
});

// ==================== ПОКАЗАТЬ / СКРЫТЬ ПАРОЛЬ ====================

// Ко всем полям пароля добавляем кнопку-глазик
document.querySelectorAll('input[type="password"]').forEach((input) => {
  // Оборачиваем поле в контейнер, чтобы разместить кнопку поверх правого края
  const wrapper = document.createElement('div');
  wrapper.className = 'relative';
  input.parentNode.insertBefore(wrapper, input);
  wrapper.appendChild(input);

  // Отступ справа, чтобы текст не заезжал под кнопку
  input.style.paddingRight = '2.75rem';

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-200 transition';
  wrapper.appendChild(button);

  // Переключение видимости пароля
  const setVisible = (visible) => {
    input.type = visible ? 'text' : 'password';
    button.innerHTML = `<i class="fa-regular ${visible ? 'fa-eye-slash' : 'fa-eye'}"></i>`;
    button.setAttribute('aria-label', visible ? 'Скрыть пароль' : 'Показать пароль');
    button.title = visible ? 'Скрыть пароль' : 'Показать пароль';
  };

  setVisible(false);
  button.addEventListener('click', () => setVisible(input.type === 'password'));

  // При очистке формы (после успешной отправки) пароль снова скрывается
  if (input.form) {
    input.form.addEventListener('reset', () => setVisible(false));
  }
});

// ==================== ИНДИКАТОР НАДЁЖНОСТИ ПАРОЛЯ ====================

// Уровни надёжности: подпись, цвет и заполнение полоски
const PASSWORD_LEVELS = [
  { label: 'Слабый пароль',   color: '#ef4444', width: '25%' },
  { label: 'Средний пароль',  color: '#eab308', width: '50%' },
  { label: 'Хороший пароль',  color: '#3b82f6', width: '75%' },
  { label: 'Надёжный пароль', color: '#22c55e', width: '100%' }
];

// Оценка пароля: по баллу за длину от 8, длину от 12, буквы разного регистра, цифры, спецсимволы
function getPasswordLevel(password) {
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[a-zа-яё]/.test(password) && /[A-ZА-ЯЁ]/.test(password)) score += 1;
  if (/\d/.test(password)) score += 1;
  if (/[^A-Za-zА-Яа-яЁё0-9]/.test(password)) score += 1;

  // Пароль короче минимально допустимого всегда слабый
  if (password.length < MIN_PASSWORD_LENGTH) score = 0;

  if (score <= 1) return PASSWORD_LEVELS[0];
  if (score === 2) return PASSWORD_LEVELS[1];
  if (score === 3) return PASSWORD_LEVELS[2];
  return PASSWORD_LEVELS[3];
}

// Добавляет под поле пароля полоску и подпись, которые обновляются при вводе
function attachPasswordMeter(inputId) {
  const input = document.getElementById(inputId);

  const meter = document.createElement('div');
  meter.className = 'hidden mt-2';
  meter.innerHTML = `
    <div class="h-1.5 rounded-full bg-gray-700 overflow-hidden">
      <div class="h-full rounded-full transition-all duration-300" style="width:0"></div>
    </div>
    <p class="mt-1 text-xs"></p>`;

  // Поле обёрнуто в контейнер с кнопкой-глазиком — вставляем индикатор после него
  const anchor = input.closest('.relative') || input;
  anchor.insertAdjacentElement('afterend', meter);

  const bar = meter.querySelector('div > div');
  const label = meter.querySelector('p');

  const update = () => {
    const password = input.value;
    meter.classList.toggle('hidden', password.length === 0);
    if (!password) return;

    const level = getPasswordLevel(password);
    bar.style.width = level.width;
    bar.style.background = level.color;
    label.textContent = level.label;
    label.style.color = level.color;
  };

  input.addEventListener('input', update);
  // После очистки формы индикатор скрывается (reset срабатывает до очистки полей)
  if (input.form) {
    input.form.addEventListener('reset', () => setTimeout(update, 0));
  }
}

attachPasswordMeter('registerPassword'); // регистрация
attachPasswordMeter('newPassword');      // смена пароля

// ==================== КАПЧА ====================

// Идентификаторы выданных кодов: отдельно для формы входа и формы регистрации
const captchaIds = { login: null, register: null };

// Загрузка нового кода для формы. prefix — 'login' или 'register'
async function loadCaptcha(prefix) {
  const image = document.getElementById(`${prefix}CaptchaImg`);
  const input = document.getElementById(`${prefix}CaptchaInput`);
  input.value = '';

  try {
    const data = await apiRequest('/auth/captcha');
    captchaIds[prefix] = data.id;
    // Картинку показываем через <img>: так SVG отображается как изображение
    // и никакой код внутри него выполниться не может
    image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(data.svg)}`;
  } catch (err) {
    captchaIds[prefix] = null;
    image.removeAttribute('src');
    showToast('Не удалось загрузить проверочный код', 'error');
  }
}

// Данные капчи для отправки на сервер вместе с формой
function getCaptcha(prefix) {
  return {
    captchaId: captchaIds[prefix],
    captchaAnswer: document.getElementById(`${prefix}CaptchaInput`).value.trim()
  };
}

// Новый код загружается каждый раз, когда открывается окно входа или регистрации
window.addEventListener('modal:open', (event) => {
  if (event.detail === 'loginModal') loadCaptcha('login');
  if (event.detail === 'registerModal') loadCaptcha('register');
});

// Кнопки "другой код" — если символы не разобрать
document.getElementById('loginCaptchaRefresh').addEventListener('click', () => loadCaptcha('login'));
document.getElementById('registerCaptchaRefresh').addEventListener('click', () => loadCaptcha('register'));

