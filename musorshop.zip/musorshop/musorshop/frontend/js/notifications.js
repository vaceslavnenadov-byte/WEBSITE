// notifications.js
// Личные уведомления: колокольчик в шапке, список, мгновенная доставка через realtime.js

// ==================== СОСТОЯНИЕ ====================

let notifications = [];  // последние уведомления (сначала новые)
let notifyUnread = 0;    // сколько из них не прочитано

const NOTIFY_LIMIT = 30; // столько уведомлений держим в списке

// Значок для каждого типа уведомления
const NOTIFY_ICONS = {
  market_sale:   'fa-right-left',
  lot_cancelled: 'fa-ban',
  balance:       'fa-wallet',
  review:        'fa-comment',
  restock:       'fa-heart'
};

function isNotifyPanelOpen() {
  return !document.getElementById('notifyPanel').classList.contains('hidden');
}

// ==================== ОТРИСОВКА ====================

function renderNotifications() {
  // Счётчик непрочитанных на колокольчике
  const badge = document.getElementById('notifyCount');
  badge.textContent = notifyUnread > 99 ? '99+' : notifyUnread;
  badge.classList.toggle('hidden', notifyUnread === 0);
  badge.classList.toggle('flex', notifyUnread > 0);

  const list = document.getElementById('notifyList');
  if (notifications.length === 0) {
    list.innerHTML = '<p class="px-4 py-6 text-sm text-center text-gray-500">Уведомлений пока нет</p>';
    return;
  }

  list.innerHTML = notifications.map((item) => `
    <div class="flex gap-3 px-4 py-3 border-b border-gray-800 ${item.read ? '' : 'bg-gray-800'}">
      <div class="w-8 h-8 shrink-0 rounded-full bg-gray-950 flex items-center justify-center text-xs text-yellow-500">
        <i class="fa-solid ${NOTIFY_ICONS[item.type] || 'fa-bell'}"></i>
      </div>
      <div class="min-w-0">
        <p class="text-sm break-words">${escapeHtml(item.text)}</p>
        <p class="mt-1 text-xs text-gray-500">${formatDate(item.createdAt)}</p>
      </div>
    </div>`).join('');
}

// ==================== ЗАГРУЗКА И ОТМЕТКА О ПРОЧТЕНИИ ====================

// Вызывается после входа, выхода и при восстановлении сессии
async function refreshNotifications() {
  if (!currentUser) {
    notifications = [];
    notifyUnread = 0;
    document.getElementById('notifyPanel').classList.add('hidden');
    renderNotifications();
    return;
  }

  try {
    const data = await apiRequest('/notifications');
    notifications = data.items;
    notifyUnread = data.unread;
  } catch (err) {
    // не удалось загрузить — колокольчик просто останется пустым
  }
  renderNotifications();
}

// Отметить все уведомления прочитанными
async function markNotificationsRead() {
  if (notifyUnread === 0) return;

  notifyUnread = 0;
  renderNotifications(); // счётчик гасим сразу, а подсветку новых оставляем до закрытия панели

  try {
    await apiRequest('/notifications/read', { method: 'POST' });
  } catch (err) {
    // не страшно: отметим при следующем открытии
  }
}

// ==================== ПАНЕЛЬ ====================

function closeNotifyPanel() {
  if (!isNotifyPanelOpen()) return;
  document.getElementById('notifyPanel').classList.add('hidden');

  // После просмотра снимаем подсветку "новое"
  notifications.forEach((item) => { item.read = true; });
  renderNotifications();
}

document.getElementById('notifyBtn').addEventListener('click', (event) => {
  event.stopPropagation(); // чтобы обработчик "клик вне панели" её тут же не закрыл

  if (isNotifyPanelOpen()) {
    closeNotifyPanel();
  } else {
    document.getElementById('notifyPanel').classList.remove('hidden');
    markNotificationsRead();
  }
});

// Клик вне панели и клавиша Esc закрывают её
document.addEventListener('click', (event) => {
  if (!event.target.closest('#notifyPanel')) closeNotifyPanel();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeNotifyPanel();
});

// Очистка списка
document.getElementById('notifyClearBtn').addEventListener('click', async () => {
  if (notifications.length === 0) return;

  try {
    await apiRequest('/notifications', { method: 'DELETE' });
    notifications = [];
    notifyUnread = 0;
    renderNotifications();
  } catch (err) {
    showToast(err.message, 'error');
  }
});

// ==================== МГНОВЕННАЯ ДОСТАВКА ====================

// Сервер прислал новое уведомление по открытому соединению
realtimeHandlers.notification = (item) => {
  notifications.unshift(item);
  notifications = notifications.slice(0, NOTIFY_LIMIT);

  if (isNotifyPanelOpen()) {
    markNotificationsRead(); // панель открыта — пользователь его уже видит
  } else {
    notifyUnread += 1;
  }
  renderNotifications();

  showToast(item.text, 'info', 6000);

  // Уведомление почти всегда означает, что изменился баланс или инвентарь.
  // Подтягиваем свежие данные, чтобы шапка и кабинет не показывали устаревшее
  apiRequest('/auth/me')
    .then((user) => {
      currentUser = user;
      updateUI();
      if (!document.getElementById('profileView').classList.contains('hidden')) {
        loadProfilePage();
      }
    })
    .catch(() => {});
};

renderNotifications();
