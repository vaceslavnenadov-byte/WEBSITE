// ui.js
// Интерфейс: уведомления, модальные окна, окно подтверждения, шапка, темы оформления

// ==================== УВЕДОМЛЕНИЯ (TOAST) ====================

const TOAST_TYPES = {
  success: { icon: '✅', border: 'border-green-500' },
  error:   { icon: '❌', border: 'border-red-500' },
  info:    { icon: 'ℹ️', border: 'border-blue-500' },
  warning: { icon: '⚠️', border: 'border-yellow-500' }
};

// Показать уведомление. duration — время показа в миллисекундах
function showToast(message, type = 'info', duration = 3500) {
  const container = document.getElementById('toastContainer');
  const style = TOAST_TYPES[type] || TOAST_TYPES.info;

  const toast = document.createElement('div');
  toast.setAttribute('role', 'status');
  // Начальное состояние: прозрачный и сдвинут вправо (для анимации появления)
  toast.className =
    `flex items-start gap-3 p-4 rounded-xl bg-gray-900 border border-gray-800 border-l-4 ${style.border} ` +
    'shadow-2xl text-sm cursor-pointer transition-all duration-300 opacity-0 translate-x-8';
  toast.innerHTML =
    `<span class="text-lg leading-none">${style.icon}</span>` +
    `<span class="flex-1">${escapeHtml(message)}</span>`;

  container.appendChild(toast);

  // Через мгновение убираем "скрытые" классы — toast плавно выезжает
  setTimeout(() => toast.classList.remove('opacity-0', 'translate-x-8'), 20);

  // Плавное исчезновение и удаление из страницы
  const hide = () => {
    toast.classList.add('opacity-0', 'translate-x-8');
    setTimeout(() => toast.remove(), 300);
  };

  const timer = setTimeout(hide, duration);

  // По клику уведомление закрывается сразу
  toast.addEventListener('click', () => {
    clearTimeout(timer);
    hide();
  });
}

// ==================== МОДАЛЬНЫЕ ОКНА ====================

function openModal(id) {
  const modal = document.getElementById(id);
  modal.classList.remove('hidden');
  modal.classList.add('flex');

  // Сообщаем остальным частям приложения, что окно открылось
  // (по этому сигналу, например, загружается капча)
  window.dispatchEvent(new CustomEvent('modal:open', { detail: id }));
}

function closeModal(id) {
  const modal = document.getElementById(id);
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}

// Общая логика закрытия для всех окон сразу
document.querySelectorAll('.modal').forEach((modal) => {
  // Клик по затемнённому фону (но не по самому окну)
  modal.addEventListener('mousedown', (event) => {
    if (event.target === modal) closeModal(modal.id);
  });
  // Клик по крестику
  modal.querySelector('.modal-close').addEventListener('click', () => closeModal(modal.id));
});

// Esc закрывает самое верхнее открытое окно
document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  const opened = document.querySelectorAll('.modal:not(.hidden)');
  if (opened.length > 0) {
    closeModal(opened[opened.length - 1].id);
  }
});

// ==================== ИНТЕРФЕЙС ====================

// Обновляет шапку в зависимости от того, вошёл пользователь или нет
function updateUI() {
  const guestButtons = document.getElementById('guestButtons');
  const userButtons = document.getElementById('userButtons');

  if (currentUser) {
    guestButtons.classList.add('hidden');
    guestButtons.classList.remove('flex');
    userButtons.classList.remove('hidden');
    userButtons.classList.add('flex');
    document.getElementById('headerBalance').textContent = formatPrice(currentUser.balance);
  } else {
    guestButtons.classList.remove('hidden');
    guestButtons.classList.add('flex');
    userButtons.classList.add('hidden');
    userButtons.classList.remove('flex');
  }

  updateCartBadge(); // кнопка корзины и счётчик на ней
  updateBonusButton(); // кнопка-подарок, когда доступен ежедневный бонус
}

// ==================== ФИНАЛЬНЫЕ ШТРИХИ ====================

// ---------- Кнопка "Наверх" ----------
const scrollTopBtn = document.getElementById('scrollTopBtn');

// Показываем кнопку, когда страница прокручена больше чем на 400 пикселей
window.addEventListener('scroll', () => {
  const visible = window.scrollY > 400;
  scrollTopBtn.classList.toggle('hidden', !visible);
  scrollTopBtn.classList.toggle('flex', visible);
}, { passive: true });

scrollTopBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// ---------- Копирование email в личном кабинете ----------
document.getElementById('copyEmailBtn').addEventListener('click', async () => {
  if (!currentUser) return;

  try {
    await navigator.clipboard.writeText(currentUser.email);
    showToast('Email скопирован в буфер обмена', 'success');
  } catch (err) {
    showToast('Не удалось скопировать email', 'error');
  }
});

// ==================== ОКНО ПОДТВЕРЖДЕНИЯ ====================

const confirmModal = document.getElementById('confirmModal');
const confirmOkBtn = document.getElementById('confirmOkBtn');
const confirmCancelBtn = document.getElementById('confirmCancelBtn');

let confirmResolver = null;     // функция, которая "отвечает" на вопрос окна
let confirmPrevFocus = null;    // элемент, на котором был фокус до открытия окна

// Закрытие окна с результатом: true — подтвердили, false — отменили
function closeConfirm(result) {
  confirmModal.classList.add('hidden');
  confirmModal.classList.remove('flex');

  const resolve = confirmResolver;
  confirmResolver = null;

  // Возвращаем фокус туда, где он был
  if (confirmPrevFocus && document.contains(confirmPrevFocus)) {
    confirmPrevFocus.focus();
  }
  confirmPrevFocus = null;

  if (resolve) resolve(result);
}

// Показать окно подтверждения. Возвращает Promise<boolean>.
// Использование: if (!(await confirmDialog({ ... }))) return;
//   danger: true — красная кнопка (для удаления и других необратимых действий)
function confirmDialog({
  title = 'Подтверждение',
  message = '',
  confirmText = 'Подтвердить',
  cancelText = 'Отмена',
  danger = false
} = {}) {
  // Если окно уже открыто — предыдущий вопрос считаем отменённым
  if (confirmResolver) closeConfirm(false);

  // textContent вставляет текст как есть, без разбора HTML — это безопасно
  document.getElementById('confirmTitle').textContent = title;
  document.getElementById('confirmMessage').textContent = message;
  confirmOkBtn.textContent = confirmText;
  confirmCancelBtn.textContent = cancelText;

  // Цвет кнопки подтверждения
  confirmOkBtn.classList.toggle('bg-red-600', danger);
  confirmOkBtn.classList.toggle('hover:bg-red-500', danger);
  confirmOkBtn.classList.toggle('text-white', danger);
  confirmOkBtn.classList.toggle('bg-yellow-500', !danger);
  confirmOkBtn.classList.toggle('hover:bg-yellow-400', !danger);
  confirmOkBtn.classList.toggle('text-black', !danger);

  confirmPrevFocus = document.activeElement;
  confirmModal.classList.remove('hidden');
  confirmModal.classList.add('flex');

  // Для опасных действий фокус на "Отмена", чтобы случайный Enter ничего не удалил
  (danger ? confirmCancelBtn : confirmOkBtn).focus();

  return new Promise((resolve) => {
    confirmResolver = resolve;
  });
}

confirmOkBtn.addEventListener('click', () => closeConfirm(true));
confirmCancelBtn.addEventListener('click', () => closeConfirm(false));

// Клик по затемнённому фону = отмена
confirmModal.addEventListener('mousedown', (event) => {
  if (event.target === confirmModal) closeConfirm(false);
});

// Esc = отмена. Слушаем на фазе перехвата (третий аргумент true) и останавливаем событие,
// чтобы общий обработчик Esc не закрыл заодно окно, лежащее под подтверждением
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && confirmResolver) {
    event.stopPropagation();
    closeConfirm(false);
  }
}, true);

// ==================== ТЕМЫ ОФОРМЛЕНИЯ ====================

// Три режима: system — как в операционной системе, light — светлая, dark — тёмная
const THEME_MODES = {
  system: { label: 'Системная', icon: 'fa-circle-half-stroke' },
  light:  { label: 'Светлая',   icon: 'fa-sun' },
  dark:   { label: 'Тёмная',    icon: 'fa-moon' }
};
const THEME_ORDER = ['system', 'light', 'dark'];

// Запрос к системе: предпочитает ли пользователь светлое оформление
const systemLightQuery = window.matchMedia('(prefers-color-scheme: light)');

// Выбранный пользователем режим (по умолчанию — системный)
function getThemePreference() {
  try {
    const saved = localStorage.getItem('theme');
    return THEME_MODES[saved] ? saved : 'system';
  } catch (err) {
    return 'system';
  }
}

// Применение темы: выставляет атрибут data-theme у <html> и обновляет кнопку
function applyTheme() {
  const preference = getThemePreference();

  // В системном режиме фактическую тему определяют настройки ОС
  const actual = preference === 'system'
    ? (systemLightQuery.matches ? 'light' : 'dark')
    : preference;

  document.documentElement.setAttribute('data-theme', actual);

  const mode = THEME_MODES[preference];
  const button = document.getElementById('themeBtn');
  button.innerHTML = `<i class="fa-solid ${mode.icon}"></i>`;
  button.title = `Тема: ${mode.label}. Нажмите, чтобы сменить`;
  button.setAttribute('aria-label', `Тема оформления: ${mode.label}`);
}

// Клик по кнопке переключает режимы по кругу: системная → светлая → тёмная
document.getElementById('themeBtn').addEventListener('click', () => {
  const current = getThemePreference();
  const next = THEME_ORDER[(THEME_ORDER.indexOf(current) + 1) % THEME_ORDER.length];

  try {
    localStorage.setItem('theme', next);
  } catch (err) {
    // хранилище недоступно — тема сменится только до перезагрузки
  }

  applyTheme();
  showToast(`Тема: ${THEME_MODES[next].label.toLowerCase()}`, 'info', 2000);
});

// Синхронизация с системой: если в ОС сменили оформление, а у нас выбран
// системный режим — сайт переключается сразу, без перезагрузки
systemLightQuery.addEventListener('change', () => {
  if (getThemePreference() === 'system') {
    applyTheme();
  }
});

applyTheme();

// ==================== МЕНЮ НА УЗКИХ ЭКРАНАХ ====================

const menuBtn = document.getElementById('menuBtn');
const mainNav = document.getElementById('mainNav');

// Открытие и закрытие меню. На широком экране навигация видна всегда
// (за это отвечает класс xl:flex), и эти переключения на неё не влияют
function setMenuOpen(open) {
  mainNav.classList.toggle('hidden', !open);
  mainNav.classList.toggle('flex', open);
  menuBtn.setAttribute('aria-expanded', String(open));
  menuBtn.innerHTML = `<i class="fa-solid ${open ? 'fa-xmark' : 'fa-bars'}"></i>`;
}

function isMenuOpen() {
  return menuBtn.getAttribute('aria-expanded') === 'true';
}

menuBtn.addEventListener('click', (event) => {
  event.stopPropagation(); // чтобы обработчик "клик вне меню" его тут же не закрыл
  setMenuOpen(!isMenuOpen());
});

// Меню закрывается после выбора пункта (кроме смены темы: её удобно листать подряд),
// при переходе на другой экран, по клику вне меню и по Esc
mainNav.addEventListener('click', (event) => {
  if (event.target.closest('a, #homeBtn')) setMenuOpen(false);
});
window.addEventListener('hashchange', () => setMenuOpen(false));
document.addEventListener('click', (event) => {
  if (isMenuOpen() && !event.target.closest('#mainNav')) setMenuOpen(false);
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && isMenuOpen()) setMenuOpen(false);
});
