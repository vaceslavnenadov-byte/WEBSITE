// catalog.js
// Каталог: карточки товаров, поиск, сортировка, фильтры, пагинация, редкость, скелетоны.
// Поиск, фильтрация, сортировка и разбивка на страницы выполняются на сервере

// ==================== ТОВАРЫ ====================

// ---------- Состояние каталога ----------
const PAGE_SIZE = 8;         // товаров на странице (то же число задано на сервере)
let searchQuery = '';        // текст поиска
let sortMode = 'newest';     // выбранная сортировка
let currentPage = 1;         // текущая страница
let catalogPages = 1;        // сколько всего страниц (сообщает сервер)
let catalogTotal = 0;        // сколько товаров подходит под поиск и фильтры
let productsLoaded = false;  // пришёл ли уже хотя бы один ответ сервера

// Допустимые варианты сортировки. Сама сортировка выполняется на сервере
const SORTERS = {
  'newest': true,
  'price-asc': true,
  'price-desc': true,
  'title-asc': true,
  'title-desc': true,
  'quantity-desc': true
};

// Фильтры каталога. Пустая строка и false означают "фильтр выключен"
const DEFAULT_FILTERS = {
  category: '',
  rarity: '',
  wear: '',
  minPrice: '',
  maxPrice: '',
  inStock: false,
  statTrak: false,
  wishlist: false
};
let catalogFilters = { ...DEFAULT_FILTERS };

function hasActiveFilters() {
  return Object.keys(DEFAULT_FILTERS).some((key) => catalogFilters[key] !== DEFAULT_FILTERS[key]);
}

// ---------- Кэш товаров ----------
// В переменной products лежит только текущая страница каталога.
// Корзине нужны и товары с других страниц, поэтому всё загруженное запоминаем здесь
const productCache = new Map();

function rememberProducts(list) {
  list.forEach((product) => productCache.set(product._id, product));
}

function getCachedProduct(productId) {
  return productCache.get(productId) || null;
}

// Загрузка свежих данных о товарах по списку id (остатки и цены могли измениться).
// Товары, которых больше нет в магазине, из кэша удаляются
async function refreshProductsByIds(ids) {
  const unique = [...new Set(ids)];
  if (unique.length === 0) return;

  const found = await apiRequest(`/products/by-ids?ids=${unique.join(',')}`);
  unique.forEach((id) => productCache.delete(id));
  rememberProducts(found);
}

// Параметры запроса к серверу: страница, сортировка, поиск и включённые фильтры
function buildCatalogQuery() {
  const params = new URLSearchParams();
  params.set('page', currentPage);
  params.set('sort', sortMode);

  const search = searchQuery.trim();
  if (search) params.set('search', search);

  ['category', 'rarity', 'wear'].forEach((key) => {
    if (catalogFilters[key]) params.set(key, catalogFilters[key]);
  });
  ['minPrice', 'maxPrice'].forEach((key) => {
    // Цену отправляем, только если это целое неотрицательное число
    if (/^\d+$/.test(catalogFilters[key])) params.set(key, catalogFilters[key]);
  });
  ['inStock', 'statTrak', 'wishlist'].forEach((key) => {
    if (catalogFilters[key]) params.set(key, '1');
  });

  return params.toString();
}

// Номер последнего отправленного запроса. Если пользователь быстро меняет фильтры,
// ответы могут прийти не по порядку — устаревшие мы пропускаем
let loadRequestId = 0;

// Загрузка страницы каталога с сервера
async function loadProducts() {
  // При первой загрузке показываем карточки-скелетоны
  if (!productsLoaded) {
    renderSkeletons();
  }

  // Фильтр "только избранное" доступен только покупателю
  const isBuyer = currentUser && currentUser.role === 'user';
  if (catalogFilters.wishlist && !isBuyer) {
    catalogFilters.wishlist = false;
    syncFilterControls();
  }

  const requestId = ++loadRequestId;

  try {
    const data = await apiRequest(`/products?${buildCatalogQuery()}`);
    if (requestId !== loadRequestId) return; // уже отправлен более новый запрос

    products = data.items;
    catalogPages = data.pages;
    catalogTotal = data.total;
    currentPage = data.page; // сервер мог поправить номер страницы (например, после удаления товара)
    productsLoaded = true;

    rememberProducts(products);
    saveCatalogState();
    renderProducts();
  } catch (err) {
    if (requestId !== loadRequestId) return;
    document.getElementById('productsGrid').innerHTML =
      '<p class="col-span-full text-center text-red-400 py-10">Не удалось загрузить товары</p>';
    showToast(err.message, 'error');
  }
}

// HTML одной карточки товара
function createProductCard(product) {
  const isAdmin = currentUser && currentUser.role === 'admin';
  const isBuyer = currentUser && currentUser.role === 'user';
  const inStock = product.quantity > 0;
  const rarity = getRarity(product);

  const id = escapeHtml(product._id);
  const title = escapeHtml(product.title);
  const description = escapeHtml(product.description);

  // Картинка; если ссылки нет или она не загрузилась — показываем иконку-заглушку
  const placeholder = '<i class="fa-solid fa-image text-4xl text-gray-700"></i>';
  const image = product.imageUrl
    ? `<img src="${escapeHtml(product.imageUrl)}" alt="${title}" loading="lazy"
            class="w-full h-full object-contain p-3"
            onerror="this.replaceWith(Object.assign(document.createElement('i'), { className: 'fa-solid fa-image text-4xl text-gray-700' }))">`
    : placeholder;

  // Рейтинг (данные появятся на шаге 22)
  const rating = ratings[product._id];
  const ratingHtml = rating
    ? `<span class="text-yellow-500"><i class="fa-solid fa-star"></i> ${rating.average}</span>
       <span class="text-gray-500">(${rating.count})</span>`
    : '<span class="text-gray-500">Нет оценок</span>';

  // Сердечко избранного — только для покупателя
  const inWishlist = wishlistIds.has(product._id);
  const heartButton = isBuyer
    ? `<button type="button" data-action="wishlist" data-id="${id}"
               aria-label="${inWishlist ? 'Убрать из избранного' : 'Добавить в избранное'}"
               class="absolute top-2 left-2 w-9 h-9 rounded-full bg-gray-950/70 flex items-center justify-center transition
                      ${inWishlist ? 'text-red-500' : 'text-gray-400 hover:text-red-400'}">
         <i class="${inWishlist ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
       </button>`
    : '';

  // Кнопки редактирования и удаления — только для админа, появляются при наведении
  const adminButtons = isAdmin
    ? `<div class="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition">
         <button type="button" data-action="edit" data-id="${id}" aria-label="Редактировать"
                 class="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-500 text-white">✎</button>
         <button type="button" data-action="delete" data-id="${id}" aria-label="Удалить"
                 class="w-9 h-9 rounded-full bg-red-600 hover:bg-red-500 text-white">✕</button>
       </div>`
    : '';

  // Кнопки "Купить" и "В корзину" — только для покупателя
  let buyButton = '';
  if (isBuyer) {
    const inCart = isInCart(product._id);
    buyButton = inStock
      ? `<button type="button" data-action="buy" data-id="${id}"
                 class="flex-1 py-2 rounded-lg bg-yellow-500 text-black text-sm font-semibold hover:bg-yellow-400 transition">
           Купить
         </button>
         <button type="button" data-action="cart" data-id="${id}"
                 aria-label="Добавить в корзину" title="${inCart ? 'Уже в корзине — добавить ещё' : 'Добавить в корзину'}"
                 class="shrink-0 w-10 rounded-lg border text-sm transition
                        ${inCart
                          ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500'
                          : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-yellow-500'}">
           <i class="fa-solid ${inCart ? 'fa-check' : 'fa-cart-plus'}"></i>
         </button>`
      : `<button type="button" disabled
                 class="flex-1 py-2 rounded-lg bg-gray-800 text-gray-500 text-sm font-semibold cursor-not-allowed">
           Нет в наличии
         </button>`;
  }

  return `
    <article class="group relative flex flex-col bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/60 transition">
      <div class="relative h-44 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
        ${image}
        ${heartButton}
        ${adminButtons}
        ${product.statTrak
          ? '<span class="absolute bottom-3 left-2 px-2 py-0.5 rounded bg-orange-500 text-black text-[10px] font-bold">StatTrak™</span>'
          : ''}
        <!-- Цветная полоса редкости -->
        <div class="absolute bottom-0 inset-x-0 h-1" style="background:${rarity.color}"></div>
      </div>
      <div class="flex flex-col flex-1 p-4">
        <h3 class="font-semibold leading-snug">${title}</h3>
        <p class="text-xs font-medium" style="color:${rarity.color}">${rarity.label}</p>
        ${getProductMeta(product) ? `<p class="text-xs text-gray-400">${getProductMeta(product)}</p>` : ''}
        <p class="mt-1 text-sm">${ratingHtml}</p>
        <p class="mt-2 text-sm text-gray-400 line-clamp-2">${description}</p>
        <div class="mt-auto pt-4 flex items-end justify-between gap-2">
          <p class="text-xl font-bold text-yellow-500">${formatPrice(product.price)} ₽</p>
          <p class="text-xs ${inStock ? 'text-gray-400' : 'text-red-400'}">
            ${inStock ? `В наличии: ${product.quantity}` : 'Нет в наличии'}
          </p>
        </div>
        <div class="mt-3 flex gap-2">
          <button type="button" data-action="reviews" data-id="${id}"
                  class="flex-1 py-2 rounded-lg bg-gray-800 border border-gray-700 text-sm font-medium hover:bg-gray-700 transition">
            💬 Отзывы
          </button>
          ${buyButton}
        </div>
      </div>
    </article>`;
}

// Отрисовка текущей страницы каталога.
// Поиск, фильтры, сортировку и разбивку на страницы выполняет сервер
function renderProducts() {
  const grid = document.getElementById('productsGrid');
  const emptyState = document.getElementById('emptyState');
  const isAdmin = currentUser && currentUser.role === 'admin';
  const isBuyer = currentUser && currentUser.role === 'user';

  // Галочка "только избранное" видна только покупателю
  document.getElementById('filterWishlistLabel').classList.toggle('hidden', !isBuyer);

  // Пока сервер не ответил, на экране остаются скелетоны
  if (!productsLoaded) return;

  // Пользователь вышел при включённом фильтре избранного — загружаем каталог заново
  // (loadProducts сам выключит этот фильтр)
  if (catalogFilters.wishlist && !isBuyer) {
    loadProducts();
    return;
  }

  document.getElementById('catalogTotal').textContent = catalogTotal;

  // Ничего не нашлось по поиску или фильтрам — показываем плашку
  const nothingFound = products.length === 0 && (searchQuery.trim() !== '' || hasActiveFilters());
  emptyState.classList.toggle('hidden', !nothingFound);
  grid.classList.toggle('hidden', nothingFound);

  if (nothingFound) {
    grid.innerHTML = '';
    renderPagination(1);
    return;
  }

  let html = products.map(createProductCard).join('');

  // Карточка-плюсик для админа — только на последней странице
  if (isAdmin && currentPage === catalogPages) {
    html += createAddCard();
  }

  if (!html) {
    html = '<p class="col-span-full text-center text-gray-500 py-10">Товаров пока нет</p>';
  }

  grid.innerHTML = html;
  renderPagination(catalogPages);
}

// Один обработчик кликов на всю сетку (делегирование событий).
// По атрибуту data-action определяем, какая кнопка нажата
document.getElementById('productsGrid').addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;

  const handler = cardActions[button.dataset.action];
  if (handler) {
    handler(button.dataset.id, button);
  } else {
    showToast('Эта функция появится на следующих шагах', 'info');
  }
});

// ==================== ШАПКА: ЛОГОТИП И "ГЛАВНАЯ" ====================

function goHome(event) {
  if (event) event.preventDefault();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

document.getElementById('homeBtn').addEventListener('click', goHome);
document.getElementById('logoLink').addEventListener('click', goHome);

// ==================== ПОИСК, СОРТИРОВКА, ПАГИНАЦИЯ ====================

// Какие номера страниц показывать: первая, последняя и соседи текущей.
// Пропуски заменяются на "...". Пример: (20, 6) -> [1, '...', 5, 6, 7, '...', 20]
function getPageNumbers(totalPages, page) {
  const wanted = new Set([1, totalPages, page - 1, page, page + 1]);
  const pages = [...wanted]
    .filter((number) => number >= 1 && number <= totalPages)
    .sort((a, b) => a - b);

  const result = [];
  pages.forEach((number, index) => {
    if (index > 0) {
      const gap = number - pages[index - 1];
      if (gap === 2) {
        result.push(number - 1); // пропущена одна страница — показываем её, а не "..."
      } else if (gap > 2) {
        result.push('...');
      }
    }
    result.push(number);
  });
  return result;
}

// Отрисовка кнопок пагинации
function renderPagination(totalPages) {
  const container = document.getElementById('pagination');

  // Одна страница — пагинация не нужна
  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  const baseClass = 'min-w-[2.5rem] px-3 py-2 rounded-lg text-sm font-medium transition';
  const normalClass = 'bg-gray-900 border border-gray-800 text-gray-300 hover:border-yellow-500';
  const activeClass = 'bg-yellow-500 text-black';
  const disabledClass = 'bg-gray-900 border border-gray-800 text-gray-600 cursor-not-allowed';

  const isFirst = currentPage === 1;
  const isLast = currentPage === totalPages;

  let html = `
    <button type="button" data-page="${currentPage - 1}" ${isFirst ? 'disabled' : ''}
            class="${baseClass} ${isFirst ? disabledClass : normalClass}">← Назад</button>`;

  getPageNumbers(totalPages, currentPage).forEach((item) => {
    if (item === '...') {
      html += '<span class="px-2 text-gray-500">…</span>';
    } else {
      html += `
        <button type="button" data-page="${item}" ${item === currentPage ? 'aria-current="page"' : ''}
                class="${baseClass} ${item === currentPage ? activeClass : normalClass}">${item}</button>`;
    }
  });

  html += `
    <button type="button" data-page="${currentPage + 1}" ${isLast ? 'disabled' : ''}
            class="${baseClass} ${isLast ? disabledClass : normalClass}">Вперёд →</button>`;

  container.innerHTML = html;
}

// Переход на страницу по клику (делегирование)
document.getElementById('pagination').addEventListener('click', (event) => {
  const button = event.target.closest('[data-page]');
  if (!button || button.disabled) return;

  currentPage = Number(button.dataset.page);
  loadProducts();

  // Плавно прокручиваем к началу сетки (с отступом под закреплённую шапку)
  const grid = document.getElementById('productsGrid');
  const top = grid.getBoundingClientRect().top + window.scrollY - 100;
  window.scrollTo({ top, behavior: 'smooth' });
});

// Дебаунс: функция вызывается только после паузы в delay мс.
// Благодаря этому поиск не запускается на каждую набранную букву
function debounce(fn, delay) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// Поиск с задержкой 300 мс
document.getElementById('searchInput').addEventListener('input', debounce((event) => {
  searchQuery = event.target.value;
  currentPage = 1; // при новом запросе возвращаемся на первую страницу
  loadProducts();
}, 300));

// Смена сортировки
document.getElementById('sortSelect').addEventListener('change', (event) => {
  sortMode = event.target.value;
  currentPage = 1;
  loadProducts();
});

// Кнопка "Главная" и логотип сбрасывают поиск, сортировку, фильтры и страницу
function resetCatalog() {
  searchQuery = '';
  sortMode = 'newest';
  currentPage = 1;
  catalogFilters = { ...DEFAULT_FILTERS };
  document.getElementById('searchInput').value = '';
  document.getElementById('sortSelect').value = 'newest';
  syncFilterControls();
  loadProducts();
}

document.getElementById('homeBtn').addEventListener('click', resetCatalog);
document.getElementById('logoLink').addEventListener('click', resetCatalog);

// ==================== СКЕЛЕТОНЫ ЗАГРУЗКИ ====================

// Серые мерцающие карточки-заготовки на время загрузки товаров
function renderSkeletons() {
  const card = `
    <div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden animate-pulse" aria-hidden="true">
      <div class="h-44 bg-gray-800"></div>
      <div class="p-4 space-y-3">
        <div class="h-4 w-3/4 rounded bg-gray-800"></div>
        <div class="h-3 w-1/3 rounded bg-gray-800"></div>
        <div class="h-3 rounded bg-gray-800"></div>
        <div class="h-6 w-1/2 rounded bg-gray-800"></div>
        <div class="h-9 rounded bg-gray-800"></div>
      </div>
    </div>`;

  // Столько же карточек, сколько помещается на странице
  document.getElementById('productsGrid').innerHTML = card.repeat(PAGE_SIZE);
}

// ==================== РЕДКОСТЬ СКИНОВ ====================

// Справочник редкостей: подпись и цвет (как в CS2)
const RARITY_INFO = {
  milspec:    { label: 'Армейское',     color: '#4b69ff' },
  restricted: { label: 'Запрещённое',   color: '#8847ff' },
  classified: { label: 'Засекреченное', color: '#d32ce6' },
  covert:     { label: 'Тайное',        color: '#eb4b4b' },
  gold:       { label: 'Редкое',        color: '#e4ae39' }
};

// Редкость предмета: { key, label, color }. У старых товаров без редкости — "Армейское"
function getRarity(item) {
  const key = item && RARITY_INFO[item.rarity] ? item.rarity : 'milspec';
  return { key, ...RARITY_INFO[key] };
}

// ==================== КАТЕГОРИЯ И КАЧЕСТВО ====================

// Категории оружия (те же ключи, что на сервере)
const CATEGORY_INFO = {
  rifle:  'Винтовки',
  sniper: 'Снайперские винтовки',
  pistol: 'Пистолеты',
  smg:    'Пистолеты-пулемёты',
  heavy:  'Тяжёлое оружие',
  knife:  'Ножи',
  gloves: 'Перчатки',
  other:  'Другое'
};

// Качество (износ) — названия как в игре, не переводятся
const WEAR_INFO = {
  fn: 'Factory New',
  mw: 'Minimal Wear',
  ft: 'Field-Tested',
  ww: 'Well-Worn',
  bs: 'Battle-Scarred'
};

// Строка характеристик для карточки: "Field-Tested · Винтовки".
// Категорию "Другое" и неуказанное качество не показываем
function getProductMeta(product) {
  const parts = [];
  if (WEAR_INFO[product.wear]) parts.push(WEAR_INFO[product.wear]);
  if (CATEGORY_INFO[product.category] && product.category !== 'other') {
    parts.push(CATEGORY_INFO[product.category]);
  }
  return parts.join(' · ');
}

// ==================== ФИЛЬТРЫ КАТАЛОГА ====================

// Соответствие "поле фильтра → id элемента управления"
const FILTER_CONTROLS = {
  category: 'filterCategory',
  rarity: 'filterRarity',
  wear: 'filterWear',
  minPrice: 'filterMinPrice',
  maxPrice: 'filterMaxPrice',
  inStock: 'filterInStock',
  statTrak: 'filterStatTrak',
  wishlist: 'filterWishlist'
};

// Выставляет элементы управления по текущим значениям фильтров
// (после сброса, восстановления из хранилища или отключения избранного)
function syncFilterControls() {
  Object.entries(FILTER_CONTROLS).forEach(([key, id]) => {
    const control = document.getElementById(id);
    if (typeof DEFAULT_FILTERS[key] === 'boolean') {
      control.checked = catalogFilters[key];
    } else {
      control.value = catalogFilters[key];
    }
  });

  // Кнопка сброса видна, только когда хоть один фильтр включён
  document.getElementById('filterResetBtn').classList.toggle('hidden', !hasActiveFilters());
}

// Считывает значения из элементов управления и перезагружает каталог
function applyFilters() {
  Object.entries(FILTER_CONTROLS).forEach(([key, id]) => {
    const control = document.getElementById(id);
    catalogFilters[key] = typeof DEFAULT_FILTERS[key] === 'boolean'
      ? control.checked
      : control.value.trim();
  });

  currentPage = 1; // при смене фильтров возвращаемся на первую страницу
  document.getElementById('filterResetBtn').classList.toggle('hidden', !hasActiveFilters());
  loadProducts();
}

// Списки и галочки применяются сразу, поля цены — после паузы в наборе
const applyFiltersDebounced = debounce(applyFilters, 400);

Object.entries(FILTER_CONTROLS).forEach(([key, id]) => {
  const control = document.getElementById(id);
  const isPrice = key === 'minPrice' || key === 'maxPrice';
  control.addEventListener(isPrice ? 'input' : 'change', isPrice ? applyFiltersDebounced : applyFilters);
});

// Сброс только фильтров (поиск и сортировка остаются)
document.getElementById('filterResetBtn').addEventListener('click', () => {
  catalogFilters = { ...DEFAULT_FILTERS };
  currentPage = 1;
  syncFilterControls();
  loadProducts();
});

// ==================== ЗАПОМИНАНИЕ СОСТОЯНИЯ КАТАЛОГА ====================

// Сортировка — личная настройка, храним в localStorage (сохраняется надолго).
// Страница, поиск и фильтры — в sessionStorage (живут, пока открыта вкладка, и переживают F5)
function saveCatalogState() {
  try {
    localStorage.setItem('catalogSort', sortMode);

    // Фильтр "только избранное" не запоминаем: при загрузке страницы
    // ещё неизвестно, вошёл ли пользователь
    const filters = { ...catalogFilters, wishlist: false };
    sessionStorage.setItem('catalogView', JSON.stringify({
      page: currentPage,
      search: searchQuery,
      filters
    }));
  } catch (err) {
    // хранилище недоступно — просто не запоминаем
  }
}

// Восстановление при загрузке страницы. Этот код выполняется раньше первого
// запроса товаров, поэтому сервер сразу получит сохранённые условия
(function restoreCatalogState() {
  try {
    const savedSort = localStorage.getItem('catalogSort');
    if (savedSort && SORTERS[savedSort]) {
      sortMode = savedSort;
      document.getElementById('sortSelect').value = savedSort;
    }

    const saved = JSON.parse(sessionStorage.getItem('catalogView') || 'null');
    if (saved) {
      if (typeof saved.search === 'string') {
        searchQuery = saved.search.slice(0, 100);
        document.getElementById('searchInput').value = searchQuery;
      }
      if (Number.isInteger(saved.page) && saved.page > 0) {
        currentPage = saved.page;
      }
      // Из сохранённых фильтров берём только известные поля подходящего типа
      if (saved.filters && typeof saved.filters === 'object') {
        Object.keys(DEFAULT_FILTERS).forEach((key) => {
          if (typeof saved.filters[key] === typeof DEFAULT_FILTERS[key]) {
            catalogFilters[key] = saved.filters[key];
          }
        });
        catalogFilters.wishlist = false;
      }
    }
    syncFilterControls();
  } catch (err) {
    // повреждённые данные игнорируем — каталог откроется в обычном виде
  }
})();
