// shop.js
// Магазин: покупка и продажа, избранное, корзина

// ==================== ПОКУПКА И ПРОДАЖА ====================

// Доля цены, которую пользователь получает при продаже (как на сервере)
const SELL_RATE = 0.8;

// Звук успешной покупки: три ноты (до, ми, соль пятой октавы).
// Звук генерируется прямо в браузере через Web Audio API, аудиофайл не нужен
let audioContext = null;

function playSuccessSound() {
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return; // браузер не поддерживает Web Audio

    // Аудиоконтекст создаём один раз и переиспользуем
    if (!audioContext) audioContext = new AudioContextClass();
    if (audioContext.state === 'suspended') audioContext.resume();

    const notes = [523.25, 659.25, 783.99]; // частоты C5, E5, G5 в герцах
    const startTime = audioContext.currentTime;

    notes.forEach((frequency, index) => {
      const oscillator = audioContext.createOscillator(); // генератор тона
      const gain = audioContext.createGain();             // регулятор громкости

      oscillator.type = 'sine';
      oscillator.frequency.value = frequency;

      // Каждая нота начинается на 0.12 с позже предыдущей
      const noteStart = startTime + index * 0.12;

      // Плавное нарастание и затухание громкости, чтобы не было щелчков
      gain.gain.setValueAtTime(0.0001, noteStart);
      gain.gain.exponentialRampToValueAtTime(0.2, noteStart + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.25);

      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start(noteStart);
      oscillator.stop(noteStart + 0.3);
    });
  } catch (err) {
    // звук — необязательная мелочь, ошибки здесь игнорируем
  }
}

// Покупка товара. Вызывается по клику на кнопку "Купить" в карточке
async function handleBuyProduct(productId, button) {
  if (!currentUser) {
    return showToast('Войдите в аккаунт, чтобы покупать', 'warning');
  }

  const product = products.find((item) => item._id === productId);
  if (!product) return;

  // Предварительная проверка баланса (сервер всё равно проверит сам)
  if (currentUser.balance < product.price) {
    return showToast('Недостаточно средств на балансе', 'warning');
  }

  const confirmedBuy = await confirmDialog({
    title: 'Покупка',
    message: `Купить «${product.title}» за ${formatPrice(product.price)} ₽?`,
    confirmText: 'Купить'
  });
  if (!confirmedBuy) return;

  // Блокируем кнопку, чтобы нельзя было купить дважды двойным кликом
  if (button) button.disabled = true;

  try {
    const data = await apiRequest(`/products/${productId}/buy`, { method: 'POST' });

    // Сервер вернул новый баланс — обновляем его у себя
    currentUser.balance = data.balance;
    // Уменьшаем остаток на витрине без повторной загрузки всех товаров
    product.quantity = Math.max(0, product.quantity - 1);

    updateUI();
    renderProducts();
    playSuccessSound();
    showToast(
      `${data.message}. Остаток на балансе: ${formatPrice(data.balance)} ₽`,
      'success',
      5000 // уведомление о покупке висит дольше обычного
    );
  } catch (err) {
    showToast(err.message, 'error');
    // Данные на странице могли устареть (например, товар раскупили) — перезагружаем
    loadProducts();
  }
}

// Продажа купленного предмета за 80% цены.
// Принимает объект покупки, возвращает true при успехе.
// Кнопка "Продать" появится в личном кабинете на шаге 14
async function handleSellProduct(purchase) {
  const refund = Math.floor(purchase.price * SELL_RATE);

  const confirmedSell = await confirmDialog({
    title: 'Продажа',
    message: `Продать «${purchase.productTitle}» за ${formatPrice(refund)} ₽? Это 80% от цены покупки.`,
    confirmText: 'Продать'
  });
  if (!confirmedSell) return false;

  try {
    const data = await apiRequest(`/products/sell/${purchase._id}`, { method: 'POST' });

    currentUser.balance = data.balance;
    updateUI();
    // Товар вернулся на витрину — обновляем остатки
    loadProducts();
    showToast(data.message, 'success');
    return true;
  } catch (err) {
    showToast(err.message, 'error');
    return false;
  }
}

// Подключаем покупку к кнопке "Купить" на карточках
cardActions.buy = handleBuyProduct;

// ==================== ИЗБРАННОЕ ====================

// Добавить товар в избранное или убрать из него. Возвращает true при успехе
async function toggleWishlist(productId, button) {
  if (!currentUser) {
    showToast('Войдите в аккаунт, чтобы пользоваться избранным', 'warning');
    return false;
  }

  const inWishlist = wishlistIds.has(productId);
  if (button) button.disabled = true;

  try {
    await apiRequest(`/products/wishlist/${productId}`, {
      method: inWishlist ? 'DELETE' : 'POST'
    });

    // Обновляем локальный набор id и перерисовываем карточки — сердечко сменит цвет
    if (inWishlist) {
      wishlistIds.delete(productId);
    } else {
      wishlistIds.add(productId);
    }
    // При включённом фильтре "только избранное" список нужно запросить заново
    if (catalogFilters.wishlist) {
      loadProducts();
    } else {
      renderProducts();
    }

    showToast(
      inWishlist ? 'Удалено из избранного' : 'Добавлено в избранное',
      inWishlist ? 'info' : 'success'
    );
    return true;
  } catch (err) {
    showToast(err.message, 'error');
    if (button) button.disabled = false;
    return false;
  }
}

// Сердечко на карточке товара
cardActions.wishlist = toggleWishlist;

// Кнопка-сердечко в списке избранного в личном кабинете
document.getElementById('wishlistList').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-wishlist-remove]');
  if (!button) return;

  const done = await toggleWishlist(button.dataset.wishlistRemove, button);
  if (done) loadWishlist();
});

// ==================== КОРЗИНА ====================

// Ключ в localStorage: у каждого покупателя своя корзина.
// Для гостя и админа корзины нет — возвращаем null
function getCartKey() {
  return currentUser && currentUser.role === 'user' ? `cart:${currentUser.id}` : null;
}

// Чтение корзины: массив вида [{ productId, quantity }]
function readCart() {
  const key = getCartKey();
  if (!key) return [];

  try {
    const raw = JSON.parse(localStorage.getItem(key) || '[]');
    if (!Array.isArray(raw)) return [];

    // Отбрасываем всё, что не похоже на позицию корзины (данные могли быть повреждены)
    return raw
      .filter((item) => item && typeof item.productId === 'string' &&
        Number.isInteger(item.quantity) && item.quantity >= 1)
      .map((item) => ({ productId: item.productId, quantity: Math.min(item.quantity, 10) }))
      .slice(0, 20);
  } catch (err) {
    return [];
  }
}

// Сохранение корзины и обновление счётчика в шапке
function writeCart(items) {
  const key = getCartKey();
  if (!key) return;

  try {
    localStorage.setItem(key, JSON.stringify(items));
  } catch (err) {
    // хранилище недоступно — корзина просто не сохранится между визитами
  }
  updateCartBadge();
}

function isInCart(productId) {
  return readCart().some((item) => item.productId === productId);
}

// Кнопка корзины в шапке: видна только покупателю, на ней — число предметов
function updateCartBadge() {
  const button = document.getElementById('cartBtn');
  const badge = document.getElementById('cartCount');
  const isBuyer = Boolean(getCartKey());

  button.classList.toggle('hidden', !isBuyer);

  const count = readCart().reduce((sum, item) => sum + item.quantity, 0);
  badge.textContent = count;
  badge.classList.toggle('hidden', count === 0);
  badge.classList.toggle('flex', count > 0);
}

const CART_MAX_LINES = 20;     // максимум разных товаров
const CART_MAX_QUANTITY = 10;  // максимум штук одного товара

// Позиции корзины вместе с данными товаров.
// Товары, которых больше нет в магазине, из корзины убираются
function getCartLines() {
  const cart = readCart();
  const lines = [];

  cart.forEach((item) => {
    const product = getCachedProduct(item.productId);
    if (product) {
      lines.push({ product, quantity: item.quantity });
    }
  });

  if (lines.length !== cart.length) {
    writeCart(lines.map((line) => ({ productId: line.product._id, quantity: line.quantity })));
  }
  return lines;
}

// Добавление товара в корзину (кнопка на карточке)
function addToCart(productId) {
  if (!getCartKey()) {
    return showToast('Войдите в аккаунт покупателя, чтобы пользоваться корзиной', 'warning');
  }

  const product = products.find((item) => item._id === productId);
  if (!product || product.quantity < 1) {
    return showToast('Товара нет в наличии', 'warning');
  }

  const cart = readCart();
  const existing = cart.find((item) => item.productId === productId);
  const limit = Math.min(product.quantity, CART_MAX_QUANTITY);

  if (existing) {
    if (existing.quantity >= limit) {
      return showToast(`Больше ${limit} шт. этого товара добавить нельзя`, 'warning');
    }
    existing.quantity += 1;
  } else {
    if (cart.length >= CART_MAX_LINES) {
      return showToast(`В корзине может быть не больше ${CART_MAX_LINES} разных товаров`, 'warning');
    }
    cart.push({ productId, quantity: 1 });
  }

  writeCart(cart);
  renderProducts(); // значок на карточке сменится на галочку
  showToast(`«${product.title}» добавлен в корзину`, 'success');
}

cardActions.cart = addToCart;

// Отрисовка содержимого окна корзины
function renderCart() {
  const list = document.getElementById('cartList');
  const footer = document.getElementById('cartFooter');
  const lines = getCartLines();

  if (lines.length === 0) {
    list.innerHTML = '<p class="text-gray-500 text-center py-6">Корзина пуста</p>';
    footer.classList.add('hidden');
    return;
  }

  let total = 0;
  let count = 0;
  let hasProblems = false; // есть ли позиции, которых не хватает на складе

  list.innerHTML = lines.map(({ product, quantity }) => {
    const id = escapeHtml(product._id);
    const lineTotal = product.price * quantity;
    const notEnough = quantity > product.quantity;

    total += lineTotal;
    count += quantity;
    if (notEnough) hasProblems = true;

    const image = product.imageUrl
      ? `<img src="${escapeHtml(product.imageUrl)}" alt="" class="w-full h-full object-contain" onerror="this.remove()">`
      : '<i class="fa-solid fa-image text-gray-600"></i>';

    const stockNote = notEnough
      ? `<span class="text-red-400">в наличии только ${product.quantity} шт.</span>`
      : `${formatPrice(product.price)} ₽ за штуку`;

    return `
      <div class="flex flex-wrap items-center gap-3 bg-gray-800 rounded-lg p-3">
        <div class="w-12 h-12 shrink-0 rounded bg-gray-900 flex items-center justify-center overflow-hidden">
          ${image}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium truncate">${escapeHtml(product.title)}</p>
          <p class="text-xs text-gray-400">${stockNote}</p>
        </div>
        <div class="shrink-0 flex items-center gap-1">
          <button type="button" data-cart-dec="${id}" aria-label="Уменьшить количество"
                  class="w-8 h-8 rounded bg-gray-900 hover:bg-gray-700">−</button>
          <span class="w-8 text-center font-semibold">${quantity}</span>
          <button type="button" data-cart-inc="${id}" aria-label="Увеличить количество"
                  class="w-8 h-8 rounded bg-gray-900 hover:bg-gray-700">+</button>
        </div>
        <p class="shrink-0 w-28 text-right font-semibold text-yellow-500">${formatPrice(lineTotal)} ₽</p>
        <button type="button" data-cart-remove="${id}" title="Убрать" aria-label="Убрать из корзины"
                class="shrink-0 w-8 h-8 rounded bg-gray-900 text-red-400 hover:bg-gray-700">✕</button>
      </div>`;
  }).join('');

  footer.classList.remove('hidden');
  document.getElementById('cartItemsCount').textContent = count;
  document.getElementById('cartTotal').textContent = formatPrice(total);

  // Подсказка под суммой и доступность кнопки оформления
  const note = document.getElementById('cartBalanceNote');
  const checkoutBtn = document.getElementById('cartCheckoutBtn');
  const notEnoughMoney = currentUser.balance < total;

  if (hasProblems) {
    note.textContent = 'Уменьшите количество товаров, которых не хватает на складе';
    note.className = 'mt-1 text-xs text-right text-red-400';
  } else if (notEnoughMoney) {
    note.textContent = `Не хватает ${formatPrice(total - currentUser.balance)} ₽. Пополните баланс`;
    note.className = 'mt-1 text-xs text-right text-red-400';
  } else {
    note.textContent = `После покупки на балансе останется ${formatPrice(currentUser.balance - total)} ₽`;
    note.className = 'mt-1 text-xs text-right text-gray-500';
  }

  const blocked = hasProblems || notEnoughMoney;
  checkoutBtn.disabled = blocked;
  checkoutBtn.classList.toggle('opacity-50', blocked);
  checkoutBtn.classList.toggle('cursor-not-allowed', blocked);
}

// Открытие корзины
document.getElementById('cartBtn').addEventListener('click', async () => {
  // В корзине могут лежать товары с других страниц каталога.
  // Запрашиваем их свежие данные (цены и остатки) по списку id
  try {
    await refreshProductsByIds(readCart().map((item) => item.productId));
  } catch (err) {
    return showToast(err.message, 'error');
  }

  renderCart();
  openModal('cartModal');
});

// Кнопки −, + и ✕ в списке корзины (делегирование)
document.getElementById('cartList').addEventListener('click', (event) => {
  const button = event.target.closest('[data-cart-inc], [data-cart-dec], [data-cart-remove]');
  if (!button) return;

  let cart = readCart();
  const productId = button.dataset.cartInc || button.dataset.cartDec || button.dataset.cartRemove;
  const item = cart.find((entry) => entry.productId === productId);
  if (!item) return;

  if (button.dataset.cartInc) {
    const product = getCachedProduct(productId);
    const limit = Math.min(product ? product.quantity : 0, CART_MAX_QUANTITY);
    if (item.quantity >= limit) {
      return showToast(`Больше ${limit} шт. этого товара добавить нельзя`, 'warning');
    }
    item.quantity += 1;
  } else if (button.dataset.cartDec && item.quantity > 1) {
    item.quantity -= 1;
  } else {
    // "✕" или уменьшение с одной штуки — убираем позицию целиком
    cart = cart.filter((entry) => entry.productId !== productId);
  }

  writeCart(cart);
  renderCart();
  renderProducts();
});

// Очистка корзины
document.getElementById('cartClearBtn').addEventListener('click', async () => {
  const confirmed = await confirmDialog({
    title: 'Очистка корзины',
    message: 'Убрать из корзины все товары?',
    confirmText: 'Очистить',
    danger: true
  });
  if (!confirmed) return;

  writeCart([]);
  renderCart();
  renderProducts();
});

// Оформление покупки
document.getElementById('cartCheckoutBtn').addEventListener('click', async (event) => {
  const button = event.currentTarget;
  const lines = getCartLines();
  if (lines.length === 0) return;

  const total = lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0);
  const count = lines.reduce((sum, line) => sum + line.quantity, 0);

  const confirmed = await confirmDialog({
    title: 'Оформление покупки',
    message: `Купить предметов: ${count} на сумму ${formatPrice(total)} ₽?`,
    confirmText: 'Купить'
  });
  if (!confirmed) return;

  button.disabled = true;
  try {
    const data = await apiRequest('/products/cart/checkout', {
      method: 'POST',
      body: {
        items: lines.map((line) => ({ productId: line.product._id, quantity: line.quantity }))
      }
    });

    currentUser.balance = data.balance;
    writeCart([]);
    updateUI();
    closeModal('cartModal');
    playSuccessSound();
    showToast(
      `${data.message} на сумму ${formatPrice(data.total)} ₽. Остаток на балансе: ${formatPrice(data.balance)} ₽`,
      'success',
      5000
    );

    // Обновляем остатки на витрине и, если открыт кабинет, его содержимое
    await loadProducts();
    if (!document.getElementById('profileView').classList.contains('hidden')) {
      loadProfilePage();
    }
  } catch (err) {
    showToast(err.message, 'error', 5000);
    // Остатки могли измениться — перезагружаем каталог, обновляем товары корзины и перерисовываем её
    await loadProducts();
    try {
      await refreshProductsByIds(readCart().map((item) => item.productId));
    } catch (refreshErr) {
      // не удалось обновить — покажем корзину по прежним данным
    }
    renderCart();
  } finally {
    button.disabled = false;
  }
});
