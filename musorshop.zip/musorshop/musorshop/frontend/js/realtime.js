// realtime.js
// События в реальном времени: постоянное соединение с сервером и лента последних событий

// ==================== СОЕДИНЕНИЕ ====================

let eventSource = null; // текущее соединение с сервером

// Обработчики событий сервера: имя события → функция.
// Другие файлы могут добавлять сюда свои обработчики (например, уведомления)
const realtimeHandlers = {};
const REALTIME_EVENTS = ['feed', 'feed:new', 'notification'];

// Открывает соединение. Вызывается при загрузке страницы, а также после входа и выхода:
// сервер определяет пользователя по cookie в момент подключения, поэтому при смене
// пользователя соединение нужно открыть заново
function connectRealtime() {
  if (eventSource) {
    eventSource.close();
    eventSource = null;
  }
  if (typeof EventSource === 'undefined') return; // очень старый браузер — работаем без ленты

  // EventSource — встроенный в браузер клиент Server-Sent Events.
  // При обрыве связи он сам переподключается через несколько секунд
  eventSource = new EventSource(`${API_URL}/events`);

  REALTIME_EVENTS.forEach((name) => {
    eventSource.addEventListener(name, (event) => {
      const handler = realtimeHandlers[name];
      if (!handler) return;
      try {
        handler(JSON.parse(event.data));
      } catch (err) {
        // повреждённое сообщение пропускаем
      }
    });
  });
}

// ==================== ЛЕНТА СОБЫТИЙ ====================

const FEED_LIMIT = 20; // сколько событий держим в ленте

// Откуда взялся предмет: значок и подпись для подсказки
const FEED_SOURCES = {
  shop:     { icon: 'fa-cart-shopping', label: 'Покупка в магазине' },
  case:     { icon: 'fa-box-open',      label: 'Выпало из кейса' },
  market:   { icon: 'fa-right-left',    label: 'Покупка на площадке' },
  contract: { icon: 'fa-arrows-rotate', label: 'Контракт обмена' }
};

// HTML одного события ленты
function createFeedItem(item) {
  const rarity = getRarity(item);
  const source = FEED_SOURCES[item.source] || FEED_SOURCES.shop;

  return `
    <div class="feed-item shrink-0 w-52 px-3 py-2 rounded-lg bg-gray-900 border border-gray-800 border-l-4 transition-all duration-500"
         style="border-left-color:${rarity.color}" title="${source.label}">
      <p class="text-xs font-medium truncate">${escapeHtml(item.title)}</p>
      <p class="text-[11px] text-gray-400 truncate">
        <i class="fa-solid ${source.icon} mr-1"></i>${escapeHtml(item.user)} · ${formatPrice(item.price)} ₽
      </p>
    </div>`;
}

// Первичное заполнение: сервер присылает последние события сразу после подключения
realtimeHandlers.feed = (items) => {
  const track = document.getElementById('liveFeedTrack');
  track.innerHTML = items.length > 0
    ? items.slice(0, FEED_LIMIT).map(createFeedItem).join('')
    : '<p class="text-xs text-gray-500 py-2">Событий пока нет: первая покупка появится здесь</p>';
};

// Новое событие: вставляем в начало ленты с плавным появлением
realtimeHandlers['feed:new'] = (item) => {
  const track = document.getElementById('liveFeedTrack');

  // Убираем заглушку "событий пока нет"
  if (!track.querySelector('.feed-item')) track.innerHTML = '';

  track.insertAdjacentHTML('afterbegin', createFeedItem(item));
  const element = track.firstElementChild;

  // Стартовое состояние (прозрачный и сжатый), затем возвращаем обычное — получается анимация
  element.classList.add('opacity-0', '-translate-y-2');
  requestAnimationFrame(() => {
    requestAnimationFrame(() => element.classList.remove('opacity-0', '-translate-y-2'));
  });

  // Лишние старые события удаляем
  const items = track.querySelectorAll('.feed-item');
  for (let i = FEED_LIMIT; i < items.length; i++) {
    items[i].remove();
  }
};

// Подключаемся сразу при загрузке страницы
connectRealtime();
