// Автоматические тесты API MusorShop.
// Запуск из папки backend: node --test tests/api.test.js
//
// Тесты работают с ОТДЕЛЬНОЙ базой musorshop_test и не трогают основную.

// Эти переменные задаём ДО подключения сервера: dotenv не перезаписывает уже заданные
process.env.NODE_ENV = 'test';
process.env.MONGO_URI = 'mongodb://127.0.0.1:27017/musorshop_test';

const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const app = require('../server');
const User = require('../models/User');
const Product = require('../models/Product');
const Purchase = require('../models/Purchase');
const Transaction = require('../models/Transaction');

let server;
let baseUrl;

// Общие данные, которые тесты передают друг другу (токены, идентификаторы)
const state = {};

// ---------- Вспомогательные функции ----------

// Запрос к API. Возвращает { status, body }
async function api(method, path, { token, body } = {}) {
  const headers = { 'X-Requested-With': 'test' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(baseUrl + path, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined
  });

  let data = null;
  try {
    data = await response.json();
  } catch (err) {
    // ответ без JSON
  }
  return { status: response.status, body: data };
}

// Регистрация и вход нового покупателя. Возвращает токен
async function registerAndLogin(email, password = 'secret123') {
  await api('POST', '/api/auth/register', { body: { email, password } });
  const login = await api('POST', '/api/auth/login', { body: { email, password } });
  return login.body.token;
}

// Данные текущего пользователя (id, баланс, роль)
async function getMe(token) {
  return (await api('GET', '/api/auth/me', { token })).body;
}

// Создание товара от имени администратора. Возвращает id
async function createProduct(data) {
  const res = await api('POST', '/api/products', {
    token: state.adminToken,
    body: { description: '', imageUrl: '', ...data }
  });
  assert.equal(res.status, 201);
  return res.body._id;
}

// ---------- Подготовка и завершение ----------

before(async () => {
  await mongoose.connect(process.env.MONGO_URI);

  // Страховка: очищать разрешаем только тестовую базу
  if (!mongoose.connection.name.endsWith('_test')) {
    throw new Error('Тесты можно запускать только на тестовой базе');
  }
  await mongoose.connection.dropDatabase();

  // После очистки базы заново создаём индексы (в том числе уникальные)
  await Promise.all(Object.values(mongoose.models).map((model) => model.createIndexes()));

  // Поднимаем сервер на любом свободном порту
  server = app.listen(0);
  await new Promise((resolve) => server.once('listening', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;

  // Администратора создаём напрямую в базе — через API это невозможно
  await User.create({
    email: 'admin@test.ru',
    password: await bcrypt.hash('adminpass', 10),
    role: 'admin'
  });
  const login = await api('POST', '/api/auth/login', {
    body: { email: 'admin@test.ru', password: 'adminpass' }
  });
  state.adminToken = login.body.token;
});

after(async () => {
  if (server.closeAllConnections) server.closeAllConnections();
  await new Promise((resolve) => server.close(resolve));
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();
});

// ==================== АВТОРИЗАЦИЯ ====================

describe('Авторизация', () => {
  it('регистрация создаёт покупателя со стартовым балансом; роль и баланс из запроса игнорируются', async () => {
    const res = await api('POST', '/api/auth/register', {
      body: { email: 'buyer@test.ru', password: 'secret123', role: 'admin', balance: 999999999 }
    });
    assert.equal(res.status, 201);

    const login = await api('POST', '/api/auth/login', {
      body: { email: 'buyer@test.ru', password: 'secret123' }
    });
    assert.equal(login.status, 200);
    state.buyerToken = login.body.token;

    const me = await getMe(state.buyerToken);
    assert.equal(me.role, 'user');
    assert.equal(me.balance, 100000);
    state.buyerId = me.id;
  });

  it('повторная регистрация с тем же email отклоняется', async () => {
    const res = await api('POST', '/api/auth/register', {
      body: { email: 'buyer@test.ru', password: 'another123' }
    });
    assert.equal(res.status, 400);
  });

  it('некорректный email и слишком короткий пароль отклоняются', async () => {
    const badEmail = await api('POST', '/api/auth/register', {
      body: { email: 'not-an-email', password: 'secret123' }
    });
    assert.equal(badEmail.status, 400);

    const shortPassword = await api('POST', '/api/auth/register', {
      body: { email: 'short@test.ru', password: '123' }
    });
    assert.equal(shortPassword.status, 400);
  });

  it('вход с неверным паролем и попытка NoSQL-инъекции отклоняются', async () => {
    const wrong = await api('POST', '/api/auth/login', {
      body: { email: 'buyer@test.ru', password: 'wrong-password' }
    });
    assert.equal(wrong.status, 400);

    // Вместо строк передаём объекты с оператором MongoDB
    const injection = await api('POST', '/api/auth/login', {
      body: { email: { $gt: '' }, password: { $gt: '' } }
    });
    assert.equal(injection.status, 400);
    assert.equal(injection.body.token, undefined);
  });

  it('профиль недоступен без токена, а с токеном не содержит пароль', async () => {
    const guest = await api('GET', '/api/auth/me');
    assert.equal(guest.status, 401);

    const me = await getMe(state.buyerToken);
    assert.equal(me.email, 'buyer@test.ru');
    assert.equal(me.password, undefined);
  });

  it('смена пароля завершает старые сессии и выдаёт новый токен', async () => {
    const oldToken = await registerAndLogin('password@test.ru', 'oldpass1');

    const change = await api('PUT', '/api/auth/change-password', {
      token: oldToken,
      body: { oldPassword: 'oldpass1', newPassword: 'newpass2' }
    });
    assert.equal(change.status, 200);
    assert.ok(change.body.token);

    const withOld = await api('GET', '/api/auth/me', { token: oldToken });
    assert.equal(withOld.status, 401);

    const withNew = await api('GET', '/api/auth/me', { token: change.body.token });
    assert.equal(withNew.status, 200);
  });

  it('пополнение сверх лимита и на нецелую сумму отклоняется', async () => {
    const tooMuch = await api('POST', '/api/auth/deposit', {
      token: state.buyerToken,
      body: { amount: 1000001 }
    });
    assert.equal(tooMuch.status, 400);

    const fractional = await api('POST', '/api/auth/deposit', {
      token: state.buyerToken,
      body: { amount: 10.5 }
    });
    assert.equal(fractional.status, 400);
  });
});

// ==================== ТОВАРЫ ====================

describe('Товары', () => {
  it('гость видит список товаров', async () => {
    const res = await api('GET', '/api/products');
    assert.equal(res.status, 200);
    assert.ok(Array.isArray(res.body.items));
    assert.equal(typeof res.body.total, 'number');
  });

  it('покупатель не может создать товар, администратор может', async () => {
    const data = { title: 'Тестовый скин', price: 1000, quantity: 2 };

    const byBuyer = await api('POST', '/api/products', { token: state.buyerToken, body: data });
    assert.equal(byBuyer.status, 403);

    const byGuest = await api('POST', '/api/products', { body: data });
    assert.equal(byGuest.status, 401);

    state.productId = await createProduct(data);
  });

  it('категория, качество и StatTrak сохраняются; неизвестные значения отклоняются', async () => {
    const id = await createProduct({
      title: 'Скин с характеристиками', price: 10, quantity: 1,
      category: 'rifle', wear: 'ft', statTrak: true
    });
    const product = await Product.findById(id);
    assert.equal(product.category, 'rifle');
    assert.equal(product.wear, 'ft');
    assert.equal(product.statTrak, true);

    const badWear = await api('POST', '/api/products', {
      token: state.adminToken,
      body: { title: 'Плохое качество', price: 1, quantity: 1, wear: 'broken' }
    });
    assert.equal(badWear.status, 400);
  });

  it('товар с отрицательной ценой отклоняется', async () => {
    const res = await api('POST', '/api/products', {
      token: state.adminToken,
      body: { title: 'Плохой товар', price: -5, quantity: 1 }
    });
    assert.equal(res.status, 400);
  });
});

// ==================== ПОКУПКА И ПРОДАЖА ====================

describe('Покупка и продажа', () => {
  it('покупка списывает деньги, уменьшает остаток и попадает в историю', async () => {
    const res = await api('POST', `/api/products/${state.productId}/buy`, { token: state.buyerToken });
    assert.equal(res.status, 200);
    assert.equal(res.body.balance, 99000);
    state.purchaseId = res.body.purchase._id;

    const product = await Product.findById(state.productId);
    assert.equal(product.quantity, 1);

    const transaction = await Transaction.findOne({ userId: state.buyerId, type: 'purchase' });
    assert.equal(transaction.amount, -1000);
    assert.equal(transaction.balanceAfter, 99000);
  });

  it('администратор не может покупать', async () => {
    const res = await api('POST', `/api/products/${state.productId}/buy`, { token: state.adminToken });
    assert.equal(res.status, 403);
  });

  it('товар дороже баланса купить нельзя, остаток при этом не меняется', async () => {
    const expensiveId = await createProduct({ title: 'Дорогой скин', price: 500000, quantity: 1 });

    const res = await api('POST', `/api/products/${expensiveId}/buy`, { token: state.buyerToken });
    assert.equal(res.status, 400);

    const product = await Product.findById(expensiveId);
    assert.equal(product.quantity, 1);
  });

  it('закончившийся товар купить нельзя', async () => {
    const emptyId = await createProduct({ title: 'Нет в наличии', price: 10, quantity: 0 });

    const res = await api('POST', `/api/products/${emptyId}/buy`, { token: state.buyerToken });
    assert.equal(res.status, 400);
  });

  it('продажа возвращает 80% и предмет на витрину; повторная продажа невозможна', async () => {
    const res = await api('POST', `/api/products/sell/${state.purchaseId}`, { token: state.buyerToken });
    assert.equal(res.status, 200);
    assert.equal(res.body.refund, 800);
    assert.equal(res.body.balance, 99800);

    const product = await Product.findById(state.productId);
    assert.equal(product.quantity, 2);

    const again = await api('POST', `/api/products/sell/${state.purchaseId}`, { token: state.buyerToken });
    assert.equal(again.status, 400);
  });

  it('чужую покупку продать нельзя', async () => {
    const buy = await api('POST', `/api/products/${state.productId}/buy`, { token: state.buyerToken });
    assert.equal(buy.status, 200);

    state.strangerToken = await registerAndLogin('stranger@test.ru');
    state.strangerId = (await getMe(state.strangerToken)).id;

    const res = await api('POST', `/api/products/sell/${buy.body.purchase._id}`, {
      token: state.strangerToken
    });
    assert.equal(res.status, 400);

    const purchase = await Purchase.findById(buy.body.purchase._id);
    assert.equal(purchase.status, 'active');
  });
});

// ==================== КОРЗИНА ====================

describe('Корзина', () => {
  it('оформление работает по принципу «всё или ничего»', async () => {
    state.cartA = await createProduct({ title: 'Корзина А', price: 100, quantity: 5 });
    state.cartB = await createProduct({ title: 'Корзина Б', price: 100, quantity: 1 });

    const before = (await getMe(state.buyerToken)).balance;

    // Второго товара не хватает — заказ должен быть отклонён целиком
    const failed = await api('POST', '/api/products/cart/checkout', {
      token: state.buyerToken,
      body: { items: [{ productId: state.cartA, quantity: 2 }, { productId: state.cartB, quantity: 3 }] }
    });
    assert.equal(failed.status, 400);
    assert.equal((await Product.findById(state.cartA)).quantity, 5);
    assert.equal((await getMe(state.buyerToken)).balance, before);

    // Корректный заказ проходит
    const ok = await api('POST', '/api/products/cart/checkout', {
      token: state.buyerToken,
      body: { items: [{ productId: state.cartA, quantity: 2 }, { productId: state.cartB, quantity: 1 }] }
    });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.count, 3);
    assert.equal(ok.body.balance, before - 300);
    assert.equal((await Product.findById(state.cartA)).quantity, 3);
  });

  it('пустая корзина и корзина с дубликатами отклоняются', async () => {
    const empty = await api('POST', '/api/products/cart/checkout', {
      token: state.buyerToken,
      body: { items: [] }
    });
    assert.equal(empty.status, 400);

    const duplicate = await api('POST', '/api/products/cart/checkout', {
      token: state.buyerToken,
      body: { items: [{ productId: state.cartA, quantity: 1 }, { productId: state.cartA, quantity: 1 }] }
    });
    assert.equal(duplicate.status, 400);
  });
});

// ==================== ОТЗЫВЫ ====================

describe('Отзывы', () => {
  it('оставить отзыв может только покупатель товара', async () => {
    // stranger@test.ru этот товар не покупал
    const res = await api('POST', `/api/products/${state.productId}/review`, {
      token: state.strangerToken,
      body: { rating: 5, comment: 'Не покупал, но хвалю' }
    });
    assert.equal(res.status, 403);

    const permission = await api('GET', `/api/products/${state.productId}/can-review`, {
      token: state.buyerToken
    });
    assert.equal(permission.body.canReview, true);
  });
  it('на товар можно оставить только один отзыв', async () => {
    const first = await api('POST', `/api/products/${state.productId}/review`, {
      token: state.buyerToken,
      body: { rating: 4, comment: 'Хороший скин' }
    });
    assert.equal(first.status, 201);

    const second = await api('POST', `/api/products/${state.productId}/review`, {
      token: state.buyerToken,
      body: { rating: 5 }
    });
    assert.equal(second.status, 400);

    const list = await api('GET', `/api/products/${state.productId}/reviews`);
    assert.equal(list.body.count, 1);
    assert.equal(list.body.average, 4);
    state.reviewId = list.body.reviews[0].id;
    // Полный email автора наружу не отдаётся
    assert.notEqual(list.body.reviews[0].userEmail, 'buyer@test.ru');
  });

  it('чужой отзыв удалить нельзя; правка администратора помечается', async () => {
    const byStranger = await api('DELETE', `/api/products/reviews/${state.reviewId}`, {
      token: state.strangerToken
    });
    assert.equal(byStranger.status, 403);

    const byAdmin = await api('PUT', `/api/products/reviews/${state.reviewId}`, {
      token: state.adminToken,
      body: { rating: 3, comment: 'Исправлено' }
    });
    assert.equal(byAdmin.status, 200);

    const list = await api('GET', `/api/products/${state.productId}/reviews`);
    assert.equal(list.body.reviews[0].editedByAdmin, true);
    assert.equal(list.body.reviews[0].rating, 3);
  });
});

// ==================== ПРОМОКОДЫ ====================

describe('Промокоды', () => {
  it('фиксированный промокод активируется один раз и соблюдает общий лимит', async () => {
    const create = await api('POST', '/api/promo', {
      token: state.adminToken,
      body: { code: 'fix100', type: 'fixed', amount: 100, maxUses: 1 }
    });
    assert.equal(create.status, 201);

    const before = (await getMe(state.buyerToken)).balance;

    const first = await api('POST', '/api/promo/redeem', { token: state.buyerToken, body: { code: 'FIX100' } });
    assert.equal(first.status, 200);
    assert.equal(first.body.balance, before + 100);

    const again = await api('POST', '/api/promo/redeem', { token: state.buyerToken, body: { code: 'FIX100' } });
    assert.equal(again.status, 400);

    // Лимит в одну активацию исчерпан — другому пользователю код уже недоступен
    const other = await api('POST', '/api/promo/redeem', { token: state.strangerToken, body: { code: 'FIX100' } });
    assert.equal(other.status, 400);
  });

  it('процентный промокод требует сумму пополнения и начисляет бонус', async () => {
    await api('POST', '/api/promo', {
      token: state.adminToken,
      body: { code: 'PCT10', type: 'percent', amount: 10, maxUses: 5 }
    });

    const before = (await getMe(state.buyerToken)).balance;

    // Без суммы код не срабатывает и не считается использованным
    const noAmount = await api('POST', '/api/promo/redeem', { token: state.buyerToken, body: { code: 'PCT10' } });
    assert.equal(noAmount.status, 400);

    const withAmount = await api('POST', '/api/promo/redeem', {
      token: state.buyerToken,
      body: { code: 'PCT10', depositAmount: 1000 }
    });
    assert.equal(withAmount.status, 200);
    assert.equal(withAmount.body.bonus, 100);
    assert.equal(withAmount.body.balance, before + 1100);
  });

  it('покупатель не может создавать промокоды', async () => {
    const res = await api('POST', '/api/promo', {
      token: state.buyerToken,
      body: { code: 'HACK', type: 'fixed', amount: 1000000, maxUses: 1 }
    });
    assert.equal(res.status, 403);
  });
});

// ==================== КЕЙСЫ ====================

describe('Кейсы', () => {
  it('открытие кейса списывает его цену и выдаёт предмет из набора', async () => {
    const create = await api('POST', '/api/cases', {
      token: state.adminToken,
      body: { title: 'Тестовый кейс', price: 50, imageUrl: '', items: [state.cartA, state.cartB] }
    });
    assert.equal(create.status, 201);

    const list = await api('GET', '/api/cases');
    const testCase = list.body[0];
    // Сумма шансов всех предметов равна 100%
    const totalChance = testCase.items.reduce((sum, item) => sum + item.chance, 0);
    assert.ok(Math.abs(totalChance - 100) < 0.05);

    const before = (await getMe(state.buyerToken)).balance;

    const open = await api('POST', `/api/cases/${testCase.id}/open`, { token: state.buyerToken });
    assert.equal(open.status, 200);
    assert.equal(open.body.balance, before - 50);
    assert.ok([state.cartA, state.cartB].includes(String(open.body.item.id)));

    const purchase = await Purchase.findOne({ userId: state.buyerId, source: 'case' });
    assert.equal(purchase.paid, 50);
  });

  it('администратор не может открывать кейсы', async () => {
    const list = await api('GET', '/api/cases');
    const res = await api('POST', `/api/cases/${list.body[0].id}/open`, { token: state.adminToken });
    assert.equal(res.status, 403);
  });
});

// ==================== АДМИНИСТРИРОВАНИЕ ====================

describe('Администрирование', () => {
  it('статистика и список пользователей закрыты для покупателя', async () => {
    const stats = await api('GET', '/api/products/admin/stats', { token: state.buyerToken });
    assert.equal(stats.status, 403);

    const users = await api('GET', '/api/users', { token: state.buyerToken });
    assert.equal(users.status, 403);

    const adminStats = await api('GET', '/api/products/admin/stats', { token: state.adminToken });
    assert.equal(adminStats.status, 200);
    assert.ok(adminStats.body.totalSales > 0);
  });

  it('корректировка не может увести баланс в минус и требует причину', async () => {
    const tooMuch = await api('POST', `/api/users/${state.strangerId}/balance`, {
      token: state.adminToken,
      body: { amount: -9000000, reason: 'Тест' }
    });
    assert.equal(tooMuch.status, 400);

    const noReason = await api('POST', `/api/users/${state.strangerId}/balance`, {
      token: state.adminToken,
      body: { amount: 500, reason: '' }
    });
    assert.equal(noReason.status, 400);

    const ok = await api('POST', `/api/users/${state.strangerId}/balance`, {
      token: state.adminToken,
      body: { amount: 500, reason: 'Тестовое начисление' }
    });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.balance, 100500);
  });

  it('блокировка мгновенно лишает доступа и запрещает вход', async () => {
    const block = await api('PUT', `/api/users/${state.strangerId}/block`, {
      token: state.adminToken,
      body: { blocked: true }
    });
    assert.equal(block.status, 200);

    // Токен ещё не истёк, но доступ уже закрыт
    const me = await api('GET', '/api/auth/me', { token: state.strangerToken });
    assert.equal(me.status, 401);

    const login = await api('POST', '/api/auth/login', {
      body: { email: 'stranger@test.ru', password: 'secret123' }
    });
    assert.equal(login.status, 403);
  });

  it('файл, выдающий себя за картинку, отклоняется', async () => {
    // Текст с расширением и типом PNG: проверка по содержимому должна его отсеять
    const form = new FormData();
    form.append('image', new Blob(['это не картинка, а обычный текст'], { type: 'image/png' }), 'fake.png');

    const response = await fetch(`${baseUrl}/api/upload/image`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${state.adminToken}` },
      body: form
    });
    assert.equal(response.status, 400);
  });
});

// ==================== COOKIE-СЕССИЯ И CSRF ====================

describe('Cookie-сессия и защита от CSRF', () => {
  let cookie;

  it('вход ставит httpOnly-cookie со строгим SameSite', async () => {
    await api('POST', '/api/auth/register', { body: { email: 'cookie@test.ru', password: 'secret123' } });

    const response = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'test' },
      body: JSON.stringify({ email: 'cookie@test.ru', password: 'secret123' })
    });
    assert.equal(response.status, 200);

    const setCookie = response.headers.get('set-cookie');
    assert.match(setCookie, /musorshop_token=/);
    assert.match(setCookie, /HttpOnly/i);
    assert.match(setCookie, /SameSite=Strict/i);

    cookie = setCookie.split(';')[0]; // "musorshop_token=..."
  });

  it('профиль доступен по одной только cookie', async () => {
    const response = await fetch(`${baseUrl}/api/auth/me`, { headers: { Cookie: cookie } });
    assert.equal(response.status, 200);
    assert.equal((await response.json()).email, 'cookie@test.ru');
  });

  it('изменяющий запрос с cookie, но без служебного заголовка отклоняется', async () => {
    const forged = await fetch(`${baseUrl}/api/auth/deposit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie },
      body: JSON.stringify({ amount: 1000 })
    });
    assert.equal(forged.status, 403);

    const genuine = await fetch(`${baseUrl}/api/auth/deposit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie, 'X-Requested-With': 'test' },
      body: JSON.stringify({ amount: 1000 })
    });
    assert.equal(genuine.status, 200);
  });

  it('выход удаляет cookie, сервер отдаёт страницу сайта', async () => {
    const logout = await fetch(`${baseUrl}/api/auth/logout`, {
      method: 'POST',
      headers: { Cookie: cookie, 'X-Requested-With': 'test' }
    });
    assert.equal(logout.status, 200);
    assert.match(logout.headers.get('set-cookie'), /musorshop_token=;/);

    const page = await fetch(`${baseUrl}/`);
    assert.equal(page.status, 200);
    assert.match(page.headers.get('content-type'), /text\/html/);
  });
});

// ==================== КАПЧА ====================

describe('Капча', () => {
  // В остальных группах капча отключена; здесь включаем её на время проверки
  before(() => { process.env.CAPTCHA_ENFORCE = '1'; });
  after(() => { delete process.env.CAPTCHA_ENFORCE; });

  it('регистрация и вход без кода с картинки отклоняются', async () => {
    const register = await api('POST', '/api/auth/register', {
      body: { email: 'bot@test.ru', password: 'secret123' }
    });
    assert.equal(register.status, 400);

    const login = await api('POST', '/api/auth/login', {
      body: { email: 'buyer@test.ru', password: 'secret123' }
    });
    assert.equal(login.status, 400);
    assert.equal(login.body.token, undefined);
  });

  it('неверный код отклоняется, верный принимается', async () => {
    const wrongCaptcha = (await api('GET', '/api/auth/captcha')).body;
    const wrong = await api('POST', '/api/auth/register', {
      body: { email: 'human@test.ru', password: 'secret123', captchaId: wrongCaptcha.id, captchaAnswer: '-----' }
    });
    assert.equal(wrong.status, 400);

    const captcha = (await api('GET', '/api/auth/captcha')).body;
    assert.match(captcha.svg, /^<svg/);
    const ok = await api('POST', '/api/auth/register', {
      // регистр букв не важен
      body: { email: 'human@test.ru', password: 'secret123', captchaId: captcha.id, captchaAnswer: captcha.answer.toUpperCase() }
    });
    assert.equal(ok.status, 201);
  });

  it('один и тот же код нельзя использовать дважды', async () => {
    const captcha = (await api('GET', '/api/auth/captcha')).body;
    const body = { email: 'human@test.ru', password: 'secret123', captchaId: captcha.id, captchaAnswer: captcha.answer };

    const first = await api('POST', '/api/auth/login', { body });
    assert.equal(first.status, 200);

    const second = await api('POST', '/api/auth/login', { body });
    assert.equal(second.status, 400);
  });
});

// ==================== КАТАЛОГ НА СЕРВЕРЕ ====================

describe('Каталог: поиск, фильтры, пагинация', () => {
  // Десять товаров с общим словом в названии, чтобы отделить их от остальных поиском
  before(async () => {
    for (let i = 1; i <= 10; i++) {
      await createProduct({
        title: `Каталогтест ${String(i).padStart(2, '0')}`,
        price: i * 100,
        quantity: i % 2,                 // у чётных остаток 0
        category: i <= 4 ? 'rifle' : 'pistol',
        statTrak: i === 1
      });
    }
  });

  it('пагинация: 8 товаров на странице, номер страницы ограничивается', async () => {
    const first = await api('GET', '/api/products?search=каталогтест');
    assert.equal(first.body.total, 10);
    assert.equal(first.body.pages, 2);
    assert.equal(first.body.items.length, 8);

    const second = await api('GET', '/api/products?search=каталогтест&page=2');
    assert.equal(second.body.items.length, 2);

    // Несуществующая страница заменяется последней
    const beyond = await api('GET', '/api/products?search=каталогтест&page=99');
    assert.equal(beyond.body.page, 2);
  });

  it('сортировка и фильтры выполняются на сервере', async () => {
    const byPrice = await api('GET', '/api/products?search=каталогтест&sort=price-desc');
    assert.equal(byPrice.body.items[0].price, 1000);

    const rifles = await api('GET', '/api/products?search=каталогтест&category=rifle');
    assert.equal(rifles.body.total, 4);

    const inStock = await api('GET', '/api/products?search=каталогтест&inStock=1');
    assert.equal(inStock.body.total, 5);

    const statTrak = await api('GET', '/api/products?search=каталогтест&statTrak=1');
    assert.equal(statTrak.body.total, 1);

    const range = await api('GET', '/api/products?search=каталогтест&minPrice=300&maxPrice=500');
    assert.equal(range.body.total, 3);
  });

  it('оператор MongoDB в параметре игнорируется, фильтр избранного учитывает пользователя', async () => {
    // Попытка передать вместо строки объект { $ne: 'rifle' }
    const injection = await api('GET', '/api/products?search=каталогтест&category[$ne]=rifle');
    assert.equal(injection.status, 200);
    assert.equal(injection.body.total, 10);

    const guest = await api('GET', '/api/products?wishlist=1');
    assert.equal(guest.body.total, 0);

    const target = (await api('GET', '/api/products?search=каталогтест')).body.items[0];
    await api('POST', `/api/products/wishlist/${target._id}`, { token: state.buyerToken });
    const buyer = await api('GET', '/api/products?wishlist=1', { token: state.buyerToken });
    assert.equal(buyer.body.total, 1);
    assert.equal(buyer.body.items[0]._id, target._id);
  });

  it('товары по списку id и краткий список для админа', async () => {
    const byIds = await api('GET', `/api/products/by-ids?ids=${state.cartA},${state.cartB},мусор`);
    assert.equal(byIds.status, 200);
    assert.equal(byIds.body.length, 2);

    const forBuyer = await api('GET', '/api/products/brief', { token: state.buyerToken });
    assert.equal(forBuyer.status, 403);

    const forAdmin = await api('GET', '/api/products/brief', { token: state.adminToken });
    assert.equal(forAdmin.status, 200);
    assert.ok(forAdmin.body.length >= 10);
  });
});

// ==================== ТОРГОВАЯ ПЛОЩАДКА ====================

describe('Торговая площадка', () => {
  let traderToken;   // второй покупатель
  let itemId;        // предмет продавца (buyer@test.ru)
  let itemValue;     // его стоимость в магазине
  let listingId;

  before(async () => {
    traderToken = await registerAndLogin('trader@test.ru');

    const purchases = (await api('GET', '/api/products/my-purchases', { token: state.buyerToken })).body;
    const item = purchases.find((purchase) => purchase.status === 'active');
    itemId = item._id;
    itemValue = item.price;
  });

  it('выставленный предмет нельзя продать магазину или выставить повторно', async () => {
    const create = await api('POST', '/api/market', {
      token: state.buyerToken,
      body: { purchaseId: itemId, price: 1000 }
    });
    assert.equal(create.status, 201);
    assert.equal(create.body.fee, 50);          // 5% от 1000
    assert.equal(create.body.sellerGets, 950);
    listingId = create.body.id;

    const sellToShop = await api('POST', `/api/products/sell/${itemId}`, { token: state.buyerToken });
    assert.equal(sellToShop.status, 400);

    const again = await api('POST', '/api/market', {
      token: state.buyerToken,
      body: { purchaseId: itemId, price: 500 }
    });
    assert.equal(again.status, 400);

    // Чужой предмет выставить нельзя
    const foreign = await api('POST', '/api/market', {
      token: traderToken,
      body: { purchaseId: itemId, price: 500 }
    });
    assert.equal(foreign.status, 400);
  });

  it('лот виден в списке; свой лот и лот для админа купить нельзя', async () => {
    const list = await api('GET', '/api/market', { token: state.buyerToken });
    const lot = list.body.items.find((item) => String(item.id) === String(listingId));
    assert.ok(lot);
    assert.equal(lot.isMine, true);
    assert.notEqual(lot.seller, 'buyer@test.ru'); // email продавца скрыт

    const own = await api('POST', `/api/market/${listingId}/buy`, { token: state.buyerToken });
    assert.equal(own.status, 400);

    const admin = await api('POST', `/api/market/${listingId}/buy`, { token: state.adminToken });
    assert.equal(admin.status, 403);
  });

  it('покупка лота: деньги продавцу за вычетом комиссии, стоимость предмета не меняется', async () => {
    const sellerBefore = (await getMe(state.buyerToken)).balance;
    const traderBefore = (await getMe(traderToken)).balance;

    const buy = await api('POST', `/api/market/${listingId}/buy`, { token: traderToken });
    assert.equal(buy.status, 200);
    assert.equal(buy.body.balance, traderBefore - 1000);
    assert.equal((await getMe(state.buyerToken)).balance, sellerBefore + 950);

    // У покупателя появился предмет с прежней стоимостью, а не с ценой лота
    const traderId = (await getMe(traderToken)).id;
    const received = await Purchase.findOne({ userId: traderId, source: 'market' });
    assert.equal(received.price, itemValue);
    assert.equal(received.paid, 1000);
    assert.equal(received.shopIncome, 50);

    // У продавца предмет отмечен как проданный на площадке
    const sold = await Purchase.findById(itemId);
    assert.equal(sold.status, 'traded');
    assert.equal(sold.soldFor, 950);

    // Второй раз лот купить нельзя
    const again = await api('POST', `/api/market/${listingId}/buy`, { token: traderToken });
    assert.equal(again.status, 400);
  });

  it('снять лот может только продавец; предмет возвращается в инвентарь', async () => {
    const traderId = (await getMe(traderToken)).id;
    const item = await Purchase.findOne({ userId: traderId, source: 'market' });

    const create = await api('POST', '/api/market', {
      token: traderToken,
      body: { purchaseId: String(item._id), price: 2000 }
    });
    assert.equal(create.status, 201);

    const byStranger = await api('DELETE', `/api/market/${create.body.id}`, { token: state.buyerToken });
    assert.equal(byStranger.status, 404);

    const byOwner = await api('DELETE', `/api/market/${create.body.id}`, { token: traderToken });
    assert.equal(byOwner.status, 200);
    assert.equal((await Purchase.findById(item._id)).status, 'active');
  });

  it('история цен содержит совершённую сделку', async () => {
    const sold = await Purchase.findById(itemId);
    const history = await api('GET', `/api/market/history/${sold.productId}`);
    assert.equal(history.status, 200);
    assert.equal(history.body.count, 1);
    assert.equal(history.body.deals[0].price, 1000);
    assert.equal(history.body.average, 1000);
  });
});

// ==================== КОНТРАКТ ОБМЕНА ====================

describe('Контракт обмена', () => {
  let inputIds;      // 10 предметов армейской редкости
  let cheapOutcome;  // подходящий результат
  let resultId;      // полученный предмет

  // Покупка десяти штук товара одним заказом; возвращает id записей инвентаря
  async function buyTen(productId) {
    const order = await api('POST', '/api/products/cart/checkout', {
      token: state.buyerToken,
      body: { items: [{ productId, quantity: 10 }] }
    });
    assert.equal(order.status, 200);

    const purchases = await Purchase.find({ userId: state.buyerId, productId, status: 'active' });
    return purchases.map((purchase) => String(purchase._id));
  }

  before(async () => {
    state.contractInput = await createProduct({ title: 'Контракт: вход', price: 100, quantity: 30, rarity: 'milspec' });
    // Сумма десяти входных предметов — 1000, порог стоимости результата — 1250
    cheapOutcome = await createProduct({ title: 'Контракт: подходящий результат', price: 1200, quantity: 0, rarity: 'restricted' });
    await createProduct({ title: 'Контракт: слишком дорогой результат', price: 5000, quantity: 0, rarity: 'restricted' });

    inputIds = await buyTen(state.contractInput);
  });

  it('нужно ровно 10 своих предметов', async () => {
    const nine = await api('POST', '/api/contract/preview', {
      token: state.buyerToken,
      body: { purchaseIds: inputIds.slice(0, 9) }
    });
    assert.equal(nine.status, 400);

    // Чужими предметами воспользоваться нельзя
    const traderToken = await registerAndLogin('contract@test.ru');
    const foreign = await api('POST', '/api/contract', { token: traderToken, body: { purchaseIds: inputIds } });
    assert.equal(foreign.status, 400);
  });

  it('слишком дорогой предмет в результаты не попадает', async () => {
    const preview = await api('POST', '/api/contract/preview', {
      token: state.buyerToken,
      body: { purchaseIds: inputIds }
    });
    assert.equal(preview.status, 200);
    assert.equal(preview.body.nextRarity, 'restricted');
    assert.equal(preview.body.totalValue, 1000);
    assert.equal(preview.body.outcomes.length, 1);
    assert.equal(String(preview.body.outcomes[0].id), cheapOutcome);
    assert.equal(preview.body.outcomes[0].chance, 100);
  });

  it('обмен забирает 10 предметов и выдаёт один; повторить его нельзя', async () => {
    const trade = await api('POST', '/api/contract', { token: state.buyerToken, body: { purchaseIds: inputIds } });
    assert.equal(trade.status, 200);
    assert.equal(String(trade.body.item.id), cheapOutcome);

    const used = await Purchase.countDocuments({ _id: { $in: inputIds }, status: 'contracted' });
    assert.equal(used, 10);

    const received = await Purchase.findOne({ userId: state.buyerId, source: 'contract' });
    assert.equal(received.price, 1200);
    assert.equal(received.paid, 0);
    resultId = String(received._id);

    const again = await api('POST', '/api/contract', { token: state.buyerToken, body: { purchaseIds: inputIds } });
    assert.equal(again.status, 400);
  });

  it('предметы разной редкости в один контракт не складываются', async () => {
    const moreIds = await buyTen(state.contractInput);
    // Девять армейских и один запрещённый (результат прошлого обмена)
    const mixed = [...moreIds.slice(0, 9), resultId];

    const res = await api('POST', '/api/contract/preview', { token: state.buyerToken, body: { purchaseIds: mixed } });
    assert.equal(res.status, 400);
  });
});

// ==================== УРОВНИ И ЕЖЕДНЕВНЫЙ БОНУС ====================

describe('Уровни и ежедневный бонус', () => {
  let token;
  let userId;

  before(async () => {
    token = await registerAndLogin('bonus@test.ru');
    userId = (await getMe(token)).id;
  });

  it('опыт начисляется за траты: 1 XP за 100 ₽', async () => {
    const before = await getMe(token);
    assert.equal(before.progress.level, 1);
    assert.equal(before.progress.xp, 0);

    const productId = await createProduct({ title: 'Товар для опыта', price: 2550, quantity: 1 });
    const buy = await api('POST', `/api/products/${productId}/buy`, { token });
    assert.equal(buy.status, 200);

    const after = await getMe(token);
    assert.equal(after.progress.xp, 25); // 2550 / 100 с округлением вниз
  });

  it('бонус выдаётся один раз за 24 часа', async () => {
    const before = await getMe(token);
    assert.equal(before.bonus.available, true);
    assert.equal(before.bonus.amount, 500);

    const claim = await api('POST', '/api/auth/bonus', { token });
    assert.equal(claim.status, 200);
    assert.equal(claim.body.amount, 500);
    assert.equal(claim.body.user.balance, before.balance + 500);
    assert.equal(claim.body.user.bonus.available, false);

    const again = await api('POST', '/api/auth/bonus', { token });
    assert.equal(again.status, 400);

    const admin = await api('POST', '/api/auth/bonus', { token: state.adminToken });
    assert.equal(admin.status, 403);
  });

  it('серия увеличивает бонус, а пропуск её обнуляет', async () => {
    // "Переводим часы": делаем вид, что прошлый бонус получен 25 часов назад
    await User.updateOne({ _id: userId }, { lastBonusAt: new Date(Date.now() - 25 * 60 * 60 * 1000) });

    const second = await api('POST', '/api/auth/bonus', { token });
    assert.equal(second.status, 200);
    assert.equal(second.body.streak, 2);
    assert.equal(second.body.amount, 550); // 500 + 10% за второй день серии

    // Пропуск больше 48 часов — серия начинается заново
    await User.updateOne({ _id: userId }, { lastBonusAt: new Date(Date.now() - 50 * 60 * 60 * 1000) });

    const afterGap = await api('POST', '/api/auth/bonus', { token });
    assert.equal(afterGap.body.streak, 1);
    assert.equal(afterGap.body.amount, 500);
  });
});

// ==================== СОБЫТИЯ В РЕАЛЬНОМ ВРЕМЕНИ ====================

describe('Лента событий (SSE)', () => {
  // Читает поток до появления нужного текста или до истечения времени
  async function readUntil(reader, text, timeoutMs = 3000) {
    const decoder = new TextDecoder();
    let received = '';

    const timeout = new Promise((resolve) => setTimeout(() => resolve('timeout'), timeoutMs));
    while (!received.includes(text)) {
      const chunk = await Promise.race([reader.read(), timeout]);
      if (chunk === 'timeout' || chunk.done) break;
      received += decoder.decode(chunk.value, { stream: true });
    }
    return received;
  }

  it('при подключении приходит лента, покупка мгновенно рассылается подключённым', async () => {
    const controller = new AbortController();
    const response = await fetch(`${baseUrl}/api/events`, { signal: controller.signal });
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type'), /text\/event-stream/);

    const reader = response.body.getReader();

    try {
      // Первое сообщение — последние события из базы
      const initial = await readUntil(reader, 'event: feed\n');
      assert.match(initial, /event: feed\n/);

      // Совершаем покупку и ждём её в потоке
      const productId = await createProduct({ title: 'Товар для ленты', price: 10, quantity: 1, rarity: 'covert' });
      const buy = await api('POST', `/api/products/${productId}/buy`, { token: state.buyerToken });
      assert.equal(buy.status, 200);

      const live = await readUntil(reader, 'Товар для ленты');
      assert.match(live, /event: feed:new/);
      assert.match(live, /Товар для ленты/);
      assert.match(live, /"rarity":"covert"/);
      // Полный email покупателя в ленту не попадает
      assert.doesNotMatch(live, /buyer@test\.ru/);
    } finally {
      controller.abort(); // закрываем соединение, иначе тест не завершится
    }
  });
});

// ==================== УВЕДОМЛЕНИЯ ====================

describe('Уведомления', () => {
  let sellerToken;
  let sellerId;
  let buyerToken;

  before(async () => {
    sellerToken = await registerAndLogin('notify-seller@test.ru');
    buyerToken = await registerAndLogin('notify-buyer@test.ru');
    sellerId = (await getMe(sellerToken)).id;
  });

  it('продавец получает уведомление о продаже лота, чужие уведомления не видны', async () => {
    const productId = await createProduct({ title: 'Товар для уведомления', price: 100, quantity: 1 });
    const buy = await api('POST', `/api/products/${productId}/buy`, { token: sellerToken });
    const listing = await api('POST', '/api/market', {
      token: sellerToken,
      body: { purchaseId: buy.body.purchase._id, price: 200 }
    });
    await api('POST', `/api/market/${listing.body.id}/buy`, { token: buyerToken });

    const seller = await api('GET', '/api/notifications', { token: sellerToken });
    assert.equal(seller.status, 200);
    assert.equal(seller.body.unread, 1);
    assert.equal(seller.body.items[0].type, 'market_sale');
    assert.match(seller.body.items[0].text, /Товар для уведомления/);

    // У покупателя уведомлений нет
    const buyer = await api('GET', '/api/notifications', { token: buyerToken });
    assert.equal(buyer.body.items.length, 0);

    const guest = await api('GET', '/api/notifications');
    assert.equal(guest.status, 401);
  });

  it('отметка о прочтении обнуляет счётчик', async () => {
    const read = await api('POST', '/api/notifications/read', { token: sellerToken });
    assert.equal(read.status, 200);

    const after = await api('GET', '/api/notifications', { token: sellerToken });
    assert.equal(after.body.unread, 0);
    assert.equal(after.body.items[0].read, true);
  });

  it('корректировка баланса мгновенно доставляется по открытому соединению', async () => {
    const controller = new AbortController();
    const response = await fetch(`${baseUrl}/api/events`, {
      headers: { Authorization: `Bearer ${sellerToken}` },
      signal: controller.signal
    });
    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    try {
      await api('POST', `/api/users/${sellerId}/balance`, {
        token: state.adminToken,
        body: { amount: 700, reason: 'Проверка уведомлений' }
      });

      // Читаем поток, пока не придёт уведомление (но не дольше трёх секунд)
      let received = '';
      const timeout = new Promise((resolve) => setTimeout(() => resolve('timeout'), 3000));
      while (!received.includes('event: notification')) {
        const chunk = await Promise.race([reader.read(), timeout]);
        if (chunk === 'timeout' || chunk.done) break;
        received += decoder.decode(chunk.value, { stream: true });
      }

      assert.match(received, /event: notification/);
      assert.match(received, /Проверка уведомлений/);
    } finally {
      controller.abort();
    }
  });

  it('появление товара в наличии уведомляет тех, у кого он в избранном', async () => {
    const productId = await createProduct({ title: 'Долгожданный товар', price: 100, quantity: 0 });
    await api('POST', `/api/products/wishlist/${productId}`, { token: buyerToken });

    // Администратор пополняет остаток
    const update = await api('PUT', `/api/products/${productId}`, {
      token: state.adminToken,
      body: { title: 'Долгожданный товар', description: '', price: 100, quantity: 3, imageUrl: '' }
    });
    assert.equal(update.status, 200);

    const list = await api('GET', '/api/notifications', { token: buyerToken });
    assert.equal(list.body.items[0].type, 'restock');
    assert.match(list.body.items[0].text, /Долгожданный товар/);
  });
});

// ==================== ЖУРНАЛ ДЕЙСТВИЙ АДМИНИСТРАТОРА ====================

describe('Журнал действий администратора', () => {
  it('действия администратора попадают в журнал с указанием исполнителя', async () => {
    const productId = await createProduct({ title: 'Товар для журнала', price: 10, quantity: 1 });

    const log = await api('GET', '/api/audit', { token: state.adminToken });
    assert.equal(log.status, 200);

    // Последняя запись — только что созданный товар
    const latest = log.body.items[0];
    assert.equal(latest.action, 'product.create');
    assert.equal(latest.category, 'product');
    assert.match(latest.target, /Товар для журнала/);
    assert.equal(latest.admin, 'admin@test.ru');

    // Удаление тоже фиксируется
    await api('DELETE', `/api/products/${productId}`, { token: state.adminToken });
    const afterDelete = await api('GET', '/api/audit', { token: state.adminToken });
    assert.equal(afterDelete.body.items[0].action, 'product.delete');
  });

  it('блокировка и корректировка баланса записываются в раздел пользователей', async () => {
    const token = await registerAndLogin('audited@test.ru');
    const userId = (await getMe(token)).id;

    await api('POST', `/api/users/${userId}/balance`, {
      token: state.adminToken,
      body: { amount: -300, reason: 'Проверка журнала' }
    });
    await api('PUT', `/api/users/${userId}/block`, { token: state.adminToken, body: { blocked: true } });

    const log = await api('GET', '/api/audit?category=user', { token: state.adminToken });
    assert.ok(log.body.items.every((item) => item.category === 'user'));
    assert.equal(log.body.items[0].action, 'user.block');
    assert.equal(log.body.items[0].target, 'audited@test.ru');
    assert.equal(log.body.items[1].action, 'user.balance');
    assert.match(log.body.items[1].target, /Проверка журнала/);
  });

  it('в журнале сохраняются значения «было» и «стало» и снимок объекта', async () => {
    const productId = await createProduct({ title: 'Товар с историей', price: 100, quantity: 5 });

    // Снимок при создании
    const created = (await api('GET', '/api/audit', { token: state.adminToken })).body.items[0];
    assert.equal(created.details.snapshot.title, 'Товар с историей');
    assert.equal(created.details.snapshot.price, 100);

    // Меняем цену и количество, название оставляем прежним
    await api('PUT', `/api/products/${productId}`, {
      token: state.adminToken,
      body: { title: 'Товар с историей', description: '', price: 250, quantity: 2, imageUrl: '' }
    });

    const updated = (await api('GET', '/api/audit', { token: state.adminToken })).body.items[0];
    assert.equal(updated.action, 'product.update');

    const changes = updated.details.changes;
    assert.deepEqual(changes.find((c) => c.field === 'price'), { field: 'price', before: 100, after: 250 });
    assert.deepEqual(changes.find((c) => c.field === 'quantity'), { field: 'quantity', before: 5, after: 2 });
    // Неизменённые поля в список не попадают
    assert.equal(changes.find((c) => c.field === 'title'), undefined);
  });

  it('журнал закрыт для покупателя и гостя', async () => {
    const buyer = await api('GET', '/api/audit', { token: state.buyerToken });
    assert.equal(buyer.status, 403);

    const guest = await api('GET', '/api/audit');
    assert.equal(guest.status, 401);
  });
});

// ==================== СЛУЖЕБНОЕ ====================

describe('Проверка работоспособности', () => {
  it('служебный адрес сообщает о состоянии сервера и базы', async () => {
    const res = await api('GET', '/api/health');
    assert.equal(res.status, 200);
    assert.equal(res.body.status, 'ok');
    assert.equal(res.body.database, 'connected');
  });
});

