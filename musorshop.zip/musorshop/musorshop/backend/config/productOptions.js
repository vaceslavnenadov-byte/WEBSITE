// Категории оружия
const CATEGORIES = {
  rifle:  'Винтовки',
  sniper: 'Снайперские винтовки',
  pistol: 'Пистолеты',
  smg:    'Пистолеты-пулемёты',
  heavy:  'Тяжёлое оружие',
  knife:  'Ножи',
  gloves: 'Перчатки',
  other:  'Другое'
};

// Качество (износ) скина — названия как в игре
const WEARS = {
  fn: 'Factory New',
  mw: 'Minimal Wear',
  ft: 'Field-Tested',
  ww: 'Well-Worn',
  bs: 'Battle-Scarred'
};

const CATEGORY_KEYS = Object.keys(CATEGORIES);
const WEAR_KEYS = Object.keys(WEARS);
const DEFAULT_CATEGORY = 'other';

module.exports = { CATEGORIES, WEARS, CATEGORY_KEYS, WEAR_KEYS, DEFAULT_CATEGORY };