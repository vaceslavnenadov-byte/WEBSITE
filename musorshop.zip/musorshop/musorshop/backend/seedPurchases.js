// Скрипт создания тестовых покупок с датами за последние 30 дней —
// чтобы график и статистика выглядели наполненными.
//
// Запуск из папки backend:
//   node seedPurchases.js           — создать тестовые покупки
//   node seedPurchases.js --clear   — удалить их вместе с демо-покупателями
require('dotenv').config();

const crypto = require('crypto');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Product = require('./models/Product');
const Purchase = require('./models/Purchase');

// Все тестовые покупки привязываются к этим демо-покупателям,
// поэтому их легко отличить от настоящих и удалить
const DEMO_EMAILS = [
  'demo1@musorshop.test',
  'demo2@musorshop.test',
  'demo3@musorshop.test',
  'demo4@musorshop.test'
];

const DAYS = 30;               // за сколько дней создаём покупки
const MAX_PER_DAY = 5;         // максимум покупок в день
const SOLD_SHARE = 0.25;       // доля покупок, проданных обратно
const MAX_DEMO_PRICE = 100000; // слишком дорогие товары не берём, чтобы не было гигантских пиков

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomItem(list) {
  return list[randomInt(0, list.length - 1)];
}

// Удаление демо-покупателей и всех их покупок
async function clearDemoData() {
  const demoUsers = await User.find({ email: { $in: DEMO_EMAILS } }).select('_id');
  const ids = demoUsers.map((user) => user._id);

  const purchases = await Purchase.deleteMany({ userId: { $in: ids } });
  const users = await User.deleteMany({ _id: { $in: ids } });
  return { purchases: purchases.deletedCount, users: users.deletedCount };
}

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB подключена');

    // Сначала всегда убираем старые тестовые данные, чтобы не было дублей
    const removed = await clearDemoData();
    if (removed.purchases > 0 || removed.users > 0) {
      console.log(`🧹 Удалено тестовых покупок: ${removed.purchases}, демо-покупателей: ${removed.users}`);
    }

    // Режим очистки: на этом заканчиваем
    if (process.argv.includes('--clear')) {
      console.log('✅ Тестовые данные очищены');
      return;
    }

    const allProducts = await Product.find();
    if (allProducts.length === 0) {
      console.log('ℹ️ В базе нет товаров. Сначала запусти node seed.js');
      return;
    }

    // Берём товары не дороже лимита; если таких нет — все
    const affordable = allProducts.filter((product) => product.price <= MAX_DEMO_PRICE);
    const pool = affordable.length > 0 ? affordable : allProducts;

    // Создаём демо-покупателей. Пароль случайный — войти под ними нельзя
    const users = [];
    for (const email of DEMO_EMAILS) {
      const hash = await bcrypt.hash(crypto.randomBytes(16).toString('hex'), 10);
      users.push(await User.create({ email, password: hash, role: 'user' }));
    }

    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);

    const purchases = [];

    for (let offset = 0; offset < DAYS; offset++) {
      // Границы суток: от полуночи до следующей полуночи (для сегодня — до текущего момента)
      const dayStart = new Date(todayStart);
      dayStart.setDate(todayStart.getDate() - offset);
      const dayEnd = Math.min(dayStart.getTime() + 24 * 60 * 60 * 1000, now.getTime());

      const count = randomInt(0, MAX_PER_DAY);

      for (let i = 0; i < count; i++) {
        const product = randomItem(pool);
        const purchasedAt = new Date(
          dayStart.getTime() + Math.random() * (dayEnd - dayStart.getTime())
        );

        const purchase = {
          userId: randomItem(users)._id,
          productId: product._id,
          productTitle: product.title,
          productImage: product.imageUrl,
          price: product.price,
          status: 'active',
          purchasedAt
        };

        // Часть покупок помечаем проданными обратно (в течение двух дней после покупки)
        if (Math.random() < SOLD_SHARE) {
          const soldTime = purchasedAt.getTime() + randomInt(1, 48) * 60 * 60 * 1000;
          purchase.status = 'sold';
          purchase.soldAt = new Date(Math.min(soldTime, now.getTime()));
        }

        purchases.push(purchase);
      }
    }

    await Purchase.insertMany(purchases);
    console.log(`✅ Создано тестовых покупок: ${purchases.length} (демо-покупателей: ${users.length})`);
    console.log('ℹ️ Удалить их: node seedPurchases.js --clear');
  } catch (err) {
    console.error('❌ Ошибка:', err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

main();