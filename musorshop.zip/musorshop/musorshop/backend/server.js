// Загружаем переменные из .env — это должно быть самой первой строкой
require('dotenv').config();

const path = require('path');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const promoRoutes = require('./routes/promo');
const transactionRoutes = require('./routes/transactions');
const userRoutes = require('./routes/users');
const uploadRoutes = require('./routes/upload');
const caseRoutes = require('./routes/cases');
const marketRoutes = require('./routes/market');
const contractRoutes = require('./routes/contract');
const eventRoutes = require('./routes/events');
const notificationRoutes = require('./routes/notifications');
const auditRoutes = require('./routes/audit');



const app = express();

// На хостинге приложение стоит за прокси-сервером, который принимает HTTPS.
// Эта настройка велит Express брать настоящий адрес посетителя и протокол из служебных
// заголовков прокси. Без неё ограничитель запросов считал бы всех посетителей одним
// адресом, а ссылки на загруженные картинки начинались бы с http вместо https.
// Включается переменной TRUST_PROXY=1 только там, где прокси действительно есть
if (process.env.TRUST_PROXY) {
  app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);
}
const PORT = process.env.PORT || 5000;

// Папка с сайтом: сервер сам отдаёт страницу, стили и скрипты
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

// Без этих переменных сервер работать не может — сразу сообщаем об этом
if (!process.env.MONGO_URI || !process.env.JWT_SECRET) {
  console.error('❌ В файле .env не заданы MONGO_URI или JWT_SECRET');
  process.exit(1);
}

// В боевом режиме не запускаемся со слабым секретом: им подписываются токены всех пользователей
if (process.env.NODE_ENV === 'production' && process.env.JWT_SECRET.length < 32) {
  console.error('❌ JWT_SECRET слишком короткий для боевого режима: нужно не меньше 32 символов');
  process.exit(1);
}

// ---------- Безопасность ----------

// Политика безопасности содержимого (CSP): перечисляет, откуда странице
// разрешено загружать скрипты, стили, шрифты, картинки и куда отправлять запросы.
// 'unsafe-inline' нужен из-за Tailwind CDN и встроенных скриптов в index.html
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com', 'https://cdn.jsdelivr.net'],
  scriptSrcAttr: ["'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://cdnjs.cloudflare.com'],
  fontSrc: ["'self'", 'https://cdnjs.cloudflare.com'],
  imgSrc: ["'self'", 'data:', 'http:', 'https:'], // картинки товаров могут быть с любых сайтов
  // Запросы — к своему серверу; jsdelivr нужен только инструментам разработчика
  // (они скачивают оттуда карту исходного кода Chart.js)
  connectSrc: ["'self'", 'https://cdn.jsdelivr.net'],
  objectSrc: ["'none'"],
  frameAncestors: ["'none'"],                      // сайт нельзя встроить в чужую страницу
  baseUri: ["'self'"],
  formAction: ["'self'"]
};

app.use(helmet({
  // Картинки из /uploads должны открываться и с других адресов
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: {
    useDefaults: false,
    directives: cspDirectives,
    // Режим наблюдения: браузер ничего не блокирует, а только сообщает в консоль
    // о нарушениях. После проверки меняется на false — и политика начинает действовать
    reportOnly: false
  }
}));

// CORS: сайт и API теперь на одном адресе, и CORS для них не нужен.
// Список разрешённых адресов оставлен для сторонних клиентов
const allowedOrigins = (process.env.CLIENT_ORIGINS || '')
  .split(',')
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(cors({ origin: allowedOrigins }));

// Учим Express читать JSON из тела запроса (не больше 100 КБ)
app.use(express.json({ limit: '100kb' }));

// Защита от CSRF. Браузер сам прикладывает cookie к запросам, поэтому изменяющие запросы
// обязаны нести служебный заголовок X-Requested-With. Наш сайт добавляет его всегда,
// а чужая страница подставить не может: браузер не даст ей отправить нестандартный
// заголовок на другой адрес без разрешения CORS.
// Запросы с токеном в заголовке Authorization (автотесты, сторонние клиенты) CSRF не подвержены
app.use('/api', (req, res, next) => {
  const safeMethod = ['GET', 'HEAD', 'OPTIONS'].includes(req.method);
  const hasBearer = (req.headers.authorization || '').startsWith('Bearer ');

  if (safeMethod || hasBearer || req.headers['x-requested-with']) {
    return next();
  }
  res.status(403).json({ message: 'Запрос отклонён: отсутствует служебный заголовок' });
});

// Фабрика ограничителей частоты запросов.
// При превышении лимита сервер отвечает кодом 429 и понятным сообщением
function createLimiter({ windowMinutes, limit, message, skipSuccessfulRequests = false }) {
  return rateLimit({
    // В режиме автотестов ограничители отключены: тесты делают много запросов подряд
    skip: () => process.env.NODE_ENV === 'test',
    windowMs: windowMinutes * 60 * 1000,
    limit,
    skipSuccessfulRequests,
    standardHeaders: true,
    legacyHeaders: false,
    message: { message }
  });
}

// Вход: не больше 5 НЕУДАЧНЫХ попыток за 5 минут с одного адреса (защита от перебора паролей)
app.use('/api/auth/login', createLimiter({
  windowMinutes: 5,
  limit: 5,
  skipSuccessfulRequests: true,
  message: 'Слишком много неудачных попыток входа. Попробуйте через 5 минут'
}));

// Регистрация: не больше 10 аккаунтов в час с одного адреса
app.use('/api/auth/register', createLimiter({
  windowMinutes: 60,
  limit: 10,
  message: 'Слишком много регистраций. Попробуйте позже'
}));

// Промокоды: не больше 5 неудачных попыток за 10 минут (защита от подбора кодов)
app.use('/api/promo/redeem', createLimiter({
  windowMinutes: 10,
  limit: 5,
  skipSuccessfulRequests: true,
  message: 'Слишком много попыток ввода промокода. Попробуйте через 10 минут'
}));

// Общий лимит на все запросы к API: 300 в минуту с одного адреса
app.use('/api', createLimiter({
  windowMinutes: 1,
  limit: 300,
  message: 'Слишком много запросов. Подождите минуту'
}));

// ---------- Маршруты API ----------
// Проверка работоспособности: по этому адресу хостинг и мы сами можем убедиться,
// что сервер запущен и база подключена
app.get('/api/health', (req, res) => {
  const dbConnected = mongoose.connection.readyState === 1;
  res.status(dbConnected ? 200 : 503).json({
    status: dbConnected ? 'ok' : 'error',
    database: dbConnected ? 'connected' : 'disconnected',
    uptimeSeconds: Math.round(process.uptime())
  });
});
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/promo', promoRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/users', userRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/cases', caseRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/contract', contractRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/audit', auditRoutes);


// Неизвестный адрес внутри /api — ответ 404 в формате JSON
app.use('/api', (req, res) => {
  res.status(404).json({ message: 'Маршрут не найден' });
});

// ---------- Статические файлы ----------

// Загруженные картинки товаров: /uploads/<имя файла>
app.use('/uploads', express.static(uploadRoutes.UPLOAD_DIR, { maxAge: '7d' }));

// Сам сайт: index.html, скрипты из папки js, i18n.js
app.use(express.static(FRONTEND_DIR));

// Всё остальное — 404
app.use((req, res) => {
  res.status(404).json({ message: 'Страница не найдена' });
});

// Общий обработчик ошибок (например, если в запросе пришёл битый JSON)
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Некорректный JSON в запросе' });
  }
  if (err.type === 'entity.too.large') {
    return res.status(413).json({ message: 'Слишком большой запрос' });
  }
  console.error('Необработанная ошибка:', err);
  res.status(500).json({ message: 'Ошибка сервера' });
});

// ---------- Запуск ----------
// Сначала подключаемся к базе и только потом начинаем принимать запросы
function start() {
  mongoose
    .connect(process.env.MONGO_URI)
    .then(() => {
      console.log('✅ MongoDB подключена');
      const server = app.listen(PORT, () => {
        console.log(`🚀 Сайт и API запущены: http://localhost:${PORT}`);
      });

      // Аккуратная остановка. Хостинг перед перезапуском присылает сигнал SIGTERM:
      // перестаём принимать новые запросы, даём завершиться текущим и закрываем базу
      const shutdown = () => {
        console.log('⏹ Получен сигнал остановки, завершаем работу…');
        // Долгие соединения ленты событий сами не закроются — обрываем их
        if (server.closeAllConnections) server.closeAllConnections();
        server.close(() => {
          mongoose.disconnect().finally(() => process.exit(0));
        });
        // Если что-то зависло — выходим принудительно через 10 секунд
        setTimeout(() => process.exit(1), 10000).unref();
      };
      process.on('SIGTERM', shutdown);
      process.on('SIGINT', shutdown);
    })
    .catch((err) => {
      console.error('❌ Не удалось подключиться к MongoDB:', err.message);
      process.exit(1);
    });
}

// Сервер стартует, только если файл запущен напрямую (node server.js или npm run dev).
// Когда его подключают автотесты, запуск пропускается: тесты сами поднимают сервер
// на свободном порту и со своей тестовой базой
if (require.main === module) {
  start();
}

module.exports = app;