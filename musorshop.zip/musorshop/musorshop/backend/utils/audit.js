const AdminAction = require('../models/AdminAction');

const MAX_VALUE_LENGTH = 300; // длинные тексты (описания, комментарии) в журнале обрезаются

// Поля, которые отслеживаются у каждого вида объектов
const AUDIT_FIELDS = {
  product: ['title', 'description', 'price', 'quantity', 'rarity', 'category', 'wear', 'statTrak', 'imageUrl'],
  promo: ['code', 'type', 'amount', 'maxUses'],
  case: ['title', 'price', 'imageUrl', 'itemsCount']
};

// Приведение значения к виду, пригодному для хранения и сравнения
function normalize(value) {
  if (value === undefined || value === null) return '';
  if (typeof value === 'string') {
    return value.length > MAX_VALUE_LENGTH ? `${value.slice(0, MAX_VALUE_LENGTH)}…` : value;
  }
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  return String(value);
}

// Снимок объекта: значения перечисленных полей
function pick(source, fields) {
  const result = {};
  fields.forEach((field) => {
    result[field] = normalize(source[field]);
  });
  return result;
}

// Список изменений между двумя состояниями объекта: только поля, значения которых различаются
function diff(before, after, fields) {
  const changes = [];
  fields.forEach((field) => {
    const oldValue = normalize(before[field]);
    const newValue = normalize(after[field]);
    if (oldValue !== newValue) {
      changes.push({ field, before: oldValue, after: newValue });
    }
  });
  return changes;
}

// Снимок кейса: вместо списка идентификаторов предметов храним их количество
function snapshotCase(caseDoc) {
  return {
    title: normalize(caseDoc.title),
    price: normalize(caseDoc.price),
    imageUrl: normalize(caseDoc.imageUrl),
    itemsCount: Array.isArray(caseDoc.items) ? caseDoc.items.length : 0
  };
}

// Запись действия администратора в журнал.
// req — запрос (из него берётся, кто действует), action — код вида "product.create",
// target — над чем выполнено действие, details — подробности ({ changes, snapshot }).
// Сбой записи не должен отменять само действие, поэтому ошибка только выводится в консоль
async function logAdminAction(req, action, target = '', details = {}) {
  try {
    await AdminAction.create({
      adminId: req.user.id,
      action,
      category: action.split('.')[0],
      target: String(target).slice(0, 500),
      details
    });
  } catch (err) {
    console.error('Не удалось записать действие администратора:', err.message);
  }
}

module.exports = { logAdminAction, pick, diff, snapshotCase, AUDIT_FIELDS };