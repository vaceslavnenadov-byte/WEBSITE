const Transaction = require('../models/Transaction');

// Запись операции в историю.
// Ошибка записи не должна ломать саму операцию (деньги уже списаны или зачислены),
// поэтому её только выводим в консоль сервера
async function logTransaction({ userId, type, amount, balanceAfter, description = '' }) {
  try {
    await Transaction.create({ userId, type, amount, balanceAfter, description });
  } catch (err) {
    console.error('Не удалось записать операцию в историю:', err.message);
  }
}

module.exports = { logTransaction };