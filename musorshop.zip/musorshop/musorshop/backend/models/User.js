const mongoose = require('mongoose');

// Схема пользователя
const userSchema = new mongoose.Schema({
  // Email — уникальный, приводим к нижнему регистру и убираем пробелы по краям
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  // Здесь хранится НЕ сам пароль, а его bcrypt-хеш
  password: {
    type: String,
    required: true
  },
  // Роль: обычный покупатель или администратор
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  // Баланс в рублях, стартовый — 100 000, не может быть отрицательным
  balance: {
    type: Number,
    default: 100000,
    min: 0
  },
  // Версия токенов. При смене пароля увеличивается на 1,
  // и все выданные ранее токены перестают действовать
  tokenVersion: {
    type: Number,
    default: 0
  },
  // Заблокирован ли пользователь администратором
  isBlocked: {
    type: Boolean,
    default: false
  },
  // Накопленный опыт (по нему считается уровень)
  xp: {
    type: Number,
    default: 0,
    min: 0
  },
  // Когда в последний раз получен ежедневный бонус
  lastBonusAt: {
    type: Date
  },
  // Сколько дней подряд пользователь забирает бонус
  bonusStreak: {
    type: Number,
    default: 0
  }
});

// Экспортируем модель; коллекция в базе будет называться "users"
module.exports = mongoose.model('User', userSchema);