const mongoose = require('mongoose');

const NOTIFICATION_TYPES = ['market_sale', 'lot_cancelled', 'balance', 'review', 'restock'];

// Личное уведомление пользователя
const notificationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    enum: NOTIFICATION_TYPES,
    required: true
  },
  text: {
    type: String,
    required: true,
    maxlength: 500
  },
  // Прочитано ли уведомление
  read: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Индекс для выборки уведомлений одного пользователя по дате
notificationSchema.index({ userId: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);