const mongoose = require('mongoose');

// Схема покупки — запись о том, что пользователь купил товар
const purchaseSchema = new mongoose.Schema({
  // Кто купил
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  // Что купил
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  // Название и картинку копируем в покупку: если админ потом
  // изменит или удалит товар, история покупок не сломается
  productTitle: {
    type: String,
    required: true
  },
  productImage: {
    type: String,
    default: ''
  },
  // Цена на момент покупки
  price: {
    type: Number,
    required: true,
    min: 0
  },
  // Сколько пользователь реально заплатил. Для покупки в магазине совпадает с price,
  // для предмета из кейса — это цена кейса (а price — стоимость самого предмета)
  paid: {
    type: Number,
    min: 0
  },
  // Сколько с этой покупки получил магазин. Заполняется для покупок на площадке:
  // там деньги уходят продавцу, а магазину остаётся только комиссия
  shopIncome: {
    type: Number,
    min: 0
  },
  // Сколько владелец получил при продаже предмета (магазину или на площадке)
  soldFor: {
    type: Number,
    min: 0
  },
  // Идентификатор контракта обмена, в который отдан предмет
  contractId: {
    type: String
  },
  // Откуда предмет: shop — куплен в магазине, case — выпал из кейса
  source: {
    type: String,
    enum: ['shop', 'case', 'market', 'contract'],
    default: 'shop'
  },
  // active — предмет у пользователя, sold — продан обратно
  status: {
    type: String,
    // active — в инвентаре, sold — продан магазину,
    // listed — выставлен на площадке, traded — продан на площадке,
    // contracted — отдан в контракт обмена
    enum: ['active', 'sold', 'listed', 'traded', 'contracted'],
    default: 'active'
  },
  purchasedAt: {
    type: Date,
    default: Date.now
  },
  // Заполняется только при продаже
  soldAt: {
    type: Date
  }
});

module.exports = mongoose.model('Purchase', purchaseSchema);