const mongoose = require('mongoose');

// Схема отзыва
const reviewSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true
  },
  // Email автора сохраняем в отзыве, чтобы не искать пользователя при каждом показе
  userEmail: {
    type: String,
    required: true
  },
  // Оценка от 1 до 5
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
  },
  // Текст отзыва, не длиннее 500 символов
  comment: {
    type: String,
    default: '',
    trim: true,
    maxlength: 500
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  // Дата последнего изменения (пусто, если отзыв не редактировался)
  editedAt: {
    type: Date
  },
  // true, если отзыв изменил администратор, а не автор
  editedByAdmin: {
    type: Boolean,
    default: false
  }
});

// Уникальный составной индекс: один пользователь — один отзыв на товар
reviewSchema.index({ userId: 1, productId: 1 }, { unique: true });

module.exports = mongoose.model('Review', reviewSchema);