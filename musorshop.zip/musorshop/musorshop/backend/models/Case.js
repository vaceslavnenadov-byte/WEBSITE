const mongoose = require('mongoose');

// Схема кейса
const caseSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
    maxlength: 60
  },
  // Цена открытия
  price: {
    type: Number,
    required: true,
    min: 1
  },
  imageUrl: {
    type: String,
    default: '',
    trim: true
  },
  // Скины, которые могут выпасть
  items: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product'
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Case', caseSchema);