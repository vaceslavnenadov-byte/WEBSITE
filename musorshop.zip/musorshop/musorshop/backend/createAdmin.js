// Скрипт создания администратора.
// Запуск из папки backend: node createAdmin.js
require('dotenv').config();

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');

async function createAdmin() {
  // Данные админа берём из .env, чтобы пароль не лежал в коде
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';

  if (!email || password.length < 5) {
    console.error('❌ Задай ADMIN_EMAIL и ADMIN_PASSWORD (от 5 символов) в файле .env');
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB подключена');

    // Хешируем пароль так же, как при обычной регистрации
    const hash = await bcrypt.hash(password, 10);

    const existing = await User.findOne({ email });

    if (existing) {
      // Пользователь с таким email уже есть — делаем его админом и обновляем пароль
      existing.role = 'admin';
      existing.password = hash;
      await existing.save();
      console.log(`✅ Пользователь ${email} обновлён: роль admin, пароль из .env`);
    } else {
      // Создаём нового администратора
      await User.create({ email, password: hash, role: 'admin' });
      console.log(`✅ Администратор ${email} создан`);
    }
  } catch (err) {
    console.error('❌ Ошибка:', err.message);
    process.exitCode = 1;
  } finally {
    // Закрываем соединение, чтобы скрипт завершился
    await mongoose.disconnect();
  }
}

createAdmin();