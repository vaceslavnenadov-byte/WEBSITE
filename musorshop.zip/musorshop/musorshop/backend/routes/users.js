const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');
const Purchase = require('../models/Purchase');
const { verifyToken, isAdmin } = require('../middleware/auth');
const { logTransaction } = require('../utils/transactions');
const { notify } = require('../utils/notify');
const { logAdminAction } = require('../utils/audit');


const router = express.Router();

// Все маршруты этого файла доступны только администратору
router.use(verifyToken, isAdmin);

const PAGE_SIZE = 20;
const MAX_ADJUSTMENT = 10000000; // максимум одной корректировки баланса
const MAX_REASON_LENGTH = 200;

// Экранирование спецсимволов регулярных выражений в поисковой строке,
// чтобы текст вроде "a.b" искался буквально
function escapeRegex(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ---------- GET /api/users — список пользователей ----------
// Параметры: ?page=1&search=часть_email
router.get('/', async (req, res) => {
  try {
    const pageNumber = parseInt(req.query.page, 10);
    const page = Number.isInteger(pageNumber) && pageNumber > 0 ? pageNumber : 1;

    const filter = {};
    if (typeof req.query.search === 'string' && req.query.search.trim()) {
      const search = req.query.search.trim().slice(0, 100);
      filter.email = { $regex: escapeRegex(search), $options: 'i' };
    }

    const [users, total] = await Promise.all([
      User.find(filter)
        .select('email role balance isBlocked')
        .sort({ _id: -1 }) // сначала недавно зарегистрированные
        .skip((page - 1) * PAGE_SIZE)
        .limit(PAGE_SIZE),
      User.countDocuments(filter)
    ]);

    // Число покупок для пользователей этой страницы — одним запросом
    const counts = await Purchase.aggregate([
      { $match: { userId: { $in: users.map((user) => user._id) } } },
      { $group: { _id: '$userId', count: { $sum: 1 } } }
    ]);
    const countById = new Map(counts.map((row) => [row._id.toString(), row.count]));

    res.json({
      page,
      total,
      hasMore: page * PAGE_SIZE < total,
      items: users.map((user) => ({
        id: user._id,
        email: user.email,
        role: user.role,
        balance: user.balance,
        isBlocked: Boolean(user.isBlocked),
        purchasesCount: countById.get(user._id.toString()) || 0,
        // Дата регистрации "зашита" в сам идентификатор MongoDB
        registeredAt: user._id.getTimestamp()
      }))
    });
  } catch (err) {
    console.error('Ошибка загрузки пользователей:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- PUT /api/users/:id/block — заблокировать или разблокировать ----------
// Тело запроса: { blocked: true | false }
router.put('/:id/block', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор пользователя' });
    }

    const { blocked } = req.body || {};
    if (typeof blocked !== 'boolean') {
      return res.status(400).json({ message: 'Не указано действие' });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }
    // Администраторов блокировать нельзя (в том числе самого себя)
    if (user.role === 'admin') {
      return res.status(400).json({ message: 'Нельзя заблокировать администратора' });
    }

    user.isBlocked = blocked;
    await user.save();
    await logAdminAction(req, blocked ? 'user.block' : 'user.unblock', user.email);
    res.json({ message: blocked ? 'Пользователь заблокирован' : 'Пользователь разблокирован' });
  } catch (err) {
    console.error('Ошибка блокировки:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/users/:id/balance — корректировка баланса ----------
// Тело запроса: { amount: число со знаком, reason: причина }
router.post('/:id/balance', async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор пользователя' });
    }

    const { amount, reason } = req.body || {};

    if (typeof amount !== 'number' || !Number.isInteger(amount) || amount === 0) {
      return res.status(400).json({ message: 'Сумма должна быть целым числом, не равным нулю' });
    }
    if (Math.abs(amount) > MAX_ADJUSTMENT) {
      return res.status(400).json({
        message: `Сумма корректировки не может превышать ${MAX_ADJUSTMENT.toLocaleString('ru-RU')} ₽`
      });
    }
    if (typeof reason !== 'string' || !reason.trim()) {
      return res.status(400).json({ message: 'Укажите причину корректировки' });
    }
    const cleanReason = reason.trim();
    if (cleanReason.length > MAX_REASON_LENGTH) {
      return res.status(400).json({ message: `Причина не должна превышать ${MAX_REASON_LENGTH} символов` });
    }

    // При списании дополнительно требуем, чтобы денег хватало, —
    // условие и изменение выполняются одной операцией
    const filter = { _id: req.params.id };
    if (amount < 0) {
      filter.balance = { $gte: -amount };
    }

    const user = await User.findOneAndUpdate(filter, { $inc: { balance: amount } }, { returnDocument: 'after' });

    if (!user) {
      const exists = await User.exists({ _id: req.params.id });
      return res.status(exists ? 400 : 404).json({
        message: exists ? 'Нельзя списать больше, чем есть на балансе' : 'Пользователь не найден'
      });
    }

    await logTransaction({
      userId: user._id,
      type: 'adjustment',
      amount,
      balanceAfter: user.balance,
      description: `Корректировка администратором: ${cleanReason}`
    });

    // Пользователю — уведомление (администратору о собственной корректировке не сообщаем)
    if (String(user._id) !== req.user.id) {
      const signed = `${amount > 0 ? '+' : '−'}${Math.abs(amount).toLocaleString('ru-RU')}`;
      await notify(user._id, 'balance', `Администратор изменил ваш баланс: ${signed} ₽. Причина: ${cleanReason}`);
    }
    await logAdminAction(req, 'user.balance',
      `${user.email}: ${amount > 0 ? '+' : '−'}${Math.abs(amount).toLocaleString('ru-RU')} ₽. Причина: ${cleanReason}`,
      {
        changes: [{ field: 'balance', before: user.balance - amount, after: user.balance }],
        snapshot: { reason: cleanReason }
      });
    res.json({ message: 'Баланс изменён', balance: user.balance });
  } catch (err) {
    console.error('Ошибка корректировки баланса:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;