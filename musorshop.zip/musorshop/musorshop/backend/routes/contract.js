const express = require('express');
const crypto = require('crypto');
const mongoose = require('mongoose');
const Purchase = require('../models/Purchase');
const Product = require('../models/Product');
const { verifyToken } = require('../middleware/auth');
const { RARITY_KEYS } = require('../config/rarities');
const { publishFeed } = require('../utils/feed');


const router = express.Router();

// Все маршруты контракта требуют входа
router.use(verifyToken);

const CONTRACT_SIZE = 10;  // сколько предметов нужно отдать
// Результат не может быть дороже 125% суммарной стоимости отданного.
// Тогда его выкуп магазином за 80% никогда не превысит стоимость вложенных предметов,
// и контракт нельзя использовать для бесконечного заработка
const VALUE_CAP = 1.25;

const isValidId = (id) => typeof id === 'string' && mongoose.isValidObjectId(id);

// Следующая по старшинству редкость (null — выше уже некуда)
function getNextRarity(rarity) {
  const index = RARITY_KEYS.indexOf(rarity);
  return index === -1 || index === RARITY_KEYS.length - 1 ? null : RARITY_KEYS[index + 1];
}

// Редкости предметов берутся из товаров магазина.
// Возвращает Map: id товара → товар (с редкостью)
async function loadProductsFor(purchases) {
  const ids = [...new Set(purchases.map((purchase) => String(purchase.productId)))];
  const products = await Product.find({ _id: { $in: ids } }).select('rarity');
  return new Map(products.map((product) => [String(product._id), product]));
}

// Проверка набора предметов и подбор возможных результатов.
// Возвращает { error } или { purchases, rarity, nextRarity, totalValue, outcomes }
async function prepareContract(userId, purchaseIds) {
  if (!Array.isArray(purchaseIds) || purchaseIds.length !== CONTRACT_SIZE ||
      !purchaseIds.every(isValidId) || new Set(purchaseIds).size !== CONTRACT_SIZE) {
    return { error: `Для контракта нужно выбрать ровно ${CONTRACT_SIZE} разных предметов` };
  }

  // Только свои предметы, лежащие в инвентаре
  const purchases = await Purchase.find({ _id: { $in: purchaseIds }, userId, status: 'active' });
  if (purchases.length !== CONTRACT_SIZE) {
    return { error: 'Некоторые предметы не найдены в инвентаре или уже недоступны' };
  }

  const productById = await loadProductsFor(purchases);
  const rarities = purchases.map((purchase) => {
    const product = productById.get(String(purchase.productId));
    return product ? product.rarity : null;
  });

  if (rarities.includes(null)) {
    return { error: 'Среди выбранных есть предмет, которого больше нет в магазине: его редкость неизвестна' };
  }
  if (new Set(rarities).size !== 1) {
    return { error: 'Все предметы контракта должны быть одной редкости' };
  }

  const rarity = rarities[0];
  const nextRarity = getNextRarity(rarity);
  if (!nextRarity) {
    return { error: 'Предметы высшей редкости обменять нельзя' };
  }

  const totalValue = purchases.reduce((sum, purchase) => sum + purchase.price, 0);

  // Возможные результаты: товары следующей редкости в пределах допустимой стоимости
  const outcomes = await Product.find({
    rarity: nextRarity,
    price: { $lte: Math.floor(totalValue * VALUE_CAP) }
  }).select('title price imageUrl rarity');

  if (outcomes.length === 0) {
    return {
      error: 'Для этого набора нет подходящего результата: суммарная стоимость предметов слишком мала. Выберите предметы подороже'
    };
  }

  return { purchases, rarity, nextRarity, totalValue, outcomes };
}

// Данные предмета-результата для ответа клиенту
function formatOutcome(product, chance) {
  return {
    id: product._id,
    title: product.title,
    price: product.price,
    imageUrl: product.imageUrl,
    rarity: product.rarity,
    chance
  };
}

// ---------- GET /api/contract/inventory — предметы инвентаря с редкостью ----------
router.get('/inventory', async (req, res) => {
  try {
    const purchases = await Purchase.find({ userId: req.user.id, status: 'active' })
      .sort({ purchasedAt: -1 });
    const productById = await loadProductsFor(purchases);

    res.json(purchases.map((purchase) => {
      const product = productById.get(String(purchase.productId));
      return {
        id: purchase._id,
        title: purchase.productTitle,
        imageUrl: purchase.productImage,
        price: purchase.price,
        // null — товар удалён из магазина, такой предмет в контракт не годится
        rarity: product ? product.rarity : null
      };
    }));
  } catch (err) {
    console.error('Ошибка загрузки инвентаря для контракта:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/contract/preview — возможные результаты для набора ----------
// Тело запроса: { purchaseIds: [10 идентификаторов] }
router.post('/preview', async (req, res) => {
  try {
    const prepared = await prepareContract(req.user.id, (req.body || {}).purchaseIds);
    if (prepared.error) {
      return res.status(400).json({ message: prepared.error });
    }

    // Все подходящие предметы равновероятны
    const chance = Math.round(10000 / prepared.outcomes.length) / 100;

    res.json({
      rarity: prepared.rarity,
      nextRarity: prepared.nextRarity,
      totalValue: prepared.totalValue,
      outcomes: prepared.outcomes
        .map((product) => formatOutcome(product, chance))
        .sort((a, b) => b.price - a.price)
    });
  } catch (err) {
    console.error('Ошибка расчёта контракта:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/contract — выполнить обмен ----------
router.post('/', async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может заключать контракты' });
    }

    const purchaseIds = (req.body || {}).purchaseIds;
    const prepared = await prepareContract(req.user.id, purchaseIds);
    if (prepared.error) {
      return res.status(400).json({ message: prepared.error });
    }

    // Забираем предметы. Каждому ставится метка этого контракта: по ней при неудаче
    // можно вернуть именно те предметы, которые успели забрать
    const contractId = crypto.randomBytes(12).toString('hex');
    const taken = await Purchase.updateMany(
      { _id: { $in: purchaseIds }, userId: req.user.id, status: 'active' },
      { status: 'contracted', soldAt: new Date(), contractId }
    );

    const giveBack = () => Purchase.updateMany(
      { contractId, status: 'contracted' },
      { $set: { status: 'active' }, $unset: { soldAt: 1, contractId: 1 } }
    );

    // Забрать удалось не все — значит, часть предметов в этот момент продали
    // или выставили в соседнем окне. Возвращаем всё как было
    if (taken.modifiedCount !== CONTRACT_SIZE) {
      await giveBack();
      return res.status(400).json({ message: 'Некоторые предметы уже недоступны. Обновите список и попробуйте снова' });
    }

    // Результат выбирает сервер криптографически стойким генератором
    const won = prepared.outcomes[crypto.randomInt(prepared.outcomes.length)];

    try {
      await Purchase.create({
        userId: req.user.id,
        productId: won._id,
        productTitle: won.title,
        productImage: won.imageUrl,
        price: won.price,
        paid: 0,        // за сам предмет денег не платили
        shopIncome: 0,  // и магазин на обмене ничего не заработал
        source: 'contract'
      });
    } catch (createErr) {
      await giveBack();
      throw createErr;
    }
    publishFeed({ userId: req.user.id, title: won.title, rarity: won.rarity, price: won.price, source: 'contract' });

    res.json({
      message: 'Контракт выполнен',
      item: formatOutcome(won, null)
    });
  } catch (err) {
    console.error('Ошибка выполнения контракта:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;