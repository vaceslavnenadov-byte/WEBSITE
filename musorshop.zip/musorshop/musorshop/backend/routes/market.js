const express = require('express');
const mongoose = require('mongoose');
const Listing = require('../models/Listing');
const Purchase = require('../models/Purchase');
const Product = require('../models/Product');
const User = require('../models/User');
const { verifyToken, optionalToken } = require('../middleware/auth');
const { logTransaction } = require('../utils/transactions');
const { addXp, xpForSpend } = require('../utils/levels');
const { publishFeed } = require('../utils/feed');
const { notify } = require('../utils/notify');
const { logAdminAction } = require('../utils/audit');
const { RARITY_KEYS } = require('../config/rarities');

const router = express.Router();

const MARKET_FEE = 0.05;           // комиссия магазина: 5% от цены лота
const MARKET_PAGE_SIZE = 12;       // лотов на странице
const MAX_LISTING_PRICE = 10000000;
const MAX_ACTIVE_LISTINGS = 50;    // столько лотов один пользователь может держать одновременно
const HISTORY_LIMIT = 50;          // сколько последних сделок показывать в истории цен

const MARKET_SORTS = {
  'newest':     { createdAt: -1, _id: -1 },
  'price-asc':  { price: 1, _id: 1 },
  'price-desc': { price: -1, _id: 1 }
};

const isValidId = (id) => typeof id === 'string' && mongoose.isValidObjectId(id);
const queryString = (value) => (typeof value === 'string' ? value.trim() : '');
const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Скрываем часть email продавца: buyer@test.ru -> bu***@test.ru
function maskEmail(email) {
  const [name, domain] = String(email || '').split('@');
  if (!domain) return '***';
  return `${name.slice(0, 2)}***@${domain}`;
}

// Комиссия с лота (округление вниз) — считается один раз, при выставлении
function calcFee(price) {
  return Math.floor(price * MARKET_FEE);
}

// ---------- GET /api/market — активные лоты (доступно всем) ----------
// Параметры: page, sort, search, rarity, mine=1 (только свои лоты)
router.get('/', optionalToken, async (req, res) => {
  try {
    const query = req.query;
    const filter = { status: 'active' };

    const search = queryString(query.search).slice(0, 100);
    if (search) {
      filter.productTitle = new RegExp(escapeRegex(search), 'i');
    }

    const rarity = queryString(query.rarity);
    if (RARITY_KEYS.includes(rarity)) filter.rarity = rarity;

    // Только свои лоты; гостю вернётся пустой список
    if (queryString(query.mine) === '1') {
      filter.sellerId = req.user ? req.user.id : null;
    }

    const sort = MARKET_SORTS[queryString(query.sort)] || MARKET_SORTS.newest;

    const total = await Listing.countDocuments(filter);
    const pages = Math.max(1, Math.ceil(total / MARKET_PAGE_SIZE));
    const requested = parseInt(queryString(query.page), 10);
    const page = Math.min(Math.max(1, Number.isInteger(requested) ? requested : 1), pages);

    const listings = await Listing.find(filter)
      .populate('sellerId', 'email')
      .sort(sort)
      .skip((page - 1) * MARKET_PAGE_SIZE)
      .limit(MARKET_PAGE_SIZE);

    res.json({
      total,
      page,
      pages,
      feePercent: MARKET_FEE * 100,
      items: listings.map((listing) => ({
        id: listing._id,
        productId: listing.productId,
        title: listing.productTitle,
        imageUrl: listing.productImage,
        rarity: listing.rarity,
        wear: listing.wear,
        statTrak: listing.statTrak,
        itemValue: listing.itemValue,
        price: listing.price,
        seller: listing.sellerId ? maskEmail(listing.sellerId.email) : '***',
        // Свой ли это лот для текущего пользователя
        isMine: Boolean(req.user && listing.sellerId && String(listing.sellerId._id) === req.user.id),
        createdAt: listing.createdAt
      }))
    });
  } catch (err) {
    console.error('Ошибка загрузки лотов:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/market/history/:productId — история сделок по товару ----------
router.get('/history/:productId', async (req, res) => {
  try {
    if (!isValidId(req.params.productId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор товара' });
    }

    // Последние сделки, от старых к новым (в таком порядке их рисует график)
    const deals = await Listing.find({ productId: req.params.productId, status: 'sold' })
      .sort({ soldAt: -1 })
      .limit(HISTORY_LIMIT)
      .select('price soldAt');
    deals.reverse();

    const prices = deals.map((deal) => deal.price);
    const product = await Product.findById(req.params.productId).select('price');

    res.json({
      deals: deals.map((deal) => ({ price: deal.price, soldAt: deal.soldAt })),
      count: prices.length,
      min: prices.length ? Math.min(...prices) : null,
      max: prices.length ? Math.max(...prices) : null,
      average: prices.length ? Math.round(prices.reduce((sum, p) => sum + p, 0) / prices.length) : null,
      // Текущая цена в магазине — для сравнения (null, если товар удалён)
      shopPrice: product ? product.price : null
    });
  } catch (err) {
    console.error('Ошибка загрузки истории цен:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/market — выставить предмет на продажу ----------
// Тело запроса: { purchaseId, price }
router.post('/', verifyToken, async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может торговать на площадке' });
    }

    const { purchaseId, price } = req.body || {};

    if (!isValidId(purchaseId)) {
      return res.status(400).json({ message: 'Некорректный идентификатор предмета' });
    }
    if (typeof price !== 'number' || !Number.isInteger(price) || price < 1 || price > MAX_LISTING_PRICE) {
      return res.status(400).json({
        message: `Цена должна быть целым числом от 1 до ${MAX_LISTING_PRICE.toLocaleString('ru-RU')}`
      });
    }

    const activeCount = await Listing.countDocuments({ sellerId: req.user.id, status: 'active' });
    if (activeCount >= MAX_ACTIVE_LISTINGS) {
      return res.status(400).json({ message: `Одновременно можно держать не больше ${MAX_ACTIVE_LISTINGS} лотов` });
    }

    // Одной операцией проверяем, что предмет свой и лежит в инвентаре, и помечаем его выставленным.
    // С этого момента его нельзя ни продать магазину, ни выставить второй раз
    const purchase = await Purchase.findOneAndUpdate(
      { _id: purchaseId, userId: req.user.id, status: 'active' },
      { status: 'listed' },
      { returnDocument: 'after' }
    );
    if (!purchase) {
      return res.status(400).json({ message: 'Предмет не найден в инвентаре или уже недоступен' });
    }

    let listing;
    try {
      // Характеристики берём из товара; если он удалён из магазина — останутся значения по умолчанию
      const product = await Product.findById(purchase.productId).select('rarity wear statTrak');

      listing = await Listing.create({
        sellerId: req.user.id,
        purchaseId: purchase._id,
        productId: purchase.productId,
        productTitle: purchase.productTitle,
        productImage: purchase.productImage,
        rarity: product ? product.rarity : 'milspec',
        wear: product ? product.wear : '',
        statTrak: product ? product.statTrak : false,
        itemValue: purchase.price,
        price,
        fee: calcFee(price)
      });
    } catch (createErr) {
      // Лот не создался — возвращаем предмет в инвентарь
      await Purchase.updateOne({ _id: purchase._id, status: 'listed' }, { status: 'active' });
      throw createErr;
    }

    res.status(201).json({
      message: 'Предмет выставлен на продажу',
      id: listing._id,
      fee: listing.fee,
      sellerGets: price - listing.fee
    });
  } catch (err) {
    console.error('Ошибка выставления лота:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/market/:id — снять лот с продажи ----------
// Доступно продавцу и администратору
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор лота' });
    }

    const filter = { _id: req.params.id, status: 'active' };
    if (req.user.role !== 'admin') {
      filter.sellerId = req.user.id; // обычный пользователь снимает только свои лоты
    }

    const listing = await Listing.findOneAndUpdate(filter, { status: 'cancelled' }, { returnDocument: 'after' });
    if (!listing) {
      return res.status(404).json({ message: 'Лот не найден или уже неактивен' });
    }

    // Возвращаем предмет в инвентарь продавца
    await Purchase.updateOne({ _id: listing.purchaseId, status: 'listed' }, { status: 'active' });

    // Если лот снял администратор, а не сам продавец, — сообщаем продавцу
    if (req.user.role === 'admin' && String(listing.sellerId) !== req.user.id) {
      await notify(
        listing.sellerId,
        'lot_cancelled',
        `Администратор снял с продажи ваш лот «${listing.productTitle}». Предмет возвращён в инвентарь`
      );
      await logAdminAction(req, 'market.cancel', `«${listing.productTitle}»`, {
        snapshot: { lotPrice: listing.price, itemValue: listing.itemValue }
      });
    }

    res.json({ message: 'Лот снят с продажи' });
  } catch (err) {
    console.error('Ошибка снятия лота:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/market/:id/buy — купить лот ----------
router.post('/:id/buy', verifyToken, async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может торговать на площадке' });
    }
    if (!isValidId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор лота' });
    }

    const now = new Date();

    // Шаг 1. Занимаем лот: одной операцией проверяем, что он активен и не свой, и помечаем проданным.
    // Два покупателя не смогут купить один лот одновременно
    const listing = await Listing.findOneAndUpdate(
      { _id: req.params.id, status: 'active', sellerId: { $ne: req.user.id } },
      { status: 'sold', buyerId: req.user.id, soldAt: now },
      { returnDocument: 'after' }
    );

    if (!listing) {
      const existing = await Listing.findById(req.params.id).select('status sellerId');
      if (!existing) {
        return res.status(404).json({ message: 'Лот не найден' });
      }
      const own = String(existing.sellerId) === req.user.id;
      return res.status(400).json({
        message: own && existing.status === 'active' ? 'Нельзя купить собственный лот' : 'Лот уже продан или снят с продажи'
      });
    }

    // Возврат лота в продажу — если дальше что-то пойдёт не так
    const releaseListing = () => Listing.updateOne(
      { _id: listing._id },
      { $set: { status: 'active' }, $unset: { buyerId: 1, soldAt: 1 } }
    );

    // Шаг 2. Списываем деньги у покупателя — только если баланса хватает
    const buyer = await User.findOneAndUpdate(
      { _id: req.user.id, balance: { $gte: listing.price } },
      { $inc: { balance: -listing.price } },
      { returnDocument: 'after' }
    );
    if (!buyer) {
      await releaseListing();
      return res.status(400).json({ message: 'Недостаточно средств на балансе' });
    }

    const sellerGets = listing.price - listing.fee;
    let seller;

    try {
      // Шаг 3. Предмет покупателю. Стоимость предмета (price) переносится без изменений,
      // а цена лота записывается как "заплачено". Магазин получает только комиссию
      await Purchase.create({
        userId: buyer._id,
        productId: listing.productId,
        productTitle: listing.productTitle,
        productImage: listing.productImage,
        price: listing.itemValue,
        paid: listing.price,
        shopIncome: listing.fee,
        source: 'market'
      });
    } catch (createErr) {
      // Предмет не выдан — возвращаем деньги и лот
      await User.updateOne({ _id: buyer._id }, { $inc: { balance: listing.price } });
      await releaseListing();
      throw createErr;
    }

    // Шаг 4. Деньги продавцу и отметка в его инвентаре
    seller = await User.findByIdAndUpdate(
      listing.sellerId,
      { $inc: { balance: sellerGets } },
      { returnDocument: 'after' }
    );
    await Purchase.updateOne(
      { _id: listing.purchaseId },
      { status: 'traded', soldAt: now, soldFor: sellerGets }
    );

    // Шаг 5. История операций обеих сторон
    await logTransaction({
      userId: buyer._id,
      type: 'market_buy',
      amount: -listing.price,
      balanceAfter: buyer.balance,
      description: listing.productTitle
    });
    if (seller) {
      await logTransaction({
        userId: seller._id,
        type: 'market_sale',
        amount: sellerGets,
        balanceAfter: seller.balance,
        description: `${listing.productTitle} (комиссия ${listing.fee.toLocaleString('ru-RU')} ₽)`
      });
    }
    // Продавцу — уведомление о сделке
    if (seller) {
      await notify(
        seller._id,
        'market_sale',
        `Ваш лот «${listing.productTitle}» купили за ${listing.price.toLocaleString('ru-RU')} ₽. ` +
        `На баланс зачислено ${sellerGets.toLocaleString('ru-RU')} ₽`
      );
    }

    await addXp(buyer._id, xpForSpend(listing.price));
    publishFeed({ user: buyer, title: listing.productTitle, rarity: listing.rarity, price: listing.price, source: 'market' });
    res.json({
      message: `Вы купили «${listing.productTitle}»`,
      price: listing.price,
      balance: buyer.balance
    });
  } catch (err) {
    console.error('Ошибка покупки лота:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;