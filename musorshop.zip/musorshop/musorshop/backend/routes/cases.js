const express = require('express');
const crypto = require('crypto');
const mongoose = require('mongoose');
const Case = require('../models/Case');
const Product = require('../models/Product');
const Purchase = require('../models/Purchase');
const User = require('../models/User');
const { verifyToken, isAdmin } = require('../middleware/auth');
const { logTransaction } = require('../utils/transactions');
const { addXp, xpForSpend } = require('../utils/levels');
const { publishFeed } = require('../utils/feed');
const { logAdminAction, diff, snapshotCase, AUDIT_FIELDS } = require('../utils/audit');
const { RARITIES, DEFAULT_RARITY } = require('../config/rarities');

const router = express.Router();

const MIN_CASE_ITEMS = 2;
const MAX_CASE_ITEMS = 50;
const MAX_CASE_PRICE = 10000000;

// Таблица выпадения: для каждого предмета считаем шанс (число от 0 до 1).
// Сначала вес делится между редкостями, которые есть в кейсе,
// затем доля каждой редкости делится поровну между её предметами
function buildDropTable(products) {
  const countByRarity = {};
  products.forEach((product) => {
    const rarity = RARITIES[product.rarity] ? product.rarity : DEFAULT_RARITY;
    countByRarity[rarity] = (countByRarity[rarity] || 0) + 1;
  });

  const totalWeight = Object.keys(countByRarity)
    .reduce((sum, rarity) => sum + RARITIES[rarity].weight, 0);

  return products.map((product) => {
    const rarity = RARITIES[product.rarity] ? product.rarity : DEFAULT_RARITY;
    return {
      product,
      rarity,
      chance: RARITIES[rarity].weight / totalWeight / countByRarity[rarity]
    };
  });
}

// Случайный выбор предмета по таблице выпадения.
// crypto.randomInt — криптографически стойкий генератор: результат нельзя предсказать
function pickItem(table) {
  const SCALE = 1000000000;
  const roll = crypto.randomInt(0, SCALE) / SCALE; // число от 0 до 1

  let cumulative = 0;
  for (const entry of table) {
    cumulative += entry.chance;
    if (roll < cumulative) return entry;
  }
  return table[table.length - 1]; // страховка от погрешности округления
}

// Данные предмета для ответа клиенту
function formatItem(entry) {
  return {
    id: entry.product._id,
    title: entry.product.title,
    price: entry.product.price,
    imageUrl: entry.product.imageUrl,
    rarity: entry.rarity,
    chance: Math.round(entry.chance * 10000) / 100 // в процентах, до сотых
  };
}

// Проверка данных кейса при создании и изменении
async function validateCaseData(body) {
  const { title, price, imageUrl, items } = body || {};

  if (typeof title !== 'string' || !title.trim() || title.trim().length > 60) {
    return { error: 'Название кейса: от 1 до 60 символов' };
  }
  if (typeof price !== 'number' || !Number.isInteger(price) || price < 1 || price > MAX_CASE_PRICE) {
    return { error: `Цена должна быть целым числом от 1 до ${MAX_CASE_PRICE.toLocaleString('ru-RU')}` };
  }
  if (imageUrl !== undefined && typeof imageUrl !== 'string') {
    return { error: 'Некорректная ссылка на картинку' };
  }
  const cleanUrl = (imageUrl || '').trim();
  if (cleanUrl && !/^https?:\/\//i.test(cleanUrl)) {
    return { error: 'Ссылка на картинку должна начинаться с http:// или https://' };
  }

  if (!Array.isArray(items) || items.length < MIN_CASE_ITEMS || items.length > MAX_CASE_ITEMS) {
    return { error: `В кейсе должно быть от ${MIN_CASE_ITEMS} до ${MAX_CASE_ITEMS} предметов` };
  }
  const allValid = items.every((id) => typeof id === 'string' && mongoose.isValidObjectId(id));
  if (!allValid || new Set(items).size !== items.length) {
    return { error: 'Некорректный список предметов' };
  }

  // Все выбранные товары должны существовать
  const found = await Product.countDocuments({ _id: { $in: items } });
  if (found !== items.length) {
    return { error: 'Некоторые из выбранных товаров не найдены' };
  }

  return { data: { title: title.trim(), price, imageUrl: cleanUrl, items } };
}

// ---------- GET /api/cases — список кейсов с содержимым и шансами (доступно всем) ----------
router.get('/', async (req, res) => {
  try {
    const cases = await Case.find()
      .populate('items', 'title price imageUrl rarity')
      .sort({ createdAt: -1 });

    res.json(cases.map((caseDoc) => {
      // Товары, удалённые админом, пропускаем
      const products = caseDoc.items.filter(Boolean);
      const table = buildDropTable(products);

      return {
        id: caseDoc._id,
        title: caseDoc.title,
        price: caseDoc.price,
        imageUrl: caseDoc.imageUrl,
        // Сначала самые редкие предметы
        items: table.map(formatItem).sort((a, b) => a.chance - b.chance)
      };
    }));
  } catch (err) {
    console.error('Ошибка загрузки кейсов:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/cases/:id/open — открыть кейс ----------
router.post('/:id/open', verifyToken, async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратор не может открывать кейсы' });
    }
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор кейса' });
    }

    const caseDoc = await Case.findById(req.params.id)
      .populate('items', 'title price imageUrl rarity');
    if (!caseDoc) {
      return res.status(404).json({ message: 'Кейс не найден' });
    }

    const products = caseDoc.items.filter(Boolean);
    if (products.length === 0) {
      return res.status(400).json({ message: 'Этот кейс пуст' });
    }

    // Списываем цену кейса — только если баланса хватает
    const user = await User.findOneAndUpdate(
      { _id: req.user.id, balance: { $gte: caseDoc.price } },
      { $inc: { balance: -caseDoc.price } },
      { returnDocument: 'after' }
    );
    if (!user) {
      return res.status(400).json({ message: 'Недостаточно средств на балансе' });
    }

    // Результат определяется на сервере — клиент на него повлиять не может
    const won = pickItem(buildDropTable(products));

    try {
      await Purchase.create({
        userId: user._id,
        productId: won.product._id,
        productTitle: won.product.title,
        productImage: won.product.imageUrl,
        price: won.product.price, // стоимость предмета (от неё считается продажа за 80%)
        paid: caseDoc.price,      // сколько реально заплачено
        source: 'case'
      });
    } catch (createErr) {
      // Предмет не выдан — возвращаем деньги
      await User.updateOne({ _id: user._id }, { $inc: { balance: caseDoc.price } });
      throw createErr;
    }

    await logTransaction({
      userId: user._id,
      type: 'case',
      amount: -caseDoc.price,
      balanceAfter: user.balance,
      description: `Кейс «${caseDoc.title}»: ${won.product.title}`
    });
    await addXp(user._id, xpForSpend(caseDoc.price));
    publishFeed({ user, title: won.product.title, rarity: won.rarity, price: won.product.price, source: 'case' });
    res.json({
      item: formatItem(won),
      casePrice: caseDoc.price,
      balance: user.balance
    });
  } catch (err) {
    console.error('Ошибка открытия кейса:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/cases — создать кейс (только админ) ----------
router.post('/', verifyToken, isAdmin, async (req, res) => {
  try {
    const { error, data } = await validateCaseData(req.body);
    if (error) {
      return res.status(400).json({ message: error });
    }

    await Case.create(data);
    await logAdminAction(req, 'case.create', `«${data.title}»`, { snapshot: snapshotCase(data) });
    res.status(201).json({ message: 'Кейс создан' });
  } catch (err) {
    console.error('Ошибка создания кейса:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- PUT /api/cases/:id — изменить кейс (только админ) ----------
router.put('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор кейса' });
    }

    const { error, data } = await validateCaseData(req.body);
    if (error) {
      return res.status(400).json({ message: error });
    }
    // Запоминаем кейс до изменения — для журнала действий
    const previousCase = await Case.findById(req.params.id);
    const caseDoc = await Case.findByIdAndUpdate(req.params.id, data, {
      returnDocument: 'after',
      runValidators: true
    });
    if (!caseDoc) {
      return res.status(404).json({ message: 'Кейс не найден' });
    }
    await logAdminAction(req, 'case.update', `«${caseDoc.title}»`, {
      changes: previousCase
        ? diff(snapshotCase(previousCase), snapshotCase(caseDoc), AUDIT_FIELDS.case)
        : []
    });
    res.json({ message: 'Кейс обновлён' });
  } catch (err) {
    console.error('Ошибка изменения кейса:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/cases/:id — удалить кейс (только админ) ----------
router.delete('/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Некорректный идентификатор кейса' });
    }

    const caseDoc = await Case.findByIdAndDelete(req.params.id);
    if (!caseDoc) {
      return res.status(404).json({ message: 'Кейс не найден' });
    }
    await logAdminAction(req, 'case.delete', `«${caseDoc.title}»`, { snapshot: snapshotCase(caseDoc) });
    res.json({ message: 'Кейс удалён' });
  } catch (err) {
    console.error('Ошибка удаления кейса:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;