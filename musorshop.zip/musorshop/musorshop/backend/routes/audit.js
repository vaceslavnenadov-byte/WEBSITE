const express = require('express');
const AdminAction = require('../models/AdminAction');
const { verifyToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

// Журнал виден только администраторам
router.use(verifyToken, isAdmin);

const PAGE_SIZE = 20;
const CATEGORIES = ['product', 'promo', 'case', 'user', 'review', 'market'];

// ---------- GET /api/audit — журнал действий администраторов ----------
// Параметры: page, category (необязательный фильтр по разделу)
router.get('/', async (req, res) => {
  try {
    const requested = parseInt(req.query.page, 10);
    const page = Number.isInteger(requested) && requested > 0 ? requested : 1;

    const filter = {};
    // Раздел принимаем только строкой из разрешённого списка
    if (typeof req.query.category === 'string' && CATEGORIES.includes(req.query.category)) {
      filter.category = req.query.category;
    }

    const [items, total] = await Promise.all([
      AdminAction.find(filter)
        .populate('adminId', 'email')
        .sort({ createdAt: -1, _id: -1 })
        .skip((page - 1) * PAGE_SIZE)
        .limit(PAGE_SIZE),
      AdminAction.countDocuments(filter)
    ]);

    res.json({
      page,
      total,
      hasMore: page * PAGE_SIZE < total,
      items: items.map((item) => ({
        id: item._id,
        admin: item.adminId ? item.adminId.email : 'Удалённый администратор',
        action: item.action,
        category: item.category,
        target: item.target,
        details: item.details || {},
        createdAt: item.createdAt
      }))
    });
  } catch (err) {
    console.error('Ошибка загрузки журнала действий:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;