const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { verifyToken, signToken, setAuthCookie, clearAuthCookie } = require('../middleware/auth');
const { logTransaction } = require('../utils/transactions');
const { createCaptcha, requireCaptcha } = require('../utils/captcha');
const { getLevelInfo, getBonusState, BONUS_XP } = require('../utils/levels');


const router = express.Router();

// Константы
const SALT_ROUNDS = 10;          // количество раундов bcrypt
const MIN_PASSWORD_LENGTH = 5;   // минимальная длина пароля
const MAX_DEPOSIT = 1000000;     // максимум одного пополнения

// Простая проверка email: есть @ и точка после неё
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Данные пользователя, которые отдаются клиенту: без пароля и служебных полей
function publicUser(user) {
  return {
    id: user._id,
    email: user.email,
    role: user.role,
    balance: user.balance,
    progress: getLevelInfo(user.xp || 0),
    // Бонус положен только покупателю
    bonus: user.role === 'user' ? getBonusState(user) : null
  };
}

// ---------- GET /api/auth/captcha — получить новый проверочный код ----------
router.get('/captcha', (req, res) => {
  const captcha = createCaptcha();

  const payload = { id: captcha.id, svg: captcha.svg };
  // Правильный ответ отдаётся ТОЛЬКО в режиме автотестов — иначе капча была бы бессмысленна
  if (process.env.NODE_ENV === 'test') {
    payload.answer = captcha.text;
  }

  res.set('Cache-Control', 'no-store'); // каждый запрос — новая картинка
  res.json(payload);
});

// ---------- POST /api/auth/register — регистрация ----------
router.post('/register', requireCaptcha, async (req, res) => {
  try {
    // Берём ТОЛЬКО email и пароль. Поле role из запроса игнорируется,
    // поэтому зарегистрироваться админом через API невозможно
    const { email, password } = req.body || {};

    // Проверяем, что пришли именно строки (защита от NoSQL-инъекций
    // вида { "email": { "$gt": "" } })
    if (typeof email !== 'string' || typeof password !== 'string') {
      return res.status(400).json({ message: 'Введите email и пароль' });
    }

    const cleanEmail = email.trim().toLowerCase();

    if (!EMAIL_REGEX.test(cleanEmail)) {
      return res.status(400).json({ message: 'Некорректный email' });
    }
    if (password.length < MIN_PASSWORD_LENGTH) {
      return res.status(400).json({
        message: `Пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`
      });
    }

    // Проверяем, не занят ли email
    const existing = await User.findOne({ email: cleanEmail });
    if (existing) {
      return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
    }

    // Хешируем пароль — в базу попадает только хеш
    const hash = await bcrypt.hash(password, SALT_ROUNDS);

    // Роль жёстко 'user', баланс подставится по умолчанию (100 000)
    await User.create({ email: cleanEmail, password: hash, role: 'user' });

    res.status(201).json({ message: 'Регистрация прошла успешно' });
  } catch (err) {
    // Код 11000 — нарушение уникального индекса (email занят)
    if (err.code === 11000) {
      return res.status(400).json({ message: 'Пользователь с таким email уже существует' });
    }
    console.error('Ошибка регистрации:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/auth/login — вход ----------
router.post('/login', requireCaptcha, async (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (typeof email !== 'string' || typeof password !== 'string') {
      return res.status(400).json({ message: 'Введите email и пароль' });
    }

    const user = await User.findOne({ email: email.trim().toLowerCase() });

    // Одинаковое сообщение для "нет такого email" и "неверный пароль",
    // чтобы нельзя было подбирать существующие адреса
    if (!user) {
      return res.status(400).json({ message: 'Неверный email или пароль' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Неверный email или пароль' });
    }

    // Заблокированный пользователь войти не может.
    // Проверяем после пароля, чтобы посторонний не мог узнать статус чужого аккаунта
    if (user.isBlocked) {
      return res.status(403).json({ message: 'Аккаунт заблокирован администратором' });
    }
    
    // Создаём токен на 1 день и кладём его в httpOnly-cookie
    const token = signToken(user);
    setAuthCookie(res, token);

    res.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error('Ошибка входа:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- GET /api/auth/me — данные о себе ----------
router.get('/me', verifyToken, async (req, res) => {
  try {
    // select('-password') — не отдаём хеш пароля наружу
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    res.json(publicUser(user));
  } catch (err) {
    console.error('Ошибка получения профиля:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- PUT /api/auth/change-password — смена пароля ----------
router.put('/change-password', verifyToken, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body || {};

    if (typeof oldPassword !== 'string' || typeof newPassword !== 'string') {
      return res.status(400).json({ message: 'Заполните все поля' });
    }
    if (newPassword.length < MIN_PASSWORD_LENGTH) {
      return res.status(400).json({
        message: `Новый пароль должен быть не короче ${MIN_PASSWORD_LENGTH} символов`
      });
    }
    if (oldPassword === newPassword) {
      return res.status(400).json({ message: 'Новый пароль совпадает со старым' });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    // Сверяем старый пароль с хешем в базе
    const isMatch = await bcrypt.compare(oldPassword, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Старый пароль введён неверно' });
    }

    user.password = await bcrypt.hash(newPassword, SALT_ROUNDS);
    // Увеличиваем версию токенов — все старые сессии (на других устройствах) завершаются
    user.tokenVersion = (user.tokenVersion || 0) + 1;
    await user.save();

    // Выдаём новый токен, чтобы текущая сессия продолжила работать
    const newToken = signToken(user);
    setAuthCookie(res, newToken);
    res.json({ message: 'Пароль успешно изменён', token: newToken });
  } catch (err) {
    console.error('Ошибка смены пароля:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/auth/deposit — пополнение баланса ----------
router.post('/deposit', verifyToken, async (req, res) => {
  try {
    const { amount } = req.body || {};

    // Сумма должна быть целым положительным числом в пределах лимита
    if (typeof amount !== 'number' || !Number.isInteger(amount) || amount <= 0) {
      return res.status(400).json({ message: 'Введите корректную сумму' });
    }
    if (amount > MAX_DEPOSIT) {
      return res.status(400).json({
        message: `Максимальная сумма пополнения — ${MAX_DEPOSIT.toLocaleString('ru-RU')} ₽`
      });
    }

    // $inc увеличивает баланс прямо в базе за одну операцию —
    // это безопаснее, чем "прочитать, прибавить, записать"
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $inc: { balance: amount } },
      { returnDocument: 'after' }
    );
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    await logTransaction({
      userId: user._id,
      type: 'deposit',
      amount,
      balanceAfter: user.balance,
      description: 'Пополнение баланса'
    });

    res.json({ message: 'Баланс пополнен', balance: user.balance });
  } catch (err) {
    console.error('Ошибка пополнения:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/auth/logout — выход ----------
// Cookie с токеном недоступна из JavaScript, поэтому удалить её может только сервер
router.post('/logout', (req, res) => {
  clearAuthCookie(res);
  res.json({ message: 'Вы вышли из аккаунта' });
});

// ---------- POST /api/auth/bonus — получить ежедневный бонус ----------
router.post('/bonus', verifyToken, async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(403).json({ message: 'Администратору бонус не положен' });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'Пользователь не найден' });
    }

    const bonus = getBonusState(user);
    if (!bonus.available) {
      return res.status(400).json({ message: 'Сегодняшний бонус уже получен', nextAt: bonus.nextAt });
    }

    // Начисляем, только если отметка о прошлом бонусе не изменилась с момента чтения.
    // Два одновременных запроса не смогут получить бонус дважды
    const updated = await User.findOneAndUpdate(
      { _id: user._id, lastBonusAt: user.lastBonusAt || null },
      {
        $inc: { balance: bonus.amount, xp: BONUS_XP },
        $set: { lastBonusAt: new Date(), bonusStreak: bonus.nextStreak }
      },
      { returnDocument: 'after' }
    );
    if (!updated) {
      return res.status(400).json({ message: 'Сегодняшний бонус уже получен' });
    }

    await logTransaction({
      userId: updated._id,
      type: 'bonus',
      amount: bonus.amount,
      balanceAfter: updated.balance,
      description: `Серия дней: ${bonus.nextStreak}`
    });

    res.json({
      message: `Бонус получен: +${bonus.amount.toLocaleString('ru-RU')} ₽`,
      amount: bonus.amount,
      streak: bonus.nextStreak,
      user: publicUser(updated)
    });
  } catch (err) {
    console.error('Ошибка получения бонуса:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;