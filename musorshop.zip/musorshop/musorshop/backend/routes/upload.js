const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const multer = require('multer');
const { verifyToken, isAdmin } = require('../middleware/auth');

const router = express.Router();

// Папка для загруженных файлов: backend/uploads (создаётся автоматически)
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2 МБ

// Определяем тип картинки по первым байтам файла ("сигнатуре").
// Расширению и типу, которые прислал браузер, доверять нельзя: их легко подделать,
// переименовав любой файл в .png. Сигнатуру подделать так не получится
function detectImageType(buffer) {
  if (buffer.length < 12) return null;

  // JPEG: FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpg';

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  const pngSignature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  if (buffer.subarray(0, 8).equals(pngSignature)) return 'png';

  // GIF: "GIF8"
  if (buffer.subarray(0, 4).toString('ascii') === 'GIF8') return 'gif';

  // WebP: "RIFF" .... "WEBP"
  if (
    buffer.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buffer.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return 'webp';
  }

  return null;
}

// Файл сначала принимаем в память, проверяем и только потом сохраняем на диск
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE, files: 1 }
}).single('image');

// ---------- POST /api/upload/image — загрузить картинку (только админ) ----------
router.post('/image', verifyToken, isAdmin, (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ message: 'Файл слишком большой. Максимум — 2 МБ' });
      }
      return res.status(400).json({ message: 'Не удалось принять файл' });
    }

    if (!req.file) {
      return res.status(400).json({ message: 'Файл не выбран' });
    }

    const extension = detectImageType(req.file.buffer);
    if (!extension) {
      return res.status(400).json({ message: 'Допустимы только изображения JPG, PNG, GIF и WebP' });
    }

    try {
      // Имя файла генерируем сами — случайное. Имя от пользователя не используем вообще,
      // поэтому через него нельзя ни перезаписать чужой файл, ни выйти за пределы папки
      const fileName = `${crypto.randomBytes(16).toString('hex')}.${extension}`;
      await fs.promises.writeFile(path.join(UPLOAD_DIR, fileName), req.file.buffer);

      // Возвращаем полный адрес файла, например http://localhost:5000/uploads/ab12....png
      res.status(201).json({
        url: `${req.protocol}://${req.get('host')}/uploads/${fileName}`
      });
    } catch (saveErr) {
      console.error('Ошибка сохранения файла:', saveErr);
      res.status(500).json({ message: 'Не удалось сохранить файл' });
    }
  });
});

module.exports = router;
module.exports.UPLOAD_DIR = UPLOAD_DIR;