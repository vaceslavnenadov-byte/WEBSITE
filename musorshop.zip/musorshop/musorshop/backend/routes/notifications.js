const express = require('express');
const Notification = require('../models/Notification');
const { verifyToken } = require('../middleware/auth');
const { toPublic } = require('../utils/notify');

const router = express.Router();

// Уведомления есть только у вошедших пользователей, и каждый видит только свои
router.use(verifyToken);

const NOTIFICATIONS_LIMIT = 30;

// ---------- GET /api/notifications — последние уведомления и число непрочитанных ----------
router.get('/', async (req, res) => {
  try {
    const [items, unread] = await Promise.all([
      Notification.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(NOTIFICATIONS_LIMIT),
      Notification.countDocuments({ userId: req.user.id, read: false })
    ]);

    res.json({ unread, items: items.map(toPublic) });
  } catch (err) {
    console.error('Ошибка загрузки уведомлений:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- POST /api/notifications/read — отметить все прочитанными ----------
router.post('/read', async (req, res) => {
  try {
    await Notification.updateMany({ userId: req.user.id, read: false }, { read: true });
    res.json({ message: 'Уведомления прочитаны' });
  } catch (err) {
    console.error('Ошибка отметки уведомлений:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// ---------- DELETE /api/notifications — очистить свои уведомления ----------
router.delete('/', async (req, res) => {
  try {
    await Notification.deleteMany({ userId: req.user.id });
    res.json({ message: 'Уведомления удалены' });
  } catch (err) {
    console.error('Ошибка удаления уведомлений:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

module.exports = router;