const express = require('express');
const { optionalToken } = require('../middleware/auth');
const { canAcceptClient, addClient, sendEvent } = require('../utils/realtime');
const { getRecentFeed } = require('../utils/feed');

const router = express.Router();

// ---------- GET /api/events — поток событий в реальном времени ----------
// Соединение остаётся открытым, пока открыта вкладка. Гость получает общую ленту,
// вошедший пользователь — ещё и личные уведомления
router.get('/', optionalToken, async (req, res) => {
  if (!canAcceptClient()) {
    return res.status(503).json({ message: 'Слишком много подключений. Попробуйте позже' });
  }

  addClient(req, res, req.user ? req.user.id : null);

  // Сразу после подключения отправляем последние события
  try {
    sendEvent(res, 'feed', await getRecentFeed());
  } catch (err) {
    console.error('Ошибка загрузки ленты:', err);
    sendEvent(res, 'feed', []);
  }
});

module.exports = router;