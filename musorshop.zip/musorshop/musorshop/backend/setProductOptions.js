// Скрипт: проставляет категорию и качество товарам, у которых они ещё не заданы.
// Запуск из папки backend: node setProductOptions.js
require('dotenv').config();

const mongoose = require('mongoose');
const Product = require('./models/Product');

// Оружие по категориям: категория определяется по началу названия скина
const WEAPONS = {
  rifle:  ['AK-47', 'M4A4', 'M4A1-S', 'FAMAS', 'Galil AR', 'AUG', 'SG 553'],
  sniper: ['AWP', 'SSG 08', 'SCAR-20', 'G3SG1'],
  pistol: ['Desert Eagle', 'USP-S', 'Glock-18', 'P250', 'Five-SeveN', 'Tec-9', 'CZ75-Auto', 'P2000', 'Dual Berettas', 'R8 Revolver'],
  smg:    ['MP9', 'MP7', 'MP5-SD', 'MAC-10', 'UMP-45', 'P90', 'PP-Bizon'],
  heavy:  ['Nova', 'XM1014', 'MAG-7', 'Sawed-Off', 'M249', 'Negev']
};

function detectCategory(title) {
  const lower = title.toLowerCase();
  if (lower.includes('knife') || lower.includes('karambit') || lower.includes('bayonet') || title.includes('★')) return 'knife';
  if (lower.includes('gloves') || lower.includes('wraps')) return 'gloves';

  for (const [category, weapons] of Object.entries(WEAPONS)) {
    if (weapons.some((weapon) => lower.startsWith(weapon.toLowerCase()))) return category;
  }
  return 'other';
}

function detectWear(text) {
  const lower = text.toLowerCase();
  if (lower.includes('factory new')) return 'fn';
  if (lower.includes('minimal wear')) return 'mw';
  if (lower.includes('field-tested')) return 'ft';
  if (lower.includes('well-worn')) return 'ww';
  if (lower.includes('battle-scarred')) return 'bs';
  return '';
}

async function main() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB подключена');

    // Только товары, где поля category ещё нет в базе
    const products = await Product.find({ category: { $exists: false } });

    for (const product of products) {
      product.category = detectCategory(product.title);
      product.wear = detectWear(`${product.title} ${product.description}`);
      await product.save();
      console.log(`  ${product.title} → ${product.category}${product.wear ? `, ${product.wear}` : ''}`);
    }

    console.log(`✅ Обновлено товаров: ${products.length}`);
  } catch (err) {
    console.error('❌ Ошибка:', err.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

main();